#! /usr/bin/perl

##########################################################################
#Title:         Dell Device Plugin Script
#Version:       1.0 
#Creation Date: 25th September 2014
#Description:   This script provides Dell Server health 
#               and component health via Out-of-Band mode using iDRAC. 
#
#Copyright (c) 2014 Dell Inc.
#All Rights Reserved.
##########################################################################

use Getopt::Long qw(:config no_ignore_case);
use Time::localtime;
use File::Spec;

# Global (package) variables used throughout the code
use vars qw($OK $WARNING $CRITICAL $UNKNOWN $HELP 
            $snmp_session $snmp_error $nextline 
            %opt %Nagios_ExitStatus_String_mapping  %snmp_status 
    );

our $plugin_timeout = 15;
our $printmsg = "";
our $printMsgUnknown = "";
our $consoleurl = undef;
our $final_exit_code = undef;

#Exit Codes
$OK       = 0;
$WARNING  = 1;
$CRITICAL = 2;
$UNKNOWN  = 3;

# Error Code for Nagios Number to String 
%Nagios_ExitStatus_String_mapping = (
    $OK         => 'OK',
    $WARNING    => 'WARNING',
    $CRITICAL   => 'CRITICAL',
    $UNKNOWN    => 'UNKNOWN',
);

# SNMP status from dell agents
%snmp_status = (
	1  => $UNKNOWN,
	2  => $UNKNOWN,
	3  => $OK,
	4  => $WARNING,
	5  => $CRITICAL,
	6  => $CRITICAL,
	7  => $WARNING,
	8  => $CRITICAL,
	9  => $CRITICAL,
	10 => $CRITICAL,
);

#############################################################
#  Memory related OID and enums 
############################################################
our %mem_oid
      = (
        '.1.3.6.1.4.1.674.10892.5.4.1100.50.1.26'   =>'FQDD',
        '.1.3.6.1.4.1.674.10892.5.4.1100.50.1.5'    =>'Status',
        '.1.3.6.1.4.1.674.10892.5.4.1100.50.1.4'    =>'State',
        '.1.3.6.1.4.1.674.10892.5.4.1100.50.1.14'   =>'Size(GB)',
        '.1.3.6.1.4.1.674.10892.5.4.1100.50.1.15'   =>'Speed(MHz)',
        '.1.3.6.1.4.1.674.10892.5.4.1100.50.1.7'    =>'Type',
        '.1.3.6.1.4.1.674.10892.5.4.1100.50.1.22'   =>'PartNumber',
    );

our %mem_overalloid = (
        '.1.3.6.1.4.1.674.10892.5.4.200.10.1.27.1' => 'OverallStatus'
        );

our %mem_StateSetting_map = (
        0 => 'Disabled',
        1 => 'Unknown',
        2 => 'Enabled',
        4 => 'Not Ready',
        6 => 'Enabled Not Ready',
    );

our %mem_Type_Map = (
        1  => 'Other', 
        2  => 'Unknown',
        3  => 'DRAM', 
        4  => 'EDRAM', 
        5  => 'VRAM', 
        6  => 'SRAM', 
        7  => 'RAM', 
        8  => 'ROM', 
        9  => 'FLASH', 
        10 => 'EEPROM', 
        11 => 'FEPROM', 
        12 => 'EPROM', 
        13 => 'CDRAM', 
        14 => '3DRAM', 
        15 => 'SDRAM', 
        16 => 'SGRAM', 
        17 => 'RDRAM', 
        18 => 'DDR', 
        19 => 'DDR2', 
        20 => 'DDR2FBDIMM', 
        24 => 'DDR3', 
        25 => 'FBD2', 
        26 => 'DDR4',
    ); 

our %mem_enums = (
        'State'         => \%mem_StateSetting_map,
        'Type'          => \%mem_Type_Map,
    );

our %complete_mem = (
        'oid'           => \%mem_oid,
        'overalloid'    => \%mem_overalloid,
        'enums'         => \%mem_enums,
		'bitmasks'		=> undef,
    );

#############################################################
#  CPU related OID and enums 
############################################################
our %cpu_oid
      = (
        '.1.3.6.1.4.1.674.10892.5.4.1100.30.1.26'   =>'FQDD',
        '.1.3.6.1.4.1.674.10892.5.4.1100.30.1.23'   =>'Name',
        '.1.3.6.1.4.1.674.10892.5.4.1100.30.1.5'    =>'Status',
        '.1.3.6.1.4.1.674.10892.5.4.1100.30.1.4'    =>'State',
        '.1.3.6.1.4.1.674.10892.5.4.1100.30.1.12'   =>'CurrentSpeed(GHz)',
        '.1.3.6.1.4.1.674.10892.5.4.1100.30.1.17'   =>'CoreCount',
    );

our %cpu_overalloid = (
        '.1.3.6.1.4.1.674.10892.5.4.200.10.1.50.1' => 'OverallStatus'
    );
 
our %cpu_enums = (
        'State' => \%mem_StateSetting_map,
    );

our %complete_cpu = (
        'oid'               => \%cpu_oid,
        'overalloid'        => \%cpu_overalloid,
        'enums'             => \%cpu_enums,
		'bitmasks'		    => undef,
    );

#############################################################
#  Physical Disk related OID and enums 
############################################################
our %phydisk_oid = (
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.55'    =>'FQDD',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.24'    =>'Status',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.4'     =>'State',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.6'     =>'ProductID',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.7'     =>'SerialNo',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.11'    =>'Size(GB)',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.35'    =>'MediaType',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.19'    =>'FreeSpace(GB)',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.8'     =>'FirmwareVersion',
    );

our %phydisk_overalloid = (
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.24' => 'OverallStatus'
    );

our %phydisk_MediaType = (
        1 => 'Unknown',
        2 => 'HDD',
        3 => 'SSD',
    );

our %State_map = (
        1 => 'Unknown',
        2 => 'Ready',
        3 => 'Online',
        4 => 'Foreign',
        5 => 'Offline',
        6 => 'Blocked',
        7 => 'Failed',
        8 => 'Non-RAID',
        9 => 'Removed',
    );

our %phydisk_enums = (
        'State'     => \%State_map,
        'MediaType' => \%phydisk_MediaType,
    );

our %complete_phydisk = (
        'oid'           => \%phydisk_oid,
        'overalloid'    => \%phydisk_overalloid,
        'enums'         => \%phydisk_enums,
		'bitmasks'		=> undef,
    );

#############################################################
# Virtual Disk related OID and enums 
############################################################
our %virdisk_oid = (
        '.1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1.36'    =>'FQDD',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1.4'     =>'State',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1.6'     =>'Size(GB)',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1.10'    =>'WritePolicy',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1.11'    =>'ReadPolicy',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1.13'    =>'Layout',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1.14'    =>'StripeSize',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1.20'    =>'Status',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1.33'    =>'MediaType',
    );

our %WritePolicy = (
        1 => 'Write Through',
        2 => 'Write Back',
        3 => 'Write Back Force',
    );

our %ReadPolicy = (
        1 => 'No Read Ahead',
        2 => 'Read Ahead',
        3 => 'Adaptive Read Ahead',
    );

our %Virdisk_State = (
        1 => 'Unknown',
        2 => 'Online',
        3 => 'Failed',
        4 => 'Degraded',
    );

our %Vir_layout = (
        1  => 'Other',
        2  => 'RAID-0',
        3  => 'RAID-1',
        4  => 'RAID-5',
        5  => 'RAID-6',
        6  => 'RAID-10',
        7  => 'RAID-50',
        8  => 'RAID-60',
        9  => 'ConcatRAID-1',
        10 => 'ConcatRAID-5',
    );

our %Vir_diskStripSize = (
        1   => 'Other',
        2   => 'Default',
        3   => '512B',
        4   => '1KB',
        5   => '2KB',
        6   => '4KB',
        7   => '8KB',
        8   => '16KB',
        9   => '32KB',
        10  => '64KB',
        11  => '128KB',
        12  => '256KB',
        13  => '512KB',
        14  => '1MB',
        15  => '2MB',
        16  => '4MB',
        17  => '8MB',
        18  => '16MB',
    );

our %virdisk_enums = (
        'WritePolicy'       => \%WritePolicy,
        'ReadPolicy'        => \%ReadPolicy,
        'Status'            => \%snmp_status,
        'State'             => \%Virdisk_State,
        'Layout'            => \%Vir_layout,
        'StripeSize'        => \%Vir_diskStripSize,
    );

our %complete_virdisk = (
        'oid'               => \%virdisk_oid,
        'overalloid'        => undef,
        'enums'             => \%virdisk_enums,
		'bitmasks'		    => undef,
    );

#############################################################
#  Battery related OID and enums 
############################################################
our %battery_oid = (
        '.1.3.6.1.4.1.674.10892.5.4.600.50.1.4'    =>'State',
        '.1.3.6.1.4.1.674.10892.5.4.600.50.1.5'    =>'Status',
        '.1.3.6.1.4.1.674.10892.5.4.600.50.1.6'    =>'Reading',
        '.1.3.6.1.4.1.674.10892.5.4.600.50.1.7'    =>'Location',
    );

our %battery_overalloid = (
        '.1.3.6.1.4.1.674.10892.5.4.200.10.1.52.1' => 'OverallStatus'
    );

our %battery_Reading = (
		0 => '[Absent]',
        1 => '[Predictive Failure]',
        2 => '[Failed]',
        4 => '[Presence Detected]',
    );

our %battery_enums = (
        'State'         => \%mem_StateSetting_map,
    );

our %battery_supply_bitmasks =
	(
		'Reading'  => \%battery_Reading,
	);
	
our %complete_battery = (
        'oid'           => \%battery_oid,
        'overalloid'    => \%battery_overalloid,
        'enums'         => \%battery_enums,
		'bitmasks'		=> \%battery_supply_bitmasks,
    );


#############################################################
#  Amperage related OID and enums 
############################################################
our %amperage_oid = (
        '.1.3.6.1.4.1.674.10892.5.4.600.30.1.8'    =>'Location',
        '.1.3.6.1.4.1.674.10892.5.4.600.30.1.5'    =>'Status',
        '.1.3.6.1.4.1.674.10892.5.4.600.30.1.4'    =>'State',
        '.1.3.6.1.4.1.674.10892.5.4.600.30.1.7'    =>'Type',
        '.1.3.6.1.4.1.674.10892.5.4.600.30.1.6'    =>'ProbeReading',
        '.1.3.6.1.4.1.674.10892.5.4.600.30.1.16'   =>'Reading',
    );

our %amperage_overalloid = (
        '.1.3.6.1.4.1.674.10892.5.4.200.10.1.15.1' => 'OverallStatus'
    );

our %amperage_Reading = (
        1 => 'Good',
        2 => 'Bad',
    );

our %amperage_enums = (
        'State'         => \%mem_StateSetting_map,
        'Reading'       => \%amperage_Reading,
    );

our %complete_amperage = (
        'oid'           => \%amperage_oid,
        'overalloid'    => \%amperage_overalloid,
        'enums'         => \%amperage_enums,
		'bitmasks'		=> undef,
    );

#############################################################
#  Temperature related OID and enums 
############################################################
our %temperature_oid = (
        '.1.3.6.1.4.1.674.10892.5.4.700.20.1.8'     =>'Location',
        '.1.3.6.1.4.1.674.10892.5.4.700.20.1.5'     =>'Status',
        '.1.3.6.1.4.1.674.10892.5.4.700.20.1.4'     =>'State',
        '.1.3.6.1.4.1.674.10892.5.4.700.20.1.6'     =>'Reading(degree Celsius)',
        '.1.3.6.1.4.1.674.10892.5.4.700.20.1.16'    =>'Reading',
    );

our %temperature_overalloid = (
        '.1.3.6.1.4.1.674.10892.5.4.200.10.1.24.1' => 'OverallStatus'
    );

our %temperature_DiscreteReading = (
        1   =>  'Good', 
        2   =>  'Bad',
    );

our %temperature_enums = (
        'State'    => \%mem_StateSetting_map,
        'Reading'  => \%temperature_DiscreteReading,
    );

our %complete_temperature = (
        'oid'           => \%temperature_oid,
        'overalloid'    => \%temperature_overalloid,
        'enums'         => \%temperature_enums,
		'bitmasks'		=> undef,
    );

#############################################################
#  Voltage related OID and enums 
############################################################
our %voltage_oid = (
        '.1.3.6.1.4.1.674.10892.5.4.600.20.1.4'     =>  'State',
        '.1.3.6.1.4.1.674.10892.5.4.600.20.1.8'     =>  'Location',
        '.1.3.6.1.4.1.674.10892.5.4.600.20.1.5'     =>  'Status',
        '.1.3.6.1.4.1.674.10892.5.4.600.20.1.6'     =>  'Reading(V)',
        '.1.3.6.1.4.1.674.10892.5.4.600.20.1.16'    =>  'Reading',
    );

our %voltage_overalloid = (
        '.1.3.6.1.4.1.674.10892.5.4.200.10.1.12.1' => 'OverallStatus'
    );

our %voltage_ProbeDiscreteReading = (
        1   => 'Good',
        2   => 'Bad',
    );

our %voltage_enums = (
        'State'    => \%mem_StateSetting_map,
        'Reading'  => \%voltage_ProbeDiscreteReading,
    );

our %complete_voltage = (
        'oid'           => \%voltage_oid,
        'overalloid'    => \%voltage_overalloid,
        'enums'         => \%voltage_enums,
		'bitmasks'		=> undef,
    );

#############################################################
#  Intrusion related OID and enums 
############################################################
our %intrusion_oid = (
        '.1.3.6.1.4.1.674.10892.5.4.300.70.1.8'     =>  'Location',
        '.1.3.6.1.4.1.674.10892.5.4.300.70.1.7'     =>  'Type',
        '.1.3.6.1.4.1.674.10892.5.4.300.70.1.6'     =>  'Reading',
        '.1.3.6.1.4.1.674.10892.5.4.300.70.1.5'     =>  'Status',
        '.1.3.6.1.4.1.674.10892.5.4.300.70.1.4'     =>  'State',
    );

our %intrusion_overalloid = (
        '.1.3.6.1.4.1.674.10892.5.4.200.10.1.30.1' => 'OverallStatus'
    );

our %intrusion_Type = (
        1   =>  'Chassis Breach Detection when Power ON', 
        2   =>  'Chassis Breach Detection when Power OFF',
    );

our %intrusion_Reading = (
        1   =>  'Chassis not Breached', 
        2   =>  'Chassis Breached', 
        3   =>  'Chassis Breached Prior', 
        4   =>  'Chassis Breach Sensor Failure',
    );

our %intrusion_enums = (
        'State'    => \%mem_StateSetting_map,
        'Type'     => \%intrusion_Type,
        'Reading'  => \%intrusion_Reading,
    );

our %complete_intrusion = (
        'oid'           => \%intrusion_oid,
        'overalloid'    => \%intrusion_overalloid,
        'enums'         => \%intrusion_enums,
		'bitmasks'		=> undef,
    );



#############################################################
# Fan related OID and enums 
#############################################################

our %cooling_device_oid =
    (
        '.1.3.6.1.4.1.674.10892.5.4.700.12.1.8'  => 'FQDD',
        '.1.3.6.1.4.1.674.10892.5.4.700.12.1.5'  => 'Status',
        '.1.3.6.1.4.1.674.10892.5.4.700.12.1.4'  => 'State',
        '.1.3.6.1.4.1.674.10892.5.4.700.12.1.6'  => 'Speed(RPM)',
        '.1.3.6.1.4.1.674.10892.5.4.700.12.1.18' => 'Reading',
    );
    
our %cooling_device_dis_reading =
    (
        1 => 'Good', 
        2 => 'Bad', 
    );
    
our %cooling_devide_enums =
    (
        'State'   => \%mem_StateSetting_map,
        'Reading' => \%cooling_device_dis_reading,
    );
our %cooling_device_overalloid =
    (
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.21.1' => 'systemStateCoolingDeviceStatusCombined', 
    );
our %complete_cooling_device =
    (
        'oid'         => \%cooling_device_oid,
        'overalloid'  => \%cooling_device_overalloid,
        'enums'       => \%cooling_devide_enums,
		'bitmasks'		=> undef,
    );

#############################################################
# Power Supply related OID and enums 
#############################################################    

our %power_supply_oid =
    (
        '.1.3.6.1.4.1.674.10892.5.4.600.12.1.15'    => 'FQDD',
        '.1.3.6.1.4.1.674.10892.5.4.600.12.1.5'     => 'Status',
        '.1.3.6.1.4.1.674.10892.5.4.600.12.1.6'     => 'OutputWattage(W)',
        '.1.3.6.1.4.1.674.10892.5.4.600.12.1.16'    => 'InputVoltage(V)',
        '.1.3.6.1.4.1.674.10892.5.4.600.12.1.14'    => 'InputWattage(W)',
        '.1.3.6.1.4.1.674.10892.5.4.600.12.1.3'     => 'CapabilitiesState',
        '.1.3.6.1.4.1.674.10892.5.4.600.12.1.11'    => 'SensorState',
    );

our %power_supply_state_cap =
    (
        0 => '[No Power Supply State]',
        1 => '[Unknown]', 
        2 => '[Online Capable]', 
        4 => '[Not Ready Capable]',
    );


our %power_supply_sensor_state = 
	(
        1  =>   '[Presence Detected]', 
        2  =>   '[PS Failure Detected]',
        4  =>   '[Predictive Failure]', 
        8  =>   '[PS AC Lost]',
        16 =>   '[AC Lost or Out of Range]', 
        32 =>   '[AC Out of Range but Present]', 
        64 =>   '[Configuration Error]',
	);
	
our %power_supply_bitmasks =
	(
		'SensorState'  => \%power_supply_sensor_state,
		'CapabilitiesState' => \%power_supply_state_cap,
	);
    
our %power_supply_overalloid =
    (
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.9.1'  => 'systemStatePowerSupplyStatusCombined',
    );
    
our %complete_power_supply =
    (
        'oid'           => \%power_supply_oid,
        'overalloid'    => \%power_supply_overalloid,
        'enums'         => undef,
		'bitmasks'		=> \%power_supply_bitmasks,
    );
    
#############################################################
# Disk Controller related OID and enums 
#############################################################

our %controller_oid = 
    (
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.1.1.79' => 'FQDD',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.1.1.2'  => 'Name',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.1.1.38' => 'Status',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.1.1.8'  => 'FirmwareVersion',
        '.1.3.6.1.4.1.674.10892.5.5.1.20.130.1.1.9'  => 'CacheSize(MB)',
    );
    
our %complete_controller =
    (
        'oid'         => \%controller_oid,
        'overalloid' => undef,
    );  'enums'         => undef,

#############################################################
# Network Device related OID and enums 
#############################################################    

our %network_device_oid =
    (
        '.1.3.6.1.4.1.674.10892.5.4.1100.90.1.30' => 'FQDD',
        '.1.3.6.1.4.1.674.10892.5.4.1100.90.1.4'  => 'ConnectionStatus',
        '.1.3.6.1.4.1.674.10892.5.4.1100.90.1.6'  => 'Name',
    );
    
our %network_device_connection_status =
    (
        1  => 'Connected',
        2  => 'Disconnected', 
        3  => 'Driver Bad',
        4  => 'Driver Disabled', 
        10 => 'Hardware Initalizing', 
        11 => 'Hardware Resetting', 
        12 => 'Hardware Closing', 
        13 => 'Hardware Not Ready',
    );
    
our %network_device_enums =
    (
        'ConnectionStatus'  => \%network_device_connection_status,
    );
        
our %complete_network_device =
    (
        'oid'           => \%network_device_oid,
        'overalloid'    => undef,
        'enums'         => \%network_device_enums,
		'bitmasks'		=> undef,
    );    
############################################################
# Server Info
############################################################

#iDRAC server inventory OIDs and corresponding display names
our %idrac_oid = (
        '1.3.6.1.4.1.674.10892.5.1.1.8' =>'Firmware Version',
        '1.3.6.1.4.1.674.10892.5.1.3.1' =>'FQDN Name',
        '1.3.6.1.4.1.674.10892.5.1.3.2' =>'Service Tag',
        '1.3.6.1.4.1.674.10892.5.1.3.6' =>'OS Name',
        '1.3.6.1.4.1.674.10892.5.1.3.14' =>'OS Version',
        '1.3.6.1.4.1.674.10892.5.1.3.12' =>'Model Name',
        '1.3.6.1.4.1.674.10892.5.1.1.2'  =>'Device Type',
        '1.3.6.1.4.1.674.10892.5.1.2.1' =>'Chassis Tag',
        '1.3.6.1.4.1.674.10892.5.1.3.18' =>'Node ID',
        '1.3.6.1.4.1.674.10892.5.1.1.7' => 'RAC Type',
    );

sub get_Server_Info {

    snmp_initialize();
    my $snmpStatus = "true";
    my $finalString  = undef;
    my $outPutLength;
    my $tmpoidresult;
    my $tmpractypeoid = "1.3.6.1.4.1.674.10892.5.1.1.7.0";
    my $racTypeModularFlag = "Not Available";
    my  $result = $snmp_session->get_entries(-columns => [keys %idrac_oid]) or $snmpStatus = "false";
    if($snmpStatus eq "false")
    {
        print "ERROR: Failed to establish SNMP session";
        log_msg("ERROR: Failed to establish SNMP session\n");
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }		
        exit $UNKNOWN;
    }
    if (!defined $result) {
        printf "ERROR: SNMP session error: ";
        log_msg("ERROR: $snmp_session->error\n");
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
        exit $UNKNOWN;
    } else {
        my $tempoid = undef;
        my $flag = 0;
        log_msg("INFO: Success in getting value from Dell agent.\n");
        foreach my $resultoid (keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq $tmpractypeoid ) && (length($result->{$resultoid}) != 0)) {
                my $tmpractype = $result->{$tmpractypeoid};
                if( ($tmpractype == 17 ) || ($tmpractype == 33 ) || ($tmpractype == 49 )){
                    $racTypeModularFlag = "Modular";
                    log_msg("INFO: Its a Modular server \n");
                
                } 
                elsif ( ($tmpractype == 16 ) || ($tmpractype == 32 ) ||  ($tmpractype == 48 ) ||($tmpractype == 21 ) || ($tmpractype == 34 ) || ($tmpractype == 50 )){
                    $racTypeModularFlag = "Monolithic";
                    log_msg("INFO: Its a Monolithic server \n");
                }
            }
        }


        foreach my $resultoid ( keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.3.1.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "Server Host FQDN = $result->{$resultoid}$nextline";
                $flag = 1;
                delete $result->{$resultoid};
                last;
            }
        }
        if ($flag != 1){
            $finalString = $finalString .  "Server Host FQDN = Not Available$nextline"; 
        }
		$flag = 0;

        foreach my $resultoid (keys  %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.3.12.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "Model Name = $result->{$resultoid}$nextline";
                $flag = 1;
                delete $result->{$resultoid};
                last;
            }
        }

        if ($flag != 1){
            $finalString = $finalString .  "Model Name = Not Available$nextline";
           }
		$flag = 0;

        foreach my $resultoid ( keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.1.2.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "Device Type = $result->{$resultoid}$nextline";
                delete $result->{$resultoid};
                $flag = 1;
                last;
            }
        }

        if ($flag != 1){
            $finalString = $finalString .  "Device Type = Not Available$nextline";
           }
		$flag = 0;

        my $service_tag = undef;
        foreach my $resultoid (keys  %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.3.2.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "Service Tag = $result->{$resultoid}$nextline";
                $service_tag = $result->{$resultoid};
                delete $result->{$resultoid};
                $flag = 1;
                last;
            } 
        }

        if ($flag != 1){
            $finalString = $finalString .  "Service Tag = Not Available$nextline";
           }
		$flag = 0;


        foreach my $resultoid ( keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.3.18.0") && 
                (length($result->{$resultoid}) != 0 ) &&  
                ($result->{$resultoid} ne $service_tag)){
                $finalString =  $finalString . "Node Id = $result->{$resultoid}$nextline";
                delete $result->{$resultoid};
                $flag = 1;
                last;
            } 
        }

		$flag = 0;

        $finalString = $finalString . "Product Type = $racTypeModularFlag$nextline";  
		
		if ($racTypeModularFlag eq "Modular")  
		{
			foreach my $resultoid (keys  %{$result}) {
				$tempoid = $resultoid;
				$tempoid =~ s/^\s+|\s+$//g;
				if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.2.1.0") && 
					(length($result->{$resultoid}) != 0 )) {
					$finalString =  $finalString . "Chassis Tag = $result->{$resultoid}$nextline";
					delete $result->{$resultoid};
					$flag = 1;
					last;
				} 
			}

			if ($flag != 1) {
				$finalString = $finalString .  "Chassis Tag = Not Available$nextline";
			}
			
			$flag = 0;
        }
		
        foreach my $resultoid ( keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.1.8.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "iDRAC Firmware Version = $result->{$resultoid}$nextline";
                delete $result->{$resultoid};
                $flag = 1;
                last;
            } 
        }

        if ($flag != 1) {
            $finalString = $finalString .  "iDRAC Firmware Version = Not Available$nextline";
           }
		$flag = 0;

        foreach my $resultoid (keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.3.6.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "OS Name = $result->{$resultoid}$nextline";
                delete $result->{$resultoid};
                $flag = 1;
                last;
            }
        }

        if ($flag != 1) {
            $finalString = $finalString .  "OS Name = Not Available$nextline";
           }
		$flag = 0;

        foreach my $resultoid ( keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.3.14.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "OS Version = $result->{$resultoid}$nextline";
                delete $result->{$resultoid};
                $flag = 1;
                last;
            } 
       }

        if ($flag != 1) {
            $finalString = $finalString .  "OS Version = Not Available$nextline";
           }
		$flag = 0;

        $finalString =  $finalString . "iDRAC URL = $consoleurl";
		$flag = 0;


		
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
        print "$finalString";
		exit $OK;
    }
}

#############################################################
# ghs  related OID and enums 
#############################################################
our %ghs_overalloid = (
        '1.3.6.1.4.1.674.10892.5.2.1.0'             => 'globalSystemStatus',                      # overall system health status
    );

our %complete_ghs = (
        'oid'            => undef,
        'overalloid'     => \%ghs_overalloid,
        'enums'          => undef,
    );

# tabular OIDs 
our %ghs_details_oid = 
    (
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.4'  => 'systemStateChassisStatus',                      # chassis status
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.9'  => 'systemStatePowerSupplyStatusCombined',          # Power supply status
		'1.3.6.1.4.1.674.10892.5.4.200.10.1.27' => 'OverallStatus',			                        # memory overall status 
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.12' => 'systemStateVoltageStatusCombined',              # voltage combined status
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.15' => 'systemStateAmperageStatusCombined',             # amperage combined status
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.21' => 'systemStateCoolingDeviceStatusCombined',        # cooling device combined status
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.24' => 'systemStateTemperatureStatusCombined',          # Temprature combined status
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.30' => 'systemStateChassisIntrusionStatusCombined',     # chassis intrusion combined status
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.42' => 'systemStatePowerUnitStatusCombined',            # power unit combined status
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.44' => 'systemStateCoolingUnitStatusCombined',          # colling unit combined status 
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.50' => 'systemStateProcessorDeviceStatusCombined',      # processor combined status
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.52' => 'systemStateBatteryStatusCombined',              # battery combined status
        #'1.3.6.1.4.1.674.10892.5.4.200.10.1.54' => 'systemStateSDCardUnitStatusCombined',           # SDCard unit combined status
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.56' => 'systemStateSDCardDeviceStatusCombined',         # SDCard Device combined status
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.58' => 'systemStateIDSDMCardUnitStatusCombined',        # IDSDM Card Unit Combined Status
        '1.3.6.1.4.1.674.10892.5.4.200.10.1.60' => 'systemStateIDSDMCardDeviceStatusCombined',      # IDSDM Card Device combined status

    );
  
# scalar OIDs
our %ghs_scalar_oid = 
    (
        '1.3.6.1.4.1.674.10892.5.2.1.0'         => 'globalSystemStatus',                        # overall system health status
        '1.3.6.1.4.1.674.10892.5.2.3.0'         => 'globalStorageStatus',                       # Storage global system
    );
    
# resultant OIDs
our %ghs_oid_name_mapping
      = (
       "1.3.6.1.4.1.674.10892.5.2.1.0"           => "OverallSystem",            # overall system health status
       "1.3.6.1.4.1.674.10892.5.2.3.0"           => "Storage",                  # Storage global system
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.4.1"  => "Chassis",                  # chassis status
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.9.1"  => "Power Supply",             # Power supply status
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.12.1" => "Voltage",                  # voltage combined status
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.15.1" => "Amperage",                 # amperage combined status
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.21.1" => "Fan",                      # cooling device combined status
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.24.1" => "Temperature",              # Temperature combined status
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.30.1" => "Chassis Intrusion",        # chassis intrusion combined status
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.42.1" => "Power Unit",               # power unit combined status
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.44.1" => "Cooling Unit",             # cooling unit combined status
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.50.1" => "Processor",                # processor combined status
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.52.1" => "Battery",                  # battery combined status
       #"1.3.6.1.4.1.674.10892.5.4.200.10.1.54.1" => "SD Card Unit",             # SDCard unit combined status
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.56.1" => "SD Card Device",           # SDCard Device combined status
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.58.1" => "IDSDM Card Unit",          # IDSDM Card Unit Combined Status
       "1.3.6.1.4.1.674.10892.5.4.200.10.1.60.1" => "IDSDM Card Device",        # IDSDM Card Device combined status
	   "1.3.6.1.4.1.674.10892.5.4.200.10.1.27.1" => "Memory",			        # memory overall status 

    );
 
    
###############################################################

# All Oid in a hash with its references.

our %main_oid = (
        'memory'        => \%complete_mem,
        'cpu'           => \%complete_cpu,
        'phydisk'       => \%complete_phydisk,
        'virdisk'       => \%complete_virdisk,
        'ghs'           => \%complete_ghs,
        'battery'       => \%complete_battery,
        'temperature'   => \%complete_temperature,
        'voltage'       => \%complete_voltage,
        'intrusion'     => \%complete_intrusion,
        'fan'           => \%complete_cooling_device,
        'ps'            => \%complete_power_supply,
        'ctl'           => \%complete_controller,
        'nic'           => \%complete_network_device,
        'amperage'      => \%complete_amperage,
    );

###############################################################

# Help text
$HELP = <<'END_HELP';
Usage: dell_check_idrac.pl -H <HOSTNAME> [OPTION]...

OPTIONS:
    -i, --item          Component name.
OPTIONAL:
    -h, --help          Display this help text
    -F, --file          Host configuration file with absolute path 
    -s, --servicename   Service name.
END_HELP

# Options with default values
%opt = (
    'hostname'     => undef,
    'filepath'     => undef,
    'help'         => 0,
    'component'    => undef,
    'opt_log'      => 0,
    'service'      => undef,
    
);

# Get options
GetOptions( 
    'H|hostname=s'      => \$opt{hostname},
    'F|file=s'          => \$opt{filepath},
    'h|help'            => \$opt{help},
    'i|item=s'          => \$opt{component},
    'l|log=i'           => \$opt{opt_log},
    's|servicename=s'   => \$opt{servicename},
) or do { 
    print $HELP; 
    exit $UNKNOWN; 
};


# If user requested help
if ($opt{'help'}) {
    print $HELP;
    exit $OK;
}


# Error if hostname option is not present
if ((!defined $opt{hostname}) and (!defined $opt{component}) )  {
    print $HELP;
    exit $UNKNOWN;
}

# Default line break
$nextline = '<br>';

my $tm = localtime(time);
my $tm_month = sprintf "%02d",$tm->mon + 1;
my $tm_day = sprintf "%02d",$tm->mday;
my $tm_year = $tm->year + 1900;

my ($volume, $directory, $file) = File::Spec->splitpath(__FILE__);

our $opt_logfile = undef;
our $nagioshomedir = undef;
my $config_cfg_path = $directory . "dellconfig.cfg";
if(-e $config_cfg_path) {
    my $log_path = undef;
    my $row = undef;
    if(open(my $fh,"<" , $config_cfg_path)) {
        while ($row  =  <$fh> ){
            chomp $row;
            if(index($row, "NAGIOS_HOME") != -1){
            $row =~ s/\s//g;
            $nagioshomedir = substr($row,12);
            last;
            }
        }
        $log_path = $nagioshomedir . "/var/dell/";
        if(!( -d $log_path )) {
            system ("mkdir -p $log_path");
        }
        $opt_logfile = $log_path . "AgentfreeServerServices_" . $tm_year . $tm_month  . $tm_day . ".dbg";
    } 
}
 
#---------------------------------------------------------------------
# Functions
#---------------------------------------------------------------------

##################################################################
# Func: snmp_initialize 
# Input: No input
# outout: No Output
# Description :  This function intializes the snmp session object
#                which will be used for making snmp querries. 
##################################################################
sub snmp_initialize {
    my $temp_community;
    my %param
      = (
     '-hostname'    => $opt{hostname},
     '-version'     => 2,
     '-community'   => 'public',
     '-port'        => 161,
     '-timeout'     => 3,
     '-retries'     => 1,
     '-domain'        => 'UDP/IPv4',
    );

    my $filename = undef;
    my @snmp_params;
    # Parameters to Net::SNMP->session()


    if (defined $opt{'filepath'}) {
        $filename = $opt{'filepath'};
    }elsif(defined $opt{servicename}){
        my $file_check  = $nagioshomedir . "/dell/config/objects/" . $opt{hostname} . ".cfg";
        if( -e $file_check) {
            $filename = $file_check;
        } else {
				if (eval { require  Socket; 1}) { 
						require  Socket;
                    } 
				else{ 
                         log_msg("ERROR: Required perl module Socket not found."); 
                         print "ERROR: Required perl module Socket not found\n"; 
                         exit $UNKNOWN;
                    }
            my $fqdnName = gethostbyaddr(inet_aton("$opt{hostname}"), AF_INET);
            $file_check = $nagioshomedir . "/dell/config/objects/" . $fqdnName . ".cfg";
            if ( -e $file_check) {
                $filename = $file_check;
            }
        }
    }
 
    my $row_counter = 0;
    if (defined $filename){   
        if(open(my $fh, "<", $filename) ) {
            log_msg("INFO ", "Success in opening the file $filename\n");
            while (my $row = <$fh>) {
                chomp $row;
                if(index($row, "action_url") != -1){
                    $row =~ s/\s//g;
                    $row = substr($row,length("action_url"));
                    $consoleurl = $row; 
                    $row_counter = $row_counter + 1 ;
                } elsif (index($row, "_dell_comm_params") != -1){
                    $row =~ s/\s//g;
                    $row = substr($row,17);
                    @snmp_params = split(',',$row);
                    $row_counter = $row_counter + 1 ;
                }
                
                if( $row_counter == 2 ){
                    last;
                }
            }
            if ($snmp_params[0] eq 'SNMP') {
                $temp_community = $snmp_params[1];
                $param{'-version'}   = $snmp_params[2];
                $param{'-timeout'}   = $snmp_params[3];
                $param{'-retries'}   = $snmp_params[4];
                $param{'-port'}      = $snmp_params[5];
                $param{'-domain'}    = $snmp_params[6];
			} else {
                print "CRITICAL: Internal Error - Invalid snmp params\n";
                log_msg("CRITICAL", "Internal Error - Invalid snmp params\n");
                exit $UNKNOWN;
            }
			
			if ($param{'-domain'} eq "UDP/IPv6"){
				if (eval { require  Socket6; 1}) { 
						require  Socket6;
                     } 
				else { 
                         log_msg("ERROR: Required perl module Socket6 not found."); 
                         print "ERROR: Required perl module Socket6 not found\n"; 
                         exit $UNKNOWN;
                     }
            }
            else{
				if (eval { require  Socket; 1}) { 
						require  Socket;
                    } 
				else{ 
                         log_msg("ERROR: Required perl module Socket not found."); 
                         print "ERROR: Required perl module Socket not found\n"; 
                         exit $UNKNOWN;
                    }
            }

            my $resource_file = $nagioshomedir . "/dell/resources/dell_resource.cfg";
            my $name;
            my $value;

            if ( -e $resource_file){
                if(open(my $rfh, "<", $resource_file)){
                    while (my $resource_row = <$rfh> ) {
                        chomp $resource_row;
                        $resource_row =~ s/^\s+|\s+$//g;
                        if ( ($resource_row !~ /^#/) && ($resource_row ne "") ){    # Ignore lines starting with # and blank lines
                            ($name, $value) = split (/=/, $resource_row);          # Split each line into name value pairs
                            $value =~ s/^\s+|\s+$//g;     # Remove spaces at the start of the line
                            $name =~ s/^\s+|\s+$//g;
                            
                            if ($name eq $temp_community){
								if ($value ne ""){
									$param{'-community'} = $value;
								} else {
									print "CRITICAL: Macro $name is not configured in the resource file: $filename\n";
									log_msg("CRITICAL", "Macro $name is not configured in the resource file: $filename\n");
									exit $UNKNOWN;
								}
							}	
                        } 
                    }
			    } else {
					print "CRITICAL: Error in opening resource file: $resource_file\n";
					log_msg("CRITICAL", "Error in opening resource file: $resource_file.\n");
					exit $UNKNOWN;
				}
            } else {
				print "CRITICAL: Missing resource file: $resource_file\n";
				log_msg("CRITICAL", "$resource_file not found.\n");
				exit $UNKNOWN;
			}
			
        } else {
            log_msg("WARNING", "Error in opening the file $filename; Proceeding with default value.\n");
        }
    } else {
        print "CRITICAL: Filepath is invalid : $filename\n";
        log_msg("CRITICAL", "Filepath is invalid : $filename\n");
        exit $UNKNOWN;
    }
     
    my $calculated_timeout = ($param{'-timeout'} * ($param{'-retries'} + 1) + 120);
    $plugin_timeout = $plugin_timeout > $calculated_timeout ? $plugin_timeout: $calculated_timeout ;

    # Parameters for SNMP v2c or v1
    if ($param{'-version'} != 2 and $param{'-version'} != 1) {
        print "SNMP: This Plugin doesn't support SNMP version other than 1 and 2.";
        log_msg ("CRITICAL","SNMP: This Plugin doesn't support SNMP version other than 1 and 2\n");
        exit $UNKNOWN;
    }    

    # Try to initialize the SNMP session
    if (eval {require Net::SNMP; 1}) {
        ($snmp_session, $snmp_error) = Net::SNMP->session( %param );
        if (!defined ($snmp_session)){ 
            print "Error while creating SNMP Session.";
            log_msg("CRITICAL ","Error while creating SNMP Session.");
            exit $UNKNOWN;
        } else {
            log_msg ("INFO","Success in creating the session.\n");
        }
    } else {
        print "ERROR: Package: Required perl module Net::SNMP not found";
        log_msg("CRITICAL","Package: Required perl module Net::SNMP not found");
        exit $UNKNOWN;
    }
    return;
}

##################################################################
# Func: arrange_result
# Input: snmp querry result, all oid hash
# outout: Return a reference of arranged result based on index value.
# Description :  This function takes snmp querry result and all oid 
#                hash reference and return a reference of arranged 
#                hash based on index
##################################################################
sub arrange_result {
    my ($result,$oidref) = @_;
    my %output = ();
    my $tempoid = undef;
    foreach my $refoid (keys %{$oidref}){
        $tempoid = $refoid . '.';
        foreach my $resoid (keys %{$result}){
            if ($resoid =~ /\Q$tempoid\E/) {
                my $key = length($resoid) - length($tempoid);
                my $key1 = substr $resoid,length($tempoid),$key;
                my $value = ($result->{$resoid});
                $value =~ s/^\s+|\s+$//g;
                $output{$key1}{$oidref->{$refoid}} = $value;
            }         
        }
    }
    return \%output;
}

##################################################################
# Func: severity_arrange
# Input: severity name string, arranged snmp result hash 
# outout: Return an array of indexes based on severity.
# Description :  This function takes arranged snmp result hash and return
#                a array of indexes based on severity. 
##################################################################
sub severity_arrange {
    my ($component, $severity_name, $oidref) = @_;
    my @finaloutput = ();
    my $all_ok_index = 0;
    my $all_critical_index = 0;
    my $all_warn_index = 0;
	my $all_unknown_index = 0;


    if ($component eq 'nic'){
        foreach my $refoid (keys %{$oidref}){
            if( $oidref->{$refoid}{$severity_name} == 1) {
                # All Ok status Index[0]
                $oidref->{$refoid}{$severity_name} = 'UP';
                $finaloutput[0][$all_ok_index] = $refoid;
                $all_ok_index = $all_ok_index + 1;
            } else {
                # All CRITICAL Status Index[2]
                $oidref->{$refoid}{$severity_name} = 'DOWN';
                $finaloutput[2][$all_critical_index] = $refoid;
                $all_critical_index = $all_critical_index + 1;
            }
        } 
    } else {
        foreach my $refoid (keys %{$oidref}){
            if( $oidref->{$refoid}{$severity_name} == 3) {
                # All Ok status Index[0]
                $oidref->{$refoid}{$severity_name} = 0;
                $finaloutput[0][$all_ok_index] = $refoid;
                $all_ok_index = $all_ok_index + 1;
            } elsif (($oidref->{$refoid}{$severity_name} == 4) ||
                     ($oidref->{$refoid}{$severity_name} == 7)) {
                # All Wanring Status Index[1] 
                $oidref->{$refoid}{$severity_name} = 1;
                $finaloutput[1][$all_warn_index] = $refoid;
                $all_warn_index = $all_warn_index + 1;
            } elsif (($oidref->{$refoid}{$severity_name} == 5) ||
                     ($oidref->{$refoid}{$severity_name} == 6) || 
					 ($oidref->{$refoid}{$severity_name} == 8) ||
					 ($oidref->{$refoid}{$severity_name} == 9) ||
					 ($oidref->{$refoid}{$severity_name} == 10))
					 {
                # All CRITICAL Status Index[2]
                $oidref->{$refoid}{$severity_name} = 2;
                $finaloutput[2][$all_critical_index] = $refoid;
                $all_critical_index = $all_critical_index + 1;
            } else {
			    # All UNKNOWN Status Index[3]
                $oidref->{$refoid}{$severity_name} = 3;
                $finaloutput[3][$all_unknown_index] = $refoid;
                $all_unknown_index = $all_unknown_index + 1;
			}
        }    
    }
	
    return \@finaloutput;

}

##################################################################
# Func: overall_health_status
# Input: Oid of overallheath status 
# Outout: NO output
# Description :  This function do snmp querry to get overall health 
#                status of the component and exit based on the snmp response.
##################################################################
sub overall_health_status{
    my ($oidref) = @_;
    my $ret =  $snmp_session->get_request(-varbindlist => [keys %{$oidref}]);
    if (!defined $ret) { 
        printf "ERROR: SNMP: %s$nextline ", $snmp_session->error;
        log_msg("CRITICAL","SNMP: %s $snmp_session->error");
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
        exit $UNKNOWN;
    } 
    my $check_ok = 3;
    my $check_unknown = 2;
    my $check_warning = 4;
   
   
   	#1,2  => $UNKNOWN,
	  #3    => $OK,
	  #4    => $WARNING,
	  #5,6  => $CRITICAL,


	
    foreach my  $key (keys %{$ret}) {  
        if ($ret->{$key} == 3) {
            $final_exit_code =  $OK;
        } elsif ( $ret->{$key} == 4) {
            $final_exit_code = $WARNING;
        } elsif( ($ret->{$key} == 5) || ($ret->{$key} == 6)){
            $final_exit_code = $CRITICAL;
        } else {
			$final_exit_code = $UNKNOWN;
		}
    }
}

##################################################################
# Func :         my_printing
# Input:         severity_array, arranged result hash, component name, severity name, 
# Output:        NO output
# Description :  This function prints all the instances of the component 
#                by iterating through the array and hash. 
# 
##################################################################

sub my_printing {
    my ($sevArray, $output, $component,$component_descriptor,$severity_name) = @_;
    my $severity;
    my $severity_index = 0;
    my $enum_bitmask_found = 0;
    my $enum_or_bitmask = 0;
    my $instance_count = 1;
	
    
    for ($severity = 2 ; $severity >= 0; $severity-- ) {
        if (exists $sevArray->[$severity]){
            for ($severity_index = 0 ; exists $sevArray->[$severity][$severity_index]; $severity_index++){
                $printmsg = $printmsg . "#$instance_count ";
                my $print_index_key =  $sevArray->[$severity][$severity_index];
                if ($component eq 'nic'){
                    $printmsg = $printmsg .  "$severity_name = $output->{$print_index_key}->{$severity_name}, ";
                    $printmsg = $printmsg .  "$component_descriptor = $output->{$print_index_key}->{$component_descriptor}, ";

                } else {
                    $printmsg = $printmsg .  "$severity_name = $Nagios_ExitStatus_String_mapping{$output->{$print_index_key}->{$severity_name}}, ";
                    $printmsg = $printmsg .  "$component_descriptor = $output->{$print_index_key}->{$component_descriptor}, ";
                }
                delete $output->{$print_index_key}->{$component_descriptor};
                delete $output->{$print_index_key}->{$severity_name};

                if ( exists ($output->{$print_index_key}->{'State'}) ) {
                    $printmsg = $printmsg . "State = $main_oid{$component}->{'enums'}->{'State'}->{$output->{$print_index_key}->{'State'}}, ";
                    delete $output->{$print_index_key}->{'State'}; 
                } 
                foreach my $output_key (sort keys %{$output->{$print_index_key}}){
	                foreach my $enum_name (keys %{$main_oid{$component}->{'enums'}}){
                        if ($output_key eq $enum_name){     
                            $enum_or_bitmask = 1;
                            if (exists $main_oid{$component}->{'enums'}->{$enum_name}->{$output->{$print_index_key}->{$output_key}}){
                                $printmsg = $printmsg . "$output_key = $main_oid{$component}->{'enums'}->{$enum_name}->{$output->{$print_index_key}->{$output_key}}, ";
                            } else {
                                $printmsg = $printmsg . "$output_key = Other($output->{$print_index_key}->{$output_key}), ";
                            }
                            last;
                        }
                    }
					if ($enum_or_bitmask != 1){

						foreach my $bit_name (keys %{$main_oid{$component}->{'bitmasks'}}){
							if ($output_key eq $bit_name) {
                                $enum_or_bitmask = 1;
								my $number = $output->{$print_index_key}->{$output_key};
								my $counter = 0;
								$printmsg = $printmsg . "$output_key = ";
								# Condition if no bit is SET.
								if ($number == 0){
									if (exists $main_oid{$component}->{'bitmasks'}->{$bit_name}->{$number}) {
										$printmsg = $printmsg . "$main_oid{$component}->{'bitmasks'}->{$bit_name}->{$number}, ";
									} else {
                                        $printmsg = $printmsg . "Other($number), ";
                                    } 
								} else {
									#Finding all the SET bits from the number
                                    my $temp_number = $number;
									while ($number){
										if($number & 1){
                                            my $bitvalue = 2**$counter;
                                            if ( exists $main_oid{$component}->{'bitmasks'}->{$bit_name}->{$bitvalue}){
										        $printmsg = $printmsg . "$main_oid{$component}->{'bitmasks'}->{$bit_name}->{$bitvalue}";
                                                $enum_bitmask_found = 1; # key value found;
                                            }
										}
										$counter = $counter + 1;
										$number = $number >> 1;
									}
                                    if ($enum_bitmask_found != 1){
                                        $printmsg = $printmsg . "Other($temp_number), ";
                                    } else {
								        $printmsg = $printmsg .", ";
                                    }
								}
                                last;
							}
						}
					}
                    if ($enum_or_bitmask != 1){
                        $printmsg = $printmsg . "$output_key = $output->{$print_index_key}->{$output_key}, ";
                    }
                    $enum_bitmask_found = 0;
                    $enum_or_bitmask = 0;
                }

                chop ($printmsg);
                chop ($printmsg);
                $printmsg = $printmsg . $nextline;
                $instance_count = $instance_count + 1;
            }
        }
    }
	
	$severity = 3;
        if (exists $sevArray->[$severity]){
            for ($severity_index = 0 ; exists $sevArray->[$severity][$severity_index]; $severity_index++){
                $printmsg = $printmsg . "#$instance_count ";
                my $print_index_key =  $sevArray->[$severity][$severity_index];
                if ($component eq 'nic'){
                    $printmsg = $printmsg .  "$severity_name = $output->{$print_index_key}->{$severity_name}, ";
                    $printmsg = $printmsg .  "$component_descriptor = $output->{$print_index_key}->{$component_descriptor}, ";

                } else {
                    $printmsg = $printmsg .  "$severity_name = $Nagios_ExitStatus_String_mapping{$output->{$print_index_key}->{$severity_name}}, ";
                    $printmsg = $printmsg .  "$component_descriptor = $output->{$print_index_key}->{$component_descriptor}, ";
                }
                delete $output->{$print_index_key}->{$component_descriptor};
                delete $output->{$print_index_key}->{$severity_name};

                if ( exists ($output->{$print_index_key}->{'State'}) ) {
                    $printmsg = $printmsg . "State = $main_oid{$component}->{'enums'}->{'State'}->{$output->{$print_index_key}->{'State'}}, ";
                    delete $output->{$print_index_key}->{'State'}; 
                } 
                foreach my $output_key (sort keys %{$output->{$print_index_key}}){
	                foreach my $enum_name (keys %{$main_oid{$component}->{'enums'}}){
                        if ($output_key eq $enum_name){     
                            $enum_or_bitmask = 1;
                            if (exists $main_oid{$component}->{'enums'}->{$enum_name}->{$output->{$print_index_key}->{$output_key}}){
                                $printmsg = $printmsg . "$output_key = $main_oid{$component}->{'enums'}->{$enum_name}->{$output->{$print_index_key}->{$output_key}}, ";
                            } else {
                                $printmsg = $printmsg . "$output_key = Other($output->{$print_index_key}->{$output_key}), ";
                            }
                            last;
                        }
                    }
					if ($enum_or_bitmask != 1){

						foreach my $bit_name (keys %{$main_oid{$component}->{'bitmasks'}}){
							if ($output_key eq $bit_name) {
                                $enum_or_bitmask = 1;
								my $number = $output->{$print_index_key}->{$output_key};
								my $counter = 0;
								$printmsg = $printmsg . "$output_key = ";
								# Condition if no bit is SET.
								if ($number == 0){
									if (exists $main_oid{$component}->{'bitmasks'}->{$bit_name}->{$number}) {
										$printmsg = $printmsg . "$main_oid{$component}->{'bitmasks'}->{$bit_name}->{$number}, ";
									} else {
                                        $printmsg = $printmsg . "Other($number), ";
                                    } 
								} else {
									#Finding all the SET bits from the number
                                    my $temp_number = $number;
									while ($number){
										if($number & 1){
                                            my $bitvalue = 2**$counter;
                                            if ( exists $main_oid{$component}->{'bitmasks'}->{$bit_name}->{$bitvalue}){
										        $printmsg = $printmsg . "$main_oid{$component}->{'bitmasks'}->{$bit_name}->{$bitvalue}";
                                                $enum_bitmask_found = 1; # key value found;
                                            }
										}
										$counter = $counter + 1;
										$number = $number >> 1;
									}
                                    if ($enum_bitmask_found != 1){
                                        $printmsg = $printmsg . "Other($temp_number), ";
                                    } else {
								        $printmsg = $printmsg .", ";
                                    }
								}
                                last;
							}
						}
					}
                    if ($enum_or_bitmask != 1){
                        $printmsg = $printmsg . "$output_key = $output->{$print_index_key}->{$output_key}, ";
                    }
                    $enum_bitmask_found = 0;
                    $enum_or_bitmask = 0;
                }

                chop ($printmsg);
                chop ($printmsg);
                $printmsg = $printmsg . $nextline;
                $instance_count = $instance_count + 1;
            }
      }
		
    $printmsg = substr ($printmsg, 0, -4);
}

##################################################################
# Func:         get_Component_Status
# Input:        Component name, Severity name, overall health check flag 
# Output:       No output.
# Description:  Main function which is getting callled by each component
#               and calling other function to display the status 
#               of the component.
##################################################################
sub get_Component_Status {
    my ($component,$component_descriptor, $severity_name,$check_overall_health) = @_;
    my %output = ();
    my @severity_array = ();
    my @ghs_output = ();
    my $result = undef;

    my $oid = $main_oid{$component}->{'oid'};

    $result = $snmp_session->get_entries(-columns => [keys %{$oid}]);
	
	if (!defined $result) {	    
        if($snmp_session->error =~ m/.*message.*size.*exceeded.*buffer.*maxMsgSize*/i){
		    log_msg("WARNING", $snmp_session->error);
            $result = $snmp_session->get_entries(-columns => [keys %{$oid}], -maxrepetitions  => 1,);
        } 
    }
    if (!defined $result) {
        if("The requested entries are empty or do not exist" eq $snmp_session->error){
            print "Component Information = UNKNOWN";
        } else {  
            print "ERROR: SNMP: ", $snmp_session->error;
        }
        log_msg("CRITICAL ", $snmp_session->error);
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
        exit $UNKNOWN;
    } else {
        log_msg("INFO", "Success in getting value from Dell agent.\n");
    }


    if( $component ne "ghs" ){
        %output = %{arrange_result($result, $oid) };
    
        if ($component eq 'amperage'){
            my $temp_reading = undef; 
            foreach my $ampkey (keys %output) { 

		
                if ( ($output{$ampkey}->{'Type'} == 23 ) ||
                     ($output{$ampkey}->{'Type'} == 25 )) {
                     $temp_reading = delete $output{$ampkey}->{'ProbeReading'};
					 if(($output{$ampkey}->{'Status'} == 1) || ($output{$ampkey}->{'Status'} == 2)){
						$output{$ampkey}->{'Reading(A)'} = "Not Available" ;
					 } else {
						$output{$ampkey}->{'Reading(A)'} = $temp_reading / 10 ;
					 }
    
                } elsif (($output{$ampkey}->{'Type'} == 24 ) ||
                         ($output{$ampkey}->{'Type'} == 26)) {
                     $temp_reading = delete $output{$ampkey}->{'ProbeReading'};
					 if(($output{$ampkey}->{'Status'} == 1) || ($output{$ampkey}->{'Status'} == 2)){
						$output{$ampkey}->{'Reading(W)'} = "Not Available" ;
					 } else {
						$output{$ampkey}->{'Reading(W)'} = $temp_reading ;
					 }

                } elsif ($output{$ampkey}->{'Type'} == 16 ) {
					delete $output{$ampkey}->{'Type'};
                    next;

                } else {
                     $temp_reading = delete $output{$ampkey}->{'ProbeReading'};
					 if(($output{$ampkey}->{'Status'} == 1) || ($output{$ampkey}->{'Status'} == 2)){
						$output{$ampkey}->{'Reading(A)'} = "Not Available" ;
					 } else {
						$output{$ampkey}->{'Reading(A)'} = $temp_reading / 1000 ;
					 }
                }
                delete $output{$ampkey}->{'Type'};
            }   

        } elsif ($component eq 'memory'){
            foreach my $memkey (keys %output){
                if (defined $output{$memkey}->{'Size(GB)'}) {
                    $output{$memkey}->{'Size(GB)'} = sprintf '%.2f', $output{$memkey}->{'Size(GB)'} / (1024.0 * 1024);
                }
            }
        } elsif ($component  eq 'phydisk'){
            foreach my $phykey (keys %output){
                if (defined $output{$phykey}->{'Size(GB)'}) {
                    $output{$phykey}->{'Size(GB)'} = sprintf '%.2f', $output{$phykey}->{'Size(GB)'} / (1024.0);
                }
                if (defined $output{$phykey}->{'Size(GB)'}) {
                    $output{$phykey}->{'FreeSpace(GB)'} = sprintf '%.2f', $output{$phykey}->{'FreeSpace(GB)'} / (1024.0);
                }
            }
        } elsif ($component  eq 'virdisk'){
            foreach my $virkey (keys %output){
                if (defined $output{$virkey}->{'Size(GB)'}) {
                    $output{$virkey}->{'Size(GB)'} = sprintf '%.2f', $output{$virkey}->{'Size(GB)'} / (1024.0);
                }
            }
        } elsif ($component  eq 'cpu'){
            foreach my $cpukey (keys %output){
                if (defined $output{$cpukey}->{'CurrentSpeed(GHz)'}) {
                    $output{$cpukey}->{'CurrentSpeed(GHz)'} = sprintf '%.2f', $output{$cpukey}->{'CurrentSpeed(GHz)'} / (1000.0);
                }
            }
        }


        @severity_array = @{severity_arrange($component, $severity_name, \%output)};

        if( ($component eq 'temperature' ) || ( $component eq 'voltage') || ( $component eq 'ps')) {
            foreach my $convertkey ( keys %output) {
                if( exists $output{$convertkey}->{"Reading(V)"}){
                    $output{$convertkey}->{"Reading(V)"} =  $output{$convertkey}->{"Reading(V)"} / 1000;
                } elsif ( exists $output{$convertkey}->{"Reading(degree Celsius)"} ){
                    $output{$convertkey}->{"Reading(degree Celsius)"} = $output{$convertkey}->{"Reading(degree Celsius)"} / 10 ;  
                } elsif ( exists $output{$convertkey}->{"OutputWattage(W)"} ){
                    $output{$convertkey}->{"OutputWattage(W)"} = $output{$convertkey}->{"OutputWattage(W)"} / 10 ;
                } 
                if ( exists $output{$convertkey}->{"InputWattage(W)"} ){
                    $output{$convertkey}->{"InputWattage(W)"} = $output{$convertkey}->{"InputWattage(W)"} / 10 ;
                }   
            }
        }
        my_printing(\@severity_array,\%output, $component,,$component_descriptor, $severity_name);
    }
    
    if($check_overall_health == 0 ) {    
        overall_health_status($main_oid{$component}->{'overalloid'});
    } elsif ($check_overall_health == 1) {
        if(defined $severity_array[2][0]){
            $final_exit_code = $CRITICAL;
        } elsif (defined  $severity_array[1][0]) {
            $final_exit_code = $WARNING;
        } elsif (defined  $severity_array[0][0]) {
            $final_exit_code = $OK;
        } else {
			#Set exit code UNKNOWN
            $final_exit_code = 3;
        }
    }
    if(defined $opt{servicename}){
        my $command = $nagioshomedir . "/libexec/eventhandlers/submit_check_result " . $opt{hostname} . q{ } .$opt{servicename} . q{ } . $final_exit_code . q{ } . "\"" . $printmsg . "\"";
        system($command);
    } else {
        print $printmsg;
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
        exit $final_exit_code;
    }
}



############################################################
# retreive and sort the overall health and component 
# health status returned from get_entries()
############################################################
sub retreive_ghs_cmpnt_value {

    my ($table_result,$scalar_result) = @_;
    my $allresult = {%$table_result , %$scalar_result};
    my @output = ();
    my $tempresultoid = undef;
	
	my $tempoid = "1.3.6.1.4.1.674.10892.5.2.1.0";
    foreach my $sclresultoid (keys  %{$scalar_result}) {
        $tempresultoid = $sclresultoid;
        $tempresultoid =~ s/^\s+|\s+$//g;
        if (($tempresultoid eq $tempoid) && ($scalar_result->{$sclresultoid} > 0) ){
            $printmsg = $printmsg .  "Overall System = $Nagios_ExitStatus_String_mapping{$snmp_status{$scalar_result->{$sclresultoid}}} $nextline";
            $final_exit_code = $snmp_status{$scalar_result->{$sclresultoid}};
            delete $allresult->{$sclresultoid};
            last;
        }
    }
	
    foreach my $resultoid (keys  %{$allresult}) {
        foreach my $ghsoid (keys  %ghs_oid_name_mapping ){

            $tempresultoid = $resultoid;
            $tempresultoid =~ s/^\s+|\s+$//g;
            #if ( (index ($resultoid, $ghsoid) != -1 ) and ( $allresult->{$resultoid} > 0 )) {
		    if ( ($tempresultoid eq $ghsoid ) and ( $allresult->{$resultoid} > 2))  {
				
                push @output,{name => $ghs_oid_name_mapping{$ghsoid}, Status => $snmp_status{$allresult->{$resultoid}}};
                delete $ghs_oid_name_mapping{$ghsoid};
                last;
            }
        }

		
		foreach my $ghsoid (keys  %ghs_oid_name_mapping ){
            $tempresultoid = $resultoid;
            $tempresultoid =~ s/^\s+|\s+$//g;
	        if ( ($tempresultoid eq $ghsoid ) and ($allresult->{$resultoid} == 2 or $allresult->{$resultoid} == 1) ) {
	    		$printMsgUnknown = $printMsgUnknown . $nextline . $ghs_oid_name_mapping{$ghsoid} . " = " . $Nagios_ExitStatus_String_mapping{$snmp_status{$allresult->{$resultoid}}} ;
                delete $ghs_oid_name_mapping{$ghsoid};
                last;
            }
        }


    }
    log_msg("INFO", "Storing SNMP status into an array.\n");
    return \@output;
}


############################################################
# Retrieving Global Health Status with Component health 
############################################################
sub get_ghs_with_Component_Status {
    my @output = ();
   
    my $scalResult = undef; 
    my $tabresult = undef;
	# calling get_entries to collect scalar OIDs
    $scalResult = $snmp_session->get_request(-varbindlist => [keys %ghs_scalar_oid]);
    if ((!defined $scalResult))  
    {
        print "ERROR: SNMP : ", $snmp_session->error;
        log_msg("CRITICAL", $snmp_session->error);
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
        exit $UNKNOWN;
    }
    # calling get_entries to collect tabular OIDs
    $tabresult = $snmp_session->get_entries(-columns => [keys %ghs_details_oid]);
    
	if ((!defined $tabresult)) 
	{
        if($snmp_session->error =~ m/.*message.*size.*exceeded.*buffer.*maxMsgSize*/i){
		    log_msg("WARNING", $snmp_session->error);
            $tabresult = $snmp_session->get_entries(-columns => [keys %ghs_details_oid], -maxrepetitions  => 1,);
        } 
    }
	
    # Error if we don't get anything
    
    if ((!defined $tabresult))  
    {
        print "ERROR: SNMP : ", $snmp_session->error;
        log_msg("CRITICAL", $snmp_session->error);
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
        exit $UNKNOWN;
    }
	@output = @{ retreive_ghs_cmpnt_value($tabresult, $scalResult) };
    log_msg("INFO", "Sorting SNMP status from device.\n");
    
    my @sorted =  sort { $b->{Status} <=> $a->{Status} } @output;
    
    $printmsg = $printmsg .  join "$nextline", map {$_->{name}." = ". $Nagios_ExitStatus_String_mapping{$_->{Status}}} @sorted;
	$printmsg = $printmsg . $printMsgUnknown;
    if(defined $opt{servicename})
    {
		my $command = $nagioshomedir . "/libexec/eventhandlers/submit_check_result " . $opt{hostname} . q{ } . "\"".$opt{servicename}."\"" . q{ } . $final_exit_code . q{ } . "\"" . $printmsg . "\"";
        system($command);
    }
    else
    {
        print $printmsg;
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
        exit $final_exit_code;
    }
}


############################################################
# MAIN Function
############################################################

# Initialize SNMP

log_msg("INFO", "Log initializing\n");
snmp_initialize();

# Setting timeout
$SIG{ALRM} = sub {
    print "PLUGIN TIMEOUT: check_idrac.pl timed out after $plugin_timeout seconds$nextline";
	if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
    exit $UNKNOWN;
};

alarm $plugin_timeout;

# Check Arguments
if (defined $opt{'component'}){
    if(lc$opt{'component'} eq 'mem'){
        get_Component_Status('memory','FQDD', 'Status',0);

    }elsif (lc$opt{'component'} eq 'cpu'){
         get_Component_Status('cpu', 'FQDD', 'Status',0);

    }elsif (lc$opt{'component'} eq 'pd'){
         get_Component_Status('phydisk','FQDD', "Status",1);

    }elsif (lc$opt{'component'} eq 'vd'){
         get_Component_Status('virdisk', 'FQDD', 'Status',1);

    }elsif (lc$opt{'component'} eq 'bat'){
         get_Component_Status('battery', 'Location', 'Status',0);

    }elsif (lc$opt{'component'} eq 'temp'){
         get_Component_Status('temperature', 'Location', 'Status',0);

    }elsif (lc$opt{'component'} eq 'vlt'){
         get_Component_Status('voltage', 'Location', 'Status',0);

    }elsif (lc$opt{'component'} eq 'int'){
         get_Component_Status('intrusion', 'Location', 'Status',0);

    }elsif (lc$opt{'component'} eq 'ghs'){
         get_ghs_with_Component_Status();

    }elsif (lc$opt{'component'} eq 'fan'){
         get_Component_Status('fan', 'FQDD', 'Status',0);

    }elsif (lc$opt{'component'} eq 'ps'){
         get_Component_Status('ps', 'FQDD', 'Status',0);

    }elsif (lc$opt{'component'} eq 'ctl'){
         get_Component_Status('ctl', 'FQDD', 'Status',1);

    }elsif (lc$opt{'component'} eq 'nic'){
         get_Component_Status('nic', 'FQDD', 'ConnectionStatus',1);
    
    }elsif (lc$opt{'component'} eq 'amp'){
         get_Component_Status('amperage', 'Location', 'Status',0);
    }elsif (lc$opt{'component'} eq 'info'){
         get_Server_Info();
    } else {
        print "Invalid component name $opt{'component'}$nextline";
        log_msg ("CRITICAL", "Invalid component name $opt{'component'}\n");
    }
}

#-----------------------------------------------------------------
# Simple log-writing method
#-----------------------------------------------------------------

sub log_msg
{

    my ($severity,$message) = @_;

    my $tm = localtime(time);
    # time in following format : 2013-01-16 18:57:37 
    my $current_time = sprintf '%d-%02d-%02d %02d:%02d:%02d ', $tm->year + 1900, $tm->mon+1, $tm->mday, $tm->hour , $tm->min , $tm->sec;    
    
    eval
    {
        $message = $current_time . q{ } . $severity . q{ } . q{Dell_} . $opt{'component'} . q{ } . $opt{'hostname'} . q{ } .  $message ;    

        if ($opt{opt_log})
        {
            open(FILE,">>$opt_logfile") ;
            print FILE "$message" or warn "Error writing $message to $opt_logfile: $!";
            close FILE;
        }
    };
    
    return 1;
}
if (defined ($snmp_session))
	{ 
        $snmp_session->close();
    }
exit;
 
