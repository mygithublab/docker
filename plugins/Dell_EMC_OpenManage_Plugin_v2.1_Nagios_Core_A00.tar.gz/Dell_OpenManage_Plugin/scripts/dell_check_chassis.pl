#! /usr/bin/perl

##########################################################################
#Title:         Dell Device Plugin Script
#Version:       2.0 
#Creation Date: 20th May 2015
#Description:   This script provides Dell Chassis information, health 
#               and component health. 
#
#Copyright (c) 2015 Dell Inc.
#All Rights Reserved.
##########################################################################

use strict;
use openwsman;
use Socket;
use Getopt::Long qw(:config no_ignore_case);
use Time::localtime;
use File::Spec;
use Net::IP qw(:PROC);

openwsman::set_debug(0);

use vars qw($OK $WARNING $CRITICAL $UNKNOWN $HELP 
            $option $nextline 
            %opt %Nagios_ExitStatus_String_mapping %wsman_status 
    );

our $plugin_timeout = 120;
our $wsman_result;
our $wsman_client;
our $filter;
our %list;
our %temp_list;
our %slot_temp_list;
our %fan_temp_list;
our $printmsg = "";
our $final_exit_code = undef;
our $consoleurl = undef;
our %param;

#Exit Codes
$OK       = 0;
$WARNING  = 1;
$CRITICAL = 2;
$UNKNOWN  = 3;


# Error Code for Nagios from String to number 
our %Nagios_ExitStatus_String_mapping = (
    'OK',			=> 0,
    'WARNING',		=> 1,
    'CRITICAL',		=> 2,
    'UNKNOWN',		=> 3,
);


# Error Code for Nagios Number to String 
%Nagios_ExitStatus_String_mapping = (
    $OK         => 'OK',
    $WARNING    => 'WARNING',
    $CRITICAL   => 'CRITICAL',
    $UNKNOWN    => 'UNKNOWN',
);

# Wsman status from dell agents
%wsman_status = (
	0 => $UNKNOWN,
    1 => $OK,
    2 => $WARNING,
    3 => $CRITICAL,
);

# Max_element for Optmizatio code
our %max_elements_map =(
	lowest_max_element => 10,
	average_max_element => 100,
	maximum_max_element => 300,
);

# OverallHealth status check
our %check_overall_health = (
	yes => 1,
	no  => 0,
);

# Help text
$HELP = <<'END_HELP';
Usage: dell_check_chassis.pl -H <HOSTNAME> [OPTION]...

OPTIONS:
    -i, --item          Component name.
OPTIONAL:
    -h, --help          Display this help text
    -F, --file          Host configuration file with absolute path 
    -s, --servicename   Service name.
    -m, --macroname     Macro name that needs to read from the configuration file
END_HELP


# Options with default values
%opt = (
    'hostname'     => undef,
    'filepath'     => undef,
    'help'         => 0,
    'component'    => undef,
    'opt_log'      => 0,
    'service'      => undef,
    
);

# Get options
GetOptions( 
    'H|hostname=s'      => \$opt{hostname},
    'F|file=s'          => \$opt{filepath},
    'h|help'            => \$opt{help},
    'i|item=s'          => \$opt{component},
    'l|log=i'           => \$opt{opt_log},
    's|servicename=s'   => \$opt{servicename},
) or do { 
    print $HELP; 
    exit $UNKNOWN; 
};


# If user requested help
if ($opt{'help'}) {
    print $HELP;
    exit $OK;
}


# Error if hostname option is not present
if ((!defined $opt{hostname}) and (!defined $opt{component}) )  {
    print $HELP;
    exit $UNKNOWN;
}

# Default line break
$nextline = '<br>';

my $tm = localtime(time);
my $tm_month = sprintf "%02d",$tm->mon + 1;
my $tm_day = sprintf "%02d",$tm->mday;
my $tm_year = $tm->year + 1900;

my ($volume, $directory, $file) = File::Spec->splitpath(__FILE__);

our $opt_logfile = undef;
our $nagioshomedir = undef;
our $racadmdir = undef;
my $config_cfg_path = $directory . "dellconfig.cfg";
if(-e $config_cfg_path) {
    my $log_path = undef;
    my $row = undef;
    if(open(my $fh,"<" , $config_cfg_path)) {
        while ($row  =  <$fh> ){
            chomp $row;
            if(index($row, "NAGIOS_HOME") != -1){
            $row =~ s/\s//g;
            $nagioshomedir = substr($row,12);
            }
            if(index($row, "RACADM") != -1){
            $row =~ s/\s//g;
            $racadmdir = substr($row,7);
            }
        }
        $log_path = $nagioshomedir . "/var/dell/";
        if(!( -d $log_path )) {
            system ("mkdir -p $log_path");
        }
        $opt_logfile = $log_path . "ChassisServices_" . $tm_year . $tm_month  . $tm_day . ".dbg";
    } 
}


##################################################################
#  Fixed URI for all wsman calls 
##################################################################

our $fixed_uri = 'http://schemas.dell.com/wbem/wscim/1/cim-schema/2/';

##################################################################
#  Chassis Information related values 
##################################################################

our @chassisinfo_selector_array = ('__cimnamespace','root/dell/cmc');
our %chassis_view_profile = (
    uri => 'DCIM_ModularChassisView',
    filter_value => "select DNSCMCName, Model, ServiceTag, MgmtControllerFirmwareVersion, URLString from DCIM_ModularChassisView",
    selector => \@chassisinfo_selector_array,
    key_attribute => undef, 
    merge_attribute => 'InstanceID',
);

our @chassis_information_profile = (\%chassis_view_profile);

my @chassis_info_item_list = ( "DNSCMCName", "Model", "ServiceTag", "MgmtControllerFirmwareVersion", "URLString");

our %chassis_info_map_print = (
    "DNSCMCName"                    => "Chassis Name",
    "Model"                         => "Model Name",
    "ServiceTag"                    => "Service Tag",
    "MgmtControllerFirmwareVersion" => "CMC Firmware Version",
    "URLString"                     => "CMC URL",
);

##################################################################
#  GHS related values 
##################################################################

our @ghs_selector_array = ('__cimnamespace','root/dell/cmc');

our %ghs_profile = (
    uri => 'DCIM_ModularChassisView',
    filter_value => "select PrimaryStatus from DCIM_ModularChassisView",
    selector => \@ghs_selector_array,
);

our %complete_ghs_profile = (
    profile => \%ghs_profile,
);

our %ghs_profile_key_mapping = (
    'PrimaryStatus'         => 'Overall Chassis',
);

our %ghs_key_mapping = (
    profile_key => \%ghs_profile_key_mapping,
);

our %complete_ghs = (
    profile =>  \%complete_ghs_profile,
    keymapping => \%ghs_key_mapping,
    enums =>    undef,
);

##################################################################
#  Power Supply related values 
##################################################################
our $ps_overall_health;
our @ps_selector_array = ('__cimnamespace','root/dell/cmc');

our %ps_profile1 = (
    uri => 'Dell_PowerSupply',
    filter_value => "select ClassId, HealthState, DeviceID from Dell_PowerSupply", 
    selector => \@ps_selector_array,
    merge_attribute  => 'ClassId',
);

our %ps_profile2 = (
    uri => 'Dell_PSPackage',
    filter_value => 'select ClassId, Name,PartNumber from Dell_PSPackage',
    selector => \@ps_selector_array,
    merge_attribute => 'ClassId',
);

our %ps_profile3 = (
    uri => 'Dell_PSSlot',
    filter_value => 'select ClassId, Number from Dell_PSSlot',
    selector => \@ps_selector_array,
    merge_attribute => 'ClassId',
);

our %complete_ps_profile = (
    profile1 => \%ps_profile1,
    profile2 => \%ps_profile2,
    profile3 => \%ps_profile3,
);

our %ps_profile_key_mapping = (
    'HealthState'       => 'Status',
    'DeviceID'          => 'FQDD', 
    'Name'              => 'Name', 
    'PartNumber'        => 'PartNumber', 
    'Number'            => 'Slot',
    'InputCurrent(A)'   => 'InputCurrent(A)',
    'InputVolts(V)'     => 'InputVoltage(V)',
    'OutputRatedPower(W)' => 'OutputPower(W)',
    ); 


our %ps_key_mapping = (
    profile_key => \%ps_profile_key_mapping,
);

our %complete_ps = (
    profile =>  \%complete_ps_profile,
    keymapping => \%ps_key_mapping,
    enums =>    undef,
);

our %ps_overall_health_map = (
    'NOT OK'  =>  2,
    'OK'      =>  0,
);

#############################################################
#  Fan related values 
############################################################

our @fan_selector_array = ('__cimnamespace','root/dell/cmc');

our %fan_profile = (
    uri => 'Dell_Fan',
    filter_value => "select ClassId, HealthState, DeviceID, ElementName from Dell_Fan", 
    selector => \@fan_selector_array,
    merge_attribute  => 'DeviceID',
);


our %complete_fan_profile = (
    profile => \%fan_profile,
   
);

our %fan_profile_key_mapping = (
    'HealthState'       => 'Status',
    'DeviceID'          => 'FQDD', 
    'ElementName' 		=> 'Name', 
    'Number'            => 'Slot',
	'Speed'             => 'Speed(RPM)',
	'ClassId'			=> 'ClassId',
    ); 


our %fan_key_mapping = (
    profile_key => \%fan_profile_key_mapping,
);

our %complete_fan = (
    profile =>  \%complete_fan_profile,
    keymapping => \%fan_key_mapping,
    enums =>    undef,
);

#############################################################
#  FanSlot related values 
############################################################

our @fanslot_selector_array = ('__cimnamespace','root/dell/cmc');


our %fanslot_profile = (
    uri => 'Dell_FanSlot',
    filter_value => "select ClassId, Number from Dell_FanSlot",
    selector => \@fanslot_selector_array,
    merge_attribute => 'ClassId',
);


our %complete_fanslot_profile = (
    profile => \%fanslot_profile,
);

our %fanslot_profile_key_mapping = (
    'ClassId'       => 'ClassId',
    'Number'        => 'Number',
    ); 


our %fanslot_key_mapping = (
    profile_key => \%fanslot_profile_key_mapping,
);

our %complete_fanslot = (
    profile =>  \%complete_fanslot_profile,
    keymapping => \%fanslot_key_mapping,
    enums =>    undef,
);

#############################################################
#  I/O Module related values
############################################################

our @io_selector_array = ('__cimnamespace','root/dell/cmc');

our %io_profile1 = (
    uri 			=> 'Dell_IOMPackage',
    filter_value 	=> "select ClassId , PartNumber, Name, IPv4Address,IOMURL from Dell_IOMPackage", 
    selector 		=> \@io_selector_array,
    merge_attribute => 'ClassId',
);

our %io_profile2 = (
    uri 			=> 'Dell_PassThroughModule',
    filter_value 	=> 'select ClassId , LinkTechnologies, DeviceID, Name from Dell_PassThroughModule',
    selector 		=> \@io_selector_array,
    merge_attribute => 'ClassId',
);

our %FabricType_Map = (
		0 => 'Unknown' ,
		1 => 'Other', 
		2 => 'Ethernet', 
		3 => 'IB', 
		4 =>'FC' , 
		5 => 'FDDI', 
		6 => 'ATM', 
		7 => 'Token Ring', 
		8 => 'Frame Relay', 
		9 => 'Infrared', 
		10 => 'BlueTooth', 
		11 => 'Wireless LAN', 
    ); 
	
our %io_enum = (
		'FabricType' => \%FabricType_Map, 
    ); 
	
our %complete_io_profile = (
    profile1 => \%io_profile1,
    profile2 => \%io_profile2,
);


	
our %io_profile_key_mapping = (
    'Status'                => 'Status',
    'DeviceID'          	=> 'FQDD',
	'IOModuleName'			=> 'Name',	
	'PartNumber'            => 'PartNumber',
    'Name' 					=> 'Slot',
	'IPv4Address'			=> 'IPv4Address',
	'LinkTechnologies'      => 'FabricType',
	'IOMURL'     			=> 'LaunchURL',
    ); 

our %io_key_mapping = (
    profile_key => \%io_profile_key_mapping,
);

our %complete_io = (
    profile 	=>  \%complete_io_profile,
    keymapping 	=> 	\%io_key_mapping,
    enums 		=>   \%io_enum,
);

	
#############################################################
#  KVM related values
############################################################

our @kvm_selector_array = ('__cimnamespace','root/dell/cmc');

our %kvm_profile = (
    uri => 'Dell_KVM',
    filter_value => "select HealthState,Name from Dell_KVM", 
    selector => \@kvm_selector_array,
	
);


our %complete_kvm_profile = (
    profile => \%kvm_profile,

);

our %kvm_profile_key_mapping = (
    'HealthState'   => 'Status', 
    'Name' 			=> 'Name', 
    ); 


our %kvm_key_mapping = (
    profile_key => \%kvm_profile_key_mapping,
);


our %complete_kvm = (
    profile =>  \%complete_kvm_profile,
    keymapping => \%kvm_key_mapping,
    enums =>    undef,
);

#############################################################
#  Slot Server related values
############################################################

our @slot_selector_array = ('__cimnamespace','root/dell/cmc');

our %slot_profile1 = (
    uri => 'DCIM_BladeServerView',
    filter_value => "select SlotNumber,MasterSlotNumber,PrimaryStatus,ServiceTag,SubSlot,HostName from DCIM_BladeServerView ", 
    selector => \@slot_selector_array,
	merge_attribute => 'InstanceID',
);

our %slot_profile2 = (
    uri => 'DCIM_BladeServerView',
    filter_value => "select Model,IPv4Address from DCIM_BladeServerView ", 
    selector => \@slot_selector_array,
	merge_attribute => 'InstanceID',
);


our %complete_slot_profile = (
    profile1 => \%slot_profile1,
	profile2 => \%slot_profile2,
);

our %slot_profile_key_mapping = (
    'SlotNumber'		=> 'SlotNumber', 
	'HostName'			=> 'HostName', 
	'Model'				=> 'Model', 
	'ServiceTag'		=> 'ServiceTag', 
    'PrimaryStatus'		=> 'Status', 
	'IPv4Address'  		=> 'iDRACIP',
	'MasterSlotNumber'	=> 'MasterSlotNumber',
	'SubSlot'  			=> 'SubSlot',
  ); 


our %slot_key_mapping = (
    profile_key => \%slot_profile_key_mapping,
);

our %complete_slot = (
    profile =>  \%complete_slot_profile,
    keymapping => \%slot_key_mapping,
    enums =>    undef,
);

#############################################################
#  STASH Slot Server related values
############################################################

our @stashslot_selector_array = ('__cimnamespace','root/dell/cmc');

our %stashslot_profile = (
    uri => 'DCIM_StorageSledView',
    filter_value => "select FQDD,HostName,Model,ServiceTag,PrimaryStatus from DCIM_StorageSledView ", 
    selector => \@stashslot_selector_array,
	merge_attribute => 'InstanceID',
);

our %complete_stashslot_profile = (
    profile => \%stashslot_profile,
);

our %stashslot_profile_key_mapping = (
    'FQDD'				=> 'SlotNumber', 
	'HostName'			=> 'HostName', 
	'Model'				=> 'Model', 
	'ServiceTag'		=> 'ServiceTag', 
    'PrimaryStatus'		=> 'Status', 
  ); 


our %stashslot_key_mapping = (
    profile_key => \%stashslot_profile_key_mapping,
);

our %complete_stashslot = (
    profile =>  \%complete_stashslot_profile,
    keymapping => \%stashslot_key_mapping,
    enums =>    undef,
);

#############################################################
#  Physical Disk related values
############################################################

our @pd_selector_array = ('__cimnamespace','root/dell/cmc');

our %pd_profile1 = (
    uri => 'DCIM_PhysicalDiskView',
    filter_value => "select PrimaryStatus,FQDD,Model,PPID,Slot,Revision from DCIM_PhysicalDiskView", 
    selector => \@pd_selector_array,
    merge_attribute  => 'FQDD',
);

our %pd_profile2 = (
    uri => 'DCIM_PhysicalDiskView',
    filter_value => "select FQDD, SizeInBytes,UsedSizeInBytes,MediaType,SecurityState from DCIM_PhysicalDiskView", 
    selector => \@pd_selector_array,
    merge_attribute  => 'FQDD',
);

our %pd_Type_Map = (
        0  => 'Hard Disk Drive', 
        1  => 'Solid State Drive',
    ); 

our %pd_security_state = (
        0  => 'Unknown', 
        1  => 'Encryption Capable',
		2  => 'Security Key Assigned',
    ); 
	
our %pd_enum = (
        MediaType  => \%pd_Type_Map, 
		SecurityState => \%pd_security_state,
    ); 
	
our %complete_pd_profile = (
    profile1 => \%pd_profile1,
	profile2 => \%pd_profile2,

);

our %pd_profile_key_mapping = (
    'PrimaryStatus'		=> 'Status', 
    'FQDD'				=> 'FQDD', 
    'Model'            	=> 'Model',
	'PPID' 				=> 'PartNumber',
	'Slot'            	=> 'Slot',
	'Revision'          => 'FirmwareVersion',
	'SizeInBytes'       => 'Capacity(GB)',
	'UsedSizeInBytes'   => 'FreeSpace(GB)',
	'MediaType'        	=> 'MediaType',
	'SecurityState'     => 'SecurityState',
    ); 


our %pd_key_mapping = (
    profile_key => \%pd_profile_key_mapping,
);

our %complete_pd = (
    profile =>  \%complete_pd_profile,
    keymapping => \%pd_key_mapping,
    enums =>    \%pd_enum,
);

###############################
#  Virtual Disk related values
###############################

our @vd_selector_array = ('__cimnamespace','root/dell/cmc');

our %vd_profile1 = (
    uri => 'DCIM_VirtualDiskView',
    filter_value => "select PrimaryStatus, FQDD, Name, SizeInBytes, MediaType, StripeSize from DCIM_VirtualDiskView", 
    selector => \@vd_selector_array,
    merge_attribute  => 'FQDD',
);

our %vd_profile2 = (
    uri => 'DCIM_VirtualDiskView',
    filter_value => "select FQDD, ReadCachePolicy, WriteCachePolicy, RAIDTypes, BusProtocol from DCIM_VirtualDiskView", 
    selector => \@vd_selector_array,
    merge_attribute  => 'FQDD',
);


our %bus_protocol_Map = (
		0  	=> 'Unknown',
		1  	=> 'SCSI',
		2	=> 'PATA',
		3	=> 'FIBRE',
		4	=> 'USB',
		5	=> 'SATA',
		6	=> 'SAS',
    ); 

our %media_Type_Map = (
		0  	=> 'Unknown',
		1  	=> 'Magnetic Drive',
		2	=> 'Solid State Drive',
    ); 

our %read_cache_Map = (
		0  	=> 'Unknown',
		16  => 'No Read Ahead',
		32	=> 'Read Ahead',
		64	=> 'Adaptive Read Ahead',
    ); 

our %write_cache_Map = (
		0  => 'Unknown',
		1  => 'Write Through',
		2  => 'Write Back',
		4  => 'Write Back Force',
    ); 

our %raid_type_Map = (
		1 	  =>  'No RAID',
		2 	  =>  'RAID 0',
		4 	  =>  'RAID 1',
		64	  =>  'RAID 5',
		128	  =>  'RAID 6',
		2048  =>  'RAID 10',
		8192  =>  'RAID 50',
		16384 =>  'RAID 60',
    ); 
	
our %stripesize_map = (
		0  		=> 'Default',
		1		=> '512B',
		2		=> '1KB',
		4		=> '2KB',
		8		=> '4KB',
		16		=> '8KB',
		32		=> '16KB',
		64		=> '32KB',
		128		=> '64KB',
		256		=> '128KB',
		512		=> '256KB',
		1024	=> '512KB',
		2048	=> '1MB',
		4096	=> '2MB',
		8192	=> '4MB',
		16384	=> '8MB',
		32768	=> '16MB',
    ); 
	
our %vd_enum = (
		'BusProtocol' => \%bus_protocol_Map, 
		'MediaType' => \%media_Type_Map, 
		'ReadPolicy' => \%read_cache_Map,  
		'WritePolicy' => \%write_cache_Map, 
		'RAIDTypes' => \%raid_type_Map,
		'StripeSize' => \%stripesize_map,
    ); 


our %complete_vd_profile = (
    profile1 => \%vd_profile1,
	profile2 => \%vd_profile2,
);
	
our %vd_profile_key_mapping = (
    'PrimaryStatus'		=> 'Status', 
    'FQDD'				=> 'FQDD', 
    'Name'            	=> 'Name',
    'SizeInBytes'		=> 'Capacity(GB)', 
    'MediaType'			=> 'MediaType', 
    'StripeSize'        => 'StripeSize',
	'ReadCachePolicy'	=> 'ReadPolicy', 
	'WriteCachePolicy'	=> 'WritePolicy', 
	'RAIDTypes'			=> 'RAIDTypes', 
	'BusProtocol'		=> 'BusProtocol', 

    ); 


our %vd_key_mapping = (
    profile_key => \%vd_profile_key_mapping,
);

our %complete_vd = (
    profile    => \%complete_vd_profile,
    keymapping => \%vd_key_mapping,
    enums      => \%vd_enum,
);

#############################################################
#  Enclosure related values
############################################################

our @enc_selector_array = ('__cimnamespace','root/dell/cmc');

our %enc_profile = (
    uri => 'DCIM_EnclosureView',
    filter_value => "select PrimaryStatus,FQDD,ServiceTag,WiredOrder,Connector,Version,SlotCount from DCIM_EnclosureView", 
    selector => \@enc_selector_array,
);


our %complete_enc_profile = (
    profile => \%enc_profile,

);

our %enc_profile_key_mapping = (
    'PrimaryStatus'  => 'Status', 
    'FQDD' 			=> 'FQDD', 
    'ServiceTag'    => 'ServiceTag',
	'WiredOrder'    => 'BayID',
	'Connector'     => 'Connector',
	'Version'       => 'FirmwareVersion',
	'SlotCount'     => 'SlotCount',
    ); 


our %enc_key_mapping = (
    profile_key => \%enc_profile_key_mapping,
);

our %complete_enc = (
    profile =>  \%complete_enc_profile,
    keymapping => \%enc_key_mapping,
    enums =>    undef,
);


#############################################################
#  Controller related values
############################################################

our @ctl_selector_array = ('__cimnamespace','root/dell/cmc');

our %ctl_profile1 = (
    uri => 'DCIM_ControllerView',
    filter_value => "select PrimaryStatus,FQDD,ProductName,CacheSizeInMB,ControllerFirmwareVersion,DeviceCardSlotType from DCIM_ControllerView", 
    selector => \@ctl_selector_array,
    merge_attribute  => 'FQDD',
);

our %ctl_profile2 = (
    uri => 'DCIM_ControllerView',
    filter_value => "select FQDD, PatrolReadState, SecurityStatus from DCIM_ControllerView", 
    selector => \@ctl_selector_array,
    merge_attribute  => 'FQDD',
);

our %patrol_read_Map = (
	0 => 'Unknown',
	1 => 'Stopped',
	2 => 'Running',
);

our %security_status_map = (
	0 => 'Unknown',
	1 => 'Encryption Capable',
	2 => 'Security Key Assigned',
);


our %ctl_enum = (
		'PatrolReadState' => \%patrol_read_Map, 
		'SecurityStatus' => \%security_status_map, 

    ); 
	
our %complete_ctl_profile = (
    profile1 => \%ctl_profile1,
	profile2 => \%ctl_profile2,

);

our %ctl_profile_key_mapping = (
    'PrimaryStatus'          	=> 'Status', 
    'FQDD' 						=> 'FQDD', 
    'ProductName'            	=> 'Name',
	'CacheSizeInMB'            	=> 'CacheSize(MB)',
	'ControllerFirmwareVersion' => 'FirmwareVersion',
	'DeviceCardSlotType'       	=> 'SlotType',
	'SecurityStatus'            => 'SecurityStatus',
	'PatrolReadState'           => 'PatrolReadState',
    ); 


our %ctl_key_mapping = (
    profile_key => \%ctl_profile_key_mapping,
);

our %complete_ctl = (
    profile =>  \%complete_ctl_profile,
    keymapping => \%ctl_key_mapping,
    enums =>    \%ctl_enum,
);


#############################################################
#  PCIe related values
############################################################

our @pci_selector_array = ('__cimnamespace','root/dell/cmc');

our %pci_profile1 = (
    uri => 'DCIM_ChassisPCIDeviceView',
    filter_value => "select Description,SlotFQDD,Fabric,PowerStateStatus,AssignedBladeSlotFQDD,AssignedBladeFQDD from DCIM_ChassisPCIDeviceView", 
    selector => \@pci_selector_array,
    merge_attribute  => 'SlotFQDD',
);

our %pci_profile2 = (
    uri => 'DCIM_ChassisPCIDeviceView',
    filter_value => "select FQDD, NumberDescription from DCIM_ChassisPCISlot", 
    selector => \@pci_selector_array,
    merge_attribute  => 'FQDD',
);


our %pci_powerstate_Map = (
	2 => 'On',
	3 => 'Off',
);

our %pci_enum = (
		'PowerState' => \%pci_powerstate_Map, 
    ); 
	
our %complete_pci_profile = (
    profile1 => \%pci_profile1,
	profile2 => \%pci_profile2,
);

our %pci_profile_key_mapping = (
	'Description'			=> 'Name',
	'SlotFQDD'         		=> 'FQDD', 
	'Fabric'         		=> 'Fabric', 
	'PowerStateStatus'      => 'PowerState', 
	'AssignedBladeSlotFQDD' => 'AssignedSlot', 
	'AssignedBladeFQDD'     => 'AssignedBlade', 
	'NumberDescription'		=> 'PCIeSlot',
    ); 


our %pci_key_mapping = (
    profile_key => \%pci_profile_key_mapping,
);

our %complete_pci = (
    profile =>  \%complete_pci_profile,
    keymapping => \%pci_key_mapping,
    enums =>    \%pci_enum,,
);

our @chassis_pci_item_list = ( "FQDD", "Name", "AssignedBlade", "AssignedSlot", "Fabric", "PCIeSlot", "PowerState" );

##################################################################
# All Attribute in a hash with its references.
##################################################################
our %main_profile = (
        'ghs'           => \%complete_ghs,
        'ps'            => \%complete_ps,
        'fan'           => \%complete_fan,
        'io'            => \%complete_io,
        'kvm'           => \%complete_kvm,
        'slot'          => \%complete_slot,
        'pd'            => \%complete_pd,
        'vd'            => \%complete_vd,
        'enc'           => \%complete_enc,
        'ctl'           => \%complete_ctl,
		'pci'           => \%complete_pci,
		'fanslot'       => \%complete_fanslot,
		'stashslot'     => \%complete_stashslot,
    );


##################################################################
# Func:         trim
# Input:        string of subslot
# Output:       removing spaces.
##################################################################
sub  trim { my $s = shift; $s =~ s/^\s+|\s+$//g; 
           return $s 
          }
##################################################################
# Func:         get_chassis_component_health
# Input:        Component name, Severity name, overall health check flag 
# Output:       No output.
# Description:  Main function which is getting callled by each component
#               and calling other function to display the status 
#               of the component.
##################################################################
sub get_chassis_component_health {
    my ($component,$component_descriptor, $severity_name,$operation,$max_elements,$check_overall_health) = @_;
    log_msg("INFO ","Get Chassis Component health, WSMAN query started for IP $opt{hostname} and component name: $component\n");
    my %output = ();
    my %psresult = ();
    my %fanresult = ();
	my %ioresult = ();
    my @severity_array = ();
	my %stash_list;

    my $final_uri = undef;
    my  $profiles  = $main_profile{$component}->{'profile'};
	foreach ( keys %{$profiles}){
        my $profile = $_;
        if($operation eq 'get'){
            get_wsman_result($profiles->{$profile}->{'uri'},
                         $profiles->{$profile}->{'selector'}, 
                         $profiles->{$profile}->{'merge_attribute'});

        } elsif ($operation eq 'Enumerate') {
            enumerate_wsman_result($profiles->{$profile}->{'uri'},
                         $profiles->{$profile}->{'filter_value'},
                         $profiles->{$profile}->{'selector'}, 
                         $profiles->{$profile}->{'merge_attribute'},
                         $max_elements);
        }             
    }
    if( !%temp_list){
        print "Component Information = UNKNOWN";
        exit $UNKNOWN;
    }	
	
	
    if ( $component eq 'ps' )
    {
        %psresult = getRacadmResult("getpbinfo", $component);
    }
    if ( $component eq 'fan' )
    {
        %fanresult = getRacadmResult("getsensorinfo", $component);
    }
	if ( $component eq 'io' )
    {
        %ioresult = getRacadmResult("getmodinfo", $component);
    }
    my $temp_list_Size = keys %temp_list;
    my $racadm_result_Size = keys %psresult;
    my $racadm_fan_result_Size = keys %fanresult;
	my $racadm_io_result_Size = keys %ioresult;
	my $sensorLeftValue;
	my $sensorRightValue;

    foreach my $item_instance ( keys %temp_list)
    {
        foreach my $key_instance ( keys %{$temp_list{$item_instance}})
        {
            if (defined $main_profile{$component}->{'keymapping'}->{'profile_key'}->{$key_instance})
            {
                my $value = $temp_list{$item_instance}->{$key_instance};
                $value =~ s/^\s+|\s+$//g;
                if (length($value) != 0 ){
                    $list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'profile_key'}->{$key_instance}}= $value;
                }

                if ( $component eq 'ps' )
                {
                    my $key;
                    $key = uc $temp_list{$item_instance}->{$key_instance};
                    if (exists $psresult{$key} && $temp_list_Size eq $racadm_result_Size)
                    {                        
                        if (length($psresult{$key}{'InputCurrent(A)'}) != 0)
                        {
                            $list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'profile_key'}->{'InputCurrent(A)'}}= $psresult{$key}{'InputCurrent(A)'};
                        }  
                        if (length($psresult{$key}{'InputVolts(V)'}) != 0)
                        {
                            $list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'profile_key'}->{'InputVolts(V)'}}= $psresult{$key}{'InputVolts(V)'};
                        }
                        if (length($psresult{$key}{'OutputRatedPower(W)'}) != 0)
                        {
                            $list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'profile_key'}->{'OutputRatedPower(W)'}}= $psresult{$key}{'OutputRatedPower(W)'};
                        }
						}
                    elsif($temp_list_Size ne $racadm_result_Size)
                    {
                        $list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'profile_key'}->{'InputCurrent(A)'}}= "Not Available";
                        $list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'profile_key'}->{'InputVolts(V)'}}= "Not Available";
                        $list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'profile_key'}->{'OutputRatedPower(W)'}}= "Not Available";
                        log_msg("WARNING ","RACADM query resultant is not available for all Power Supply instances for IP $opt{hostname}.\n");
                    }
                }

                if ( $component eq 'fan' )
                {
                    my $key;
					
				if( index($temp_list{$item_instance}->{'ElementName'}, "-") != -1 )
				{
					($sensorLeftValue, $sensorRightValue) = split (/-/, $temp_list{$item_instance}->{'ElementName'});
						$key = uc $sensorLeftValue . $sensorRightValue;

				} elsif( index($temp_list{$item_instance}->{'ElementName'}, " ") != -1 )
				{
					($sensorLeftValue, $sensorRightValue) = split (" ", $temp_list{$item_instance}->{'ElementName'});
						$key = uc $sensorLeftValue . $sensorRightValue;
				} 
				if (exists $fanresult{$key} && $temp_list_Size eq $racadm_fan_result_Size)
                {                        
                    if (length($fanresult{$key}{'Speed'}) != 0)
                   {
                        $list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'profile_key'}->{'Speed'}}= $fanresult{$key}{'Speed'};
                    }
                }
                elsif($temp_list_Size ne $racadm_fan_result_Size)
                {
                    $list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'profile_key'}->{'Speed'}}= "Not Available";
                }
                }
                #code end for merging racadm resultant data with wsman resultant for Fan Component
                #code start for merging racadm resultant data with wsman resultant for io Component
                if ( $component eq 'io' )
                {
                    my $key;
                    $key = $temp_list{$item_instance}->{'DeviceID'};
                    if (exists $ioresult{$key} && $temp_list_Size eq $racadm_io_result_Size)
                    {                        
                        if (length($ioresult{$key}{'Status'}) != 0)
                        {
                            $list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'profile_key'}->{'Status'}}= $ioresult{$key}{'Status'};
                        }
                    }
                    elsif($temp_list_Size ne $racadm_io_result_Size)
                    {
                        $list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'profile_key'}->{'Status'}}= "unknown";
                    }
                }
                #code end for merging racadm resultant data with wsman resultant for io Component				
            }
        }
    }
		
	if ($component eq 'fan'){
		%fan_temp_list = %list;
		undef %temp_list;
		my $profilesfanslot  = $main_profile{'fanslot'}->{'profile'};
		foreach ( keys %{$profilesfanslot}){
			my $profile = $_;
			enumerate_wsman_result($profilesfanslot->{$profile}->{'uri'},
							 $profilesfanslot->{$profile}->{'filter_value'},
							 $profilesfanslot->{$profile}->{'selector'}, 
							 $profilesfanslot->{$profile}->{'merge_attribute'},
							 $max_elements);
			             
		}
		
		foreach my $item_instance ( keys %temp_list)
		{
			foreach my $key_instance ( keys %{$temp_list{$item_instance}})
			{
				if (defined $main_profile{'fanslot'}->{'keymapping'}->{'profile_key'}->{$key_instance})
				{
					my $value = $temp_list{$item_instance}->{$key_instance};
					$value =~ s/^\s+|\s+$//g;
					if (length($value) != 0 ){
						$list{$item_instance}->{$main_profile{'fanslot'}->{'keymapping'}->{'profile_key'}->{$key_instance}}= $value;
					}
			
				}
			}
		}

		foreach my $faninstance ( keys %list){
			foreach my $fanslotinstance ( keys %temp_list){
				if($list{$faninstance}->{'ClassId'} == $list{$fanslotinstance}->{'ClassId'} ){
					$list{$faninstance}->{'Slot'} = $list{$fanslotinstance}->{'Number'};
					}
				}
			}
			
		foreach my $faninstance ( keys %list){
		delete $list{$faninstance}->{'ClassId'};
			if ( ! (exists $list{$faninstance}->{'FQDD'} )){  
					delete $list{$faninstance};
				}
				
		}
	}

	if ($component eq 'pci'){
		foreach my $pciinstance ( keys %list){
			if ( ! (exists $list{$pciinstance}->{'FQDD'} )){  
				delete $list{$pciinstance};
			}
		}
		foreach my $pciinstance ( keys %list){	
			if ( exists $list{$pciinstance}->{'PowerState'}){  
				  if($list{$pciinstance}->{'PowerState'} == 2) {
					$list{$pciinstance}->{'PowerState'} = "On";
				  } elsif($list{$pciinstance}->{'PowerState'} == 3) {
					$list{$pciinstance}->{'PowerState'} = "Off";
				  } else {
					$list{$pciinstance}->{'PowerState'} = "Others";
				  }
			}
			
		}
	}
    if ($component eq 'pd'){
        foreach my $pdinstance ( keys %list){
            if ( exists $list{$pdinstance}->{'Capacity(GB)'} ){  
			
                $list{$pdinstance}->{'Capacity(GB)'} = sprintf '%.2f', $list{$pdinstance}->{'Capacity(GB)'}/(1024.00 * 1024 * 1024 );   
            }
        }
		
		foreach my $pdinstance ( keys %list){
            if ( exists $list{$pdinstance}->{'FreeSpace(GB)'} ){   
                $list{$pdinstance}->{'FreeSpace(GB)'} = sprintf '%.2f', $list{$pdinstance}->{'FreeSpace(GB)'}/(1024.00 * 1024 * 1024 ); 
                $list{$pdinstance}->{'FreeSpace(GB)'} = $list{$pdinstance}->{'Capacity(GB)'} - $list{$pdinstance}->{'FreeSpace(GB)'} ; 
            }
        }
	}
	
	if ($component eq 'vd'){
        foreach my $vdinstance ( keys %list){
            if ( exists $list{$vdinstance}->{'Capacity(GB)'} ){  
			
                $list{$vdinstance}->{'Capacity(GB)'} = sprintf '%.2f', $list{$vdinstance}->{'Capacity(GB)'}/(1024.00 * 1024 * 1024 );   
            }
        }
	}

	if ($component eq 'slot'){
		%slot_temp_list = %list;
		foreach my $slottmpinstance ( keys %slot_temp_list){
			if($list{$slottmpinstance}->{'MasterSlotNumber'} != $list{$slottmpinstance}->{'SlotNumber'} ) {
				foreach my $slotinstance ( keys %list){
					if( $list{$slotinstance}->{'SlotNumber'} == $list{$slottmpinstance}->{'MasterSlotNumber'}) {
						$list{$slotinstance}->{'SlotNumber'} = $list{$slotinstance}->{'SlotNumber'} . '/' .$list{$slottmpinstance}->{'SlotNumber'}  ;
					}
				}
			}
		}

		foreach my $slotinstance ( keys %list){
			if($list{$slotinstance}->{'MasterSlotNumber'} != $list{$slotinstance}->{'SlotNumber'} ) {
				delete $list{$slotinstance};
			}
		}
		# Check for STASH server
		undef %temp_list;
		my $stashprofiles  = $main_profile{'stashslot'}->{'profile'};
		foreach ( keys %{$stashprofiles}){
			my $stashprofile = $_;
			enumerate_wsman_result($stashprofiles->{$stashprofile}->{'uri'},
							 $stashprofiles->{$stashprofile}->{'filter_value'},
							 $stashprofiles->{$stashprofile}->{'selector'}, 
							 $stashprofiles->{$stashprofile}->{'merge_attribute'},
							 $max_elements);
			             
		}
		if(%temp_list) {
			foreach my $item_instance ( keys %temp_list)
			{
				foreach my $key_instance ( keys %{$temp_list{$item_instance}})
				{
					if (defined $main_profile{'stashslot'}->{'keymapping'}->{'profile_key'}->{$key_instance})
					{
						my $value = $temp_list{$item_instance}->{$key_instance};
						$value =~ s/^\s+|\s+$//g;
						if (length($value) != 0 ){
							$stash_list{$item_instance}->{$main_profile{'stashslot'}->{'keymapping'}->{'profile_key'}->{$key_instance}}= $value;
						}
				
					}
				}
			}
			foreach my $stashslotinstance ( keys %stash_list){
				if ( exists $stash_list{$stashslotinstance}->{'SlotNumber'} ){  
				
					 $stash_list{$stashslotinstance}->{'SlotNumber'} = substr($stash_list{$stashslotinstance}->{'SlotNumber'}, -2);   
					 if(substr(($stash_list{$stashslotinstance}->{'SlotNumber'}),0,1) == 0) {
						$stash_list{$stashslotinstance}->{'SlotNumber'} = substr($stash_list{$stashslotinstance}->{'SlotNumber'}, -1);  
					 }
					
				}
			}
		%list = (%list, %stash_list );	
		}

		# STASH check End
		
		foreach my $slotinstance ( keys %list){
            if ( (exists $list{$slotinstance}->{'SubSlot'} ) ){ 
                if ( (uc(trim($list{$slotinstance}->{'SubSlot'})) ne "NA")){
                $list{$slotinstance}->{'SlotNumber'} = $list{$slotinstance}->{'SlotNumber'}.$list{$slotinstance}->{'SubSlot'};
                } 
		         delete $list{$slotinstance}->{'SubSlot'};
            }
			delete $list{$slotinstance}->{'MasterSlotNumber'};	
			
			if( ($list{$slotinstance}->{'iDRACIP'} eq '0.0.0.0') || ($list{$slotinstance}->{'iDRACIP'} eq '') ) { 
				$list{$slotinstance}->{'iDRACIP'} = 'Not Available';   
			}
			
			if($list{$slotinstance}->{'HostName'} eq '' ) { 
				$list{$slotinstance}->{'HostName'} = 'Not Available';   
			}
        }
	}
	
	if ( $component eq 'io' )
    {
        foreach my $iotmpinstance ( keys %list)
		{
			if( ($list{$iotmpinstance}->{'IPv4Address'} eq '0.0.0.0') || ($list{$iotmpinstance}->{'IPv4Address'} eq '') )
			{ 
				$list{$iotmpinstance}->{'IPv4Address'} = 'Not Available';   
			}
			if( ($list{$iotmpinstance}->{'LaunchURL'} eq "http://0.0.0.0") || ($list{$iotmpinstance}->{'LaunchURL'} eq '') ) 
			{ 
				$list{$iotmpinstance}->{'LaunchURL'} = 'Not Available';   
			}
        }
    }


    if ( $component eq 'ghs' )
    {
        foreach my $instance ( keys %list)
        {
            $final_exit_code  = $wsman_status{$list{$instance}->{'Overall Chassis'}}; 
            
            if (!defined ($final_exit_code))
            {
                $final_exit_code = $UNKNOWN;
            }
            $printmsg = "Overall Chassis = $Nagios_ExitStatus_String_mapping{$final_exit_code}";
        }
    } elsif( $component eq 'pci' ) {
		print_chassis_pci();
		exit $OK;
	} else
    {
		if( $component eq 'io' )
		{
			@severity_array =  @{severity_arrange_on_string($severity_name,$component)}; 
		}
		else
		{
			@severity_array =  @{severity_arrange($severity_name,$component)};
		}

        log_msg("INFO ","Success in arranging $component instance on severity basis.\n");
    
        my_printing(\@severity_array,$component,$component_descriptor,$severity_name);
        if($check_overall_health == 1)
        {
            my $status;
            if ($component eq "ps")
            {
                $final_exit_code = $ps_overall_health_map{$ps_overall_health};
            }
            else
            {
                overall_health_status($component,$max_elements);
                foreach my $item_instance ( keys %temp_list)
                {
                    foreach my $key_instance ( keys %{$temp_list{$item_instance}})
                    {
                        $status =  $temp_list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'overallhealthkey'}->{'status'}};
                        last;
                    }
                    last;
                }
                
                if($status == 0) 
                {
                    $final_exit_code = $UNKNOWN;
                }
                elsif($status == 1)
                {
                    $final_exit_code = $OK;
                }
                elsif($status == 2) 
                {
                    $final_exit_code = $WARNING;
                } 
                else 
                {
                    $final_exit_code = $CRITICAL;
                } 
            }
        } 
        elsif ($check_overall_health == 0) 
        {
            if(defined $severity_array[3][0])
            {
                $final_exit_code = $CRITICAL;
            } 
            elsif (defined  $severity_array[2][0]) 
            {
                $final_exit_code = $WARNING;
            } 
            elsif (defined  $severity_array[1][0]) 
            {
                $final_exit_code = $OK;
            } 
            else 
            {
                $final_exit_code = $UNKNOWN;
            }
        }
        log_msg("INFO ","Success in getting all attribute value for component $component\n");
    }
	
    if(defined $opt{servicename}){
        my $command = $nagioshomedir . "/libexec/eventhandlers/submit_check_result " .  $opt{hostname} . q{ } . "\"" .$opt{servicename}."\""  . q{ } . $final_exit_code . q{ } . "\"" . $printmsg . "\"";
        system($command);
    } else {
        print $printmsg;
        exit $final_exit_code;
    }
}

sub  overall_health_status
{
    my ($component,$max_elements) = @_;
    
    my $temp_profile = $main_profile{$component}->{'overallHealth'};
    my $temp_uri = $fixed_uri . $temp_profile->{'uri'};
    enumerate_wsman_result($temp_profile->{'uri'},
                           $temp_profile->{'filter_value'},  
                           $temp_profile->{'selector'},
                           'InstanceID',
                           $max_elements);
}

##################################################################
# Func: severity_arrange
# Input: severity name string, arranged wsman result hash 
# outout: Return an array of indexes based on severity.
# Description :  This function takes arranged wsman result hash and return
#                a array of indexes based on severity. 
##################################################################
sub severity_arrange {
    my ($severity_name, $component) = @_;
    my @finaloutput = ();
    my $all_unknown_index = 0;
    my $all_ok_index = 0;
    my $all_critical_index = 0;
    my $all_warn_index = 0;

        foreach my $eachInstance (keys %list){
			
		    if ($list{$eachInstance}{$severity_name} == 0){
                # All Unknown instances to index[0]  
                $list{$eachInstance}{$severity_name} = 3;
                $finaloutput[0][$all_unknown_index] = $eachInstance;
                $all_unknown_index = $all_unknown_index + 1;
            }elsif( ($list{$eachInstance}{$severity_name} == 5) || ($list{$eachInstance}{$severity_name} == 1)) {
                # All Ok status Index[1]
                $list{$eachInstance}{$severity_name} = 0;
                $finaloutput[1][$all_ok_index] = $eachInstance;
                $all_ok_index = $all_ok_index + 1;
            } elsif (($list{$eachInstance}{$severity_name} == 10) || ($list{$eachInstance}{$severity_name} == 15) || ($list{$eachInstance}{$severity_name} == 2)) {
                # All Wanring Status Index[2] 
                $list{$eachInstance}{$severity_name} = 1;
                $finaloutput[2][$all_warn_index] = $eachInstance;
                $all_warn_index = $all_warn_index + 1;
            } else {
                # All CRITICAL Status Index[3]
                $list{$eachInstance}{$severity_name} = 2;
                $finaloutput[3][$all_critical_index] = $eachInstance;
                $all_critical_index = $all_critical_index + 1;
            }
        }    

    return \@finaloutput;

}

##################################################################
# Func: severity_arrange_on_string
# Input: severity name string, arranged snmp result hash 
# outout: Return an array of indexes based on severity.
# Description :  This function takes arranged snmp result hash and return
#                a array of indexes based on severity. 
##################################################################
sub severity_arrange_on_string {
    my ($severity_name, $component) = @_;
    my @finaloutput = ();
    my $all_unknown_index = 0;
    my $all_ok_index = 0;
    my $all_critical_index = 0;
    my $all_warn_index = 0;

    foreach my $eachInstance (keys %list){
        if (exists $list{$eachInstance}{$severity_name}){
            if (lc($list{$eachInstance}{$severity_name}) eq 'unknown'){
                # All Unknown instances to index[0]  
                $list{$eachInstance}{$severity_name} = 3;
                $finaloutput[0][$all_unknown_index] = $eachInstance;
                $all_unknown_index = $all_unknown_index + 1;
            }elsif( lc($list{$eachInstance}{$severity_name}) eq 'ok') {
                # All Ok status Index[1]
                $list{$eachInstance}{$severity_name} = 0;
                $finaloutput[1][$all_ok_index] = $eachInstance;
                $all_ok_index = $all_ok_index + 1;
            } elsif ( (lc($list{$eachInstance}{$severity_name}) eq 'warning') || (lc($list{$eachInstance}{$severity_name}) eq 'not ok') ) {
                # All Warning Status Index[2] 
                $list{$eachInstance}{$severity_name} = 1;
                $finaloutput[2][$all_warn_index] = $eachInstance;
                $all_warn_index = $all_warn_index + 1;
            } else   {
                # All CRITICAL Status Index[3]
                $list{$eachInstance}{$severity_name} = 2;
                $finaloutput[3][$all_critical_index] = $eachInstance;
                $all_critical_index = $all_critical_index + 1;
            }
        }
    }    
    return \@finaloutput;
}

##################################################################
# Func :         my_printing
# Input:         severity_array, arranged result hash, component name, 
#                severity name 
# Output:        NO output
# Description :  This function prints all the instances of the component 
#                by iterating through the array and hash. 
# 
##################################################################

sub my_printing { 
    my ($sevArray, $component,$component_descriptor,$severity_name) = @_;
    my $severity;
    my $severity_index = 0;
    my $check_enum_flag = 0;
    my $instance_count = 1;
    log_msg("INFO ","Started printing of all the instances of $component for IP $opt{hostname}\n");
    for ($severity = 3 ; $severity >= 0; $severity-- ) {
        if (exists $sevArray->[$severity]){
            for ($severity_index = 0 ; exists $sevArray->[$severity][$severity_index]; $severity_index++){ 
                $printmsg = $printmsg . "#$instance_count ";
                my $print_index_key =  $sevArray->[$severity][$severity_index];
                $printmsg = $printmsg .  "$severity_name = $Nagios_ExitStatus_String_mapping{$list{$print_index_key}->{$severity_name}}, ";

                $printmsg = $printmsg .  "$component_descriptor = $list{$print_index_key}->{$component_descriptor}, ";
                delete $list{$print_index_key}->{$component_descriptor};
                delete $list{$print_index_key}->{$severity_name};

                if ( exists ($list{$print_index_key}->{'State'}) ) {
				    $printmsg = $printmsg . "State = $main_profile{$component}->{'enums'}->{'State'}->{$list{$print_index_key}->{'State'}}, ";
                    delete $list{$print_index_key}->{'State'}; 
                } 
                foreach my $list_key (sort keys %{$list{$print_index_key}}){
                    my $value_len = length($list{$print_index_key}->{$list_key});
                    if ($value_len != 0)
                    {
                        foreach my $enum_name (keys %{$main_profile{$component}->{'enums'}}){
                            if ($list_key eq $enum_name){     
                                if (exists $main_profile{$component}->{'enums'}->{$enum_name}->{$list{$print_index_key}->{$list_key}}){
                                    $printmsg = $printmsg . "$list_key = $main_profile{$component}->{'enums'}->{$enum_name}->{$list{$print_index_key}->{$list_key}}, ";
                                } else {
                                    $printmsg = $printmsg . "$list_key = Other($list{$print_index_key}->{$list_key}), "; 
                                }
                                $check_enum_flag = 1;
                                last;
                            }
                        }
                        if ($check_enum_flag != 1)
                        {
                            $printmsg = $printmsg . "$list_key = $list{$print_index_key}->{$list_key}, ";
                        }
                        $check_enum_flag = 0;
                    } 
                    else 
                    {
                        $printmsg = $printmsg . "$list_key = Not Available, ";
                    }
                }
                chop ($printmsg);
                chop ($printmsg);
                $printmsg = $printmsg . $nextline;
                $instance_count = $instance_count + 1;
            }
        }
    }
    $printmsg = substr ($printmsg, 0, -4);
}
 
##################################################################
# Func: collectDataforPowerSupply 
# Input: array of strings
# outout: array of strings
# Description : This function reads the Power Supply racadm output 
#                and collect the required values in array.
##################################################################
sub collectDataforPowerSupply
{
    my @data = @_;
    my $ressize = @data;
    my @temp ;
    log_msg("INFO ","Collecting Data of Power Supply component from RACADM result for IP $opt{hostname}.\n");
    for (my $i = 0; $i < $ressize; $i++)
    {
        if (index($data[$i] , "Overall Power Health") == 0)
        {
            my ($key,$value) = split(/=/, $data[$i], 2);            
            $value =~ s/^\s*//;     # Remove spaces at the start of the line
            $value =~ s/\s*$//;     # Remove spaces at the end of the line
            $ps_overall_health = uc($value);
        }
        elsif (index($data[$i] , "[Chassis Power Supply Status Table]") != -1)
        {
            for (my $j= $i; $j<$ressize; $j++)
            {
               if ( ( index(uc($data[$j]) , "PS") == 0 ) and length($data[$j]) > 124 )
               {
                   $data[$j] =~ s/^\s*//;     # Remove spaces at the start of the line
                   $data[$j] =~ s/\s*$//;     # Remove spaces at the end of the line
                   push @temp , $data[$j];
               }
            }
            last;
        }
    }
    return @temp;
}

##################################################################
# Func: filterPSDataReading 
# Input: array of strings
# outout: hash (key,value) 
# Description :  This function reads the Power Supply racadm output 
#                and collect the required values in hash.
##################################################################
sub filterPSDataReading
{
    my @data = @_; 
    my %pstemp;
    my $psname                   = "";
    my $inputCurrentReading      = "";
    my $inputVoltsReading        = "";
    my $outputRatedPowerReading  = "";
    log_msg("INFO ","Filtering required data of Power Supply component from RACADM result for IP $opt{hostname}\n");
    #iterate loop to collect different reading values
    foreach my $temps (@data)
    {
        #reseting reading variables to resuse and to set values in resultant hash
        $psname                  = "";
        $inputCurrentReading     = "";
        $inputVoltsReading       = "";
        $outputRatedPowerReading = "";
        my $psNameStart          = 0;
        my $psInCurrReadStart    = 55;
        my $psInVoltReadStart    = 78;
        my $psOpRatePwStart      = 101;
        $psname                  = substr $temps, $psNameStart, 15;       #Power Supply name at 1st position and length is 16 
        $inputCurrentReading     = substr $temps, $psInCurrReadStart, 23; #Power Supply Input Current Reading at 4th position and length is 23
        $inputVoltsReading       = substr $temps, $psInVoltReadStart, 23; #Power Supply Input Volts Reading at 5th position and length is 23
        $outputRatedPowerReading = substr $temps, $psOpRatePwStart;       #Power Supply Output Rated Power Reading at 6th position and length is 23
        
        $psname                  = uc removeSpaceAndAdditionalChar($psname,"");        
        $inputCurrentReading     = removeSpaceAndAdditionalChar($inputCurrentReading,"A");
        $inputVoltsReading       = removeSpaceAndAdditionalChar($inputVoltsReading,"V");
        $outputRatedPowerReading = removeSpaceAndAdditionalChar($outputRatedPowerReading,"W");     

        $pstemp{$psname}{'InputCurrent(A)'}      = $inputCurrentReading;
        $pstemp{$psname}{'InputVolts(V)'}        = $inputVoltsReading;
        $pstemp{$psname}{'OutputRatedPower(W)'}  = $outputRatedPowerReading;       
    }
    return %pstemp;
}


##################################################################
# Func: removeSpaceAndAdditionalChar 
# Input: string, and character to be removed
# outout: string without head and trail space 
# Description :  This function removes the unwanted characters
#                like space A, V, W from given string. 
##################################################################
sub removeSpaceAndAdditionalChar
{
    my $data         = shift;
    my $charToRemove = shift;
    
    #remove additional space from head and trail
    $data =~ s/^\s*//;
    $data =~ s/\s*$//; 
    #remove additional character
    if ($charToRemove ne "" && ($charToRemove eq "A" || $charToRemove eq "V" || $charToRemove eq "W"))
    {
        $data =~ tr/AVW//d;   #remove 'A', 'V' and 'W' character
        $data =~ s/^\s*//;
        $data =~ s/\s*$//;
    }
    return $data;
}
 
##################################################################
# Func: getRacadmResult 
# Input: racadm query, component name
# outout: racadm query response
# Description :  This function does racadm query and returns the 
#                response. 
##################################################################	
sub getRacadmResult
{
    my $query         = shift;
    my $componentName = shift;
    my %psData;
    my %ioData;    
    my %fanData;
	
    my $racadmKey     = $racadmdir;
    my $hostOpt       = " -r ";
    my $userNameOpt   = " -u ";
    my $pswdOpt       = " -p ";
    my $space         = " ";
	my $colon         = ":";

    my $hostaddr = $opt{hostname};
    if (ip_is_ipv6($hostaddr))
    {
        $hostaddr = '[' . $hostaddr . ']';
    }
    my $racadmQuery   = $racadmKey . $hostOpt . $hostaddr . $colon. $param{'port'} . $userNameOpt . $param{'username'} . $pswdOpt . $param{'password'} . $space . $query . " 2>&1";
    
    my @racadmRes = `$racadmQuery`;
    if ($componentName eq 'ps')
    {
        my @returnData = collectDataforPowerSupply(@racadmRes);
        %psData = filterPSDataReading(@returnData);
        log_msg("INFO ","RACADM query executed for Power Supply Component for IP $opt{hostname}\n");
        return %psData;
    }
    elsif ($componentName eq 'fan')
    {
        my @returnData = collectFanData(@racadmRes);
        %fanData = filterFanDataReading(@returnData);
        return %fanData;
    }
	elsif ($componentName eq 'io')
    {
        my @returnData = collectIOData(@racadmRes);
        %ioData = filterIODataReading(@returnData);
        return %ioData;
    }
}

##################################################################
# Func: collectFanData 
# Input: array of strings
# outout: array of strings
# Description : This function reads the Fan racadm output 
#                and collect the required values in array.
##################################################################
sub collectFanData
{
    my @data = @_;
    my $ressize = @data;
	my $count = 0;
    my @temp ;

    for (my $i = 0; $i < $ressize; $i++)
    {
        if ( $count < 2 )
        {
                $data[$i] =~ s/^\s*//;     # Remove spaces at the start of the line
                $data[$i] =~ s/\s*$//;     # Remove spaces at the end of the line
				if (index($data[$i] , "<senType>       <Num>           <sensorName>    <status>        <reading>") != -1)
                {
				    $count = $count + 1;
                }
				elsif ($data[$i] ne "" && $count !=0)
				{
				    push @temp , $data[$i];
                }
            
        }
    }

    return @temp;
}

##################################################################
# Func: filterFanDataReading 
# Input: array of strings
# outout: hash (key,value) 
# Description :  This function reads the Fan racadm output 
#                and collect the required values in hash.
##################################################################
sub filterFanDataReading
{
    my @data = @_; 
    my %fantemp;
    my $fannumber       = "";
    my $fanReading      = "";
	my $sensorname      = "";
	my $finalSpeedKey   = "";
	my $space           = " ";
	
	my $sensorLeftValue = "";
    my $sensorRightValue = "";
    #iterate loop to collect different reading values
    foreach my $temps (@data)
    {
        #reseting reading variables to reuse and to set values in resultant hash
        $fannumber      = "";
        $fanReading     = "";
        
        $fannumber      = substr $temps, 16, 16;    #Fan slot at 1st position and length is 16 
		$sensorname     = substr $temps, 32, 16;    #Fan sensorname at 1st position and length is 32
        $fanReading     = substr $temps, 64, 16;    #Fan speed Reading at 5th position and length is 64
		
        #remove additional space from head and trail
		$fannumber =~ s/^\s*//;
		$fannumber =~ s/\s*$//;
		$fanReading =~ s/^\s*//;
        $fanReading =~ s/\s*$//;
		$sensorname =~ s/^\s*//;
        $sensorname =~ s/\s*$//;
		
        #In case of M1000e, Racadm response for Fan Element Name comes with '-' in between (e.g. 'Fan-1')		
		#whereas in WSMAN response comes with space in between (e.g. 'Fan 1')
		if( index($sensorname, "-") != -1 )
		{
		    ($sensorLeftValue, $sensorRightValue) = split (/-/, $sensorname);
			$finalSpeedKey = uc $sensorLeftValue . $fannumber;

		} elsif( index($sensorname, " ") != -1 )
		{
		    ($sensorLeftValue, $sensorRightValue) = split (" ", $sensorname);
			$finalSpeedKey = uc $sensorLeftValue . $fannumber;
		} else
		{
		  
			$finalSpeedKey = uc $sensorname . $fannumber;
		}
		
        $fantemp{$finalSpeedKey}{'Speed'}      = $fanReading;    
    }

    return %fantemp;
}

##################################################################
# Func: collectIOData 
# Input: array of strings
# outout: array of strings
# Description : This function reads the IO racadm output 
#                and collect the required values in array.
##################################################################
sub collectIOData
{
    my @data = @_;
    my $ressize = @data;
    my @temp ;

    for (my $i = 0; $i < $ressize; $i++)
    {
		$data[$i] =~ s/^\s*//;     # Remove spaces at the start of the line
		$data[$i] =~ s/\s*$//;     # Remove spaces at the end of the line
		if (index($data[$i] , "Switch-") == 0)
		{
			push @temp , $data[$i];
		}            
    }

    return @temp;
}

##################################################################
# Func: filterIODataReading 
# Input: array of strings
# outout: hash (key,value) 
# Description :  This function reads the IO racadm output 
#                and collect the required values in hash.
##################################################################
sub filterIODataReading
{
    my @data = @_; 
    my %iotemp;
    my $switchname       = "";
	my $switchpresent    = "";
    my $switchstatus      = "";
	my $switchId         = "iom";
	my $finalSwitchKey   = "";
	
	my $switchLeftValue = "";
    my $switchRightValue = "";
    #iterate loop to collect different reading values
    foreach my $temps (@data)
    {
        #reseting reading variables to reuse and to set values in resultant hash
        $switchname      = "";
        $switchstatus    = "";
		$switchpresent   = "";
		
		$switchname      = substr $temps, 0, 16;     #IO switchname at 1st position and length is 0
		$switchpresent   = substr $temps, 16, 16;    #IO status at 2nd position and length is 16
        $switchstatus    = substr $temps, 48, 16;    #IO status at 4th position and length is 48
		
        #remove additional space from head and trail
		$switchname    =~ s/^\s*//;
		$switchname    =~ s/\s*$//;
		$switchpresent =~ s/^\s*//;
        $switchpresent =~ s/\s*$//;
		$switchstatus  =~ s/^\s*//;
        $switchstatus  =~ s/\s*$//;
			
		if( index($switchname, "-") != -1 )
		{
		    ($switchLeftValue, $switchRightValue) = split (/-/, $switchname);
			$finalSwitchKey = $switchId . $switchRightValue;
		}
		
		if( $switchpresent eq "Present" )
		{
		    $iotemp{$finalSwitchKey}{'Status'}      = $switchstatus; 
		}   
    }

    return %iotemp;
}


##################################################################
# Func: wsman_initialize 
# Input: No input
# outout: No Output
# Description :  This function intializes the wsman session object
#                which will be used for making wsman querries. 
##################################################################
sub wsman_initialize {
    my $wsman_status = 0;
    my $temp_username;
    my $temp_password;
    %param
      = (
        'hostname'         => $opt{hostname},
        'username'         => undef,
        'password'         => undef,
        'timeout'          => undef,
        'port'             => undef,
        'certificateCheck' => undef,
    );
    
    # Try to initialize the wsman session
    #  Creating option object 
    $option = new openwsman::ClientOptions::()
        or  $wsman_status = 1;
    if ($wsman_status == 1) {
        print "Error while creating Wsman Session: ";
        log_msg("CRITICAL ","Error while creating Wsman clientoption Session.\n");
        exit $UNKNOWN;
    } else {
        log_msg("INFO ","Success while creating Wsman clientoption Session.\n");
    }
    
    my $filename = undef;
    my @wsman_params;

    if (defined $opt{'filepath'}) {
        $filename = $opt{'filepath'};
    } elsif(defined $opt{servicename}){
        my $file_check  = $nagioshomedir . "/dell/config/objects/" . $opt{hostname} . ".cfg";
        if( -e $file_check) {
            $filename = $file_check;
        } else {
            my $fqdnName = gethostbyaddr(inet_aton("$opt{hostname}"), AF_INET);
            $file_check = $nagioshomedir . "/dell/config/objects/" . $fqdnName . ".cfg";
            if ( -e $file_check) {
                $filename = $file_check;
            }
        }
    }

    if (defined $filename){   
        if(open(my $fh, "<", $filename) ) {
            log_msg("INFO ", "Success in opening the wsman file $filename\n");
            while (my $row = <$fh>) {
                chomp $row;
                if(index($row, "_dell_comm_params") != -1){
                    $row =~ s/\s//g;
                    $row = substr($row,17);
                    @wsman_params = split(',',$row);
                    last;
                }
 
            }
            if($wsman_params[0] eq 'WSMAN'){
                $temp_username              = $wsman_params[1];
                $temp_password              = $wsman_params[2];
                $param{'timeout'}           = $wsman_params[3];
                $param{'port'}              = $wsman_params[4];
                $param{'certificateCheck'}  = $wsman_params[5];
                $param{'retries'}           = $wsman_params[6];
            }  else {
                print "CRITICAL: Internal Error - Invalid wsman params\n";
                log_msg("CRITICAL", "Internal Error - Invalid wsman params\n");
                exit $UNKNOWN;
            }
            my $resource_file = $nagioshomedir . "/dell/resources/dell_resource.cfg";
            my $name;
            my $value;

            if ( -e $resource_file){
                if(open(my $rfh, "<", $resource_file)){
                    my $checkCount = 0; 
                    while (my $resource_row = <$rfh> ) {
                        chomp $resource_row;
                        $resource_row =~ s/^\s+|\s+$//g; 
                        if ( ($resource_row !~ /^#/) && ($resource_row ne "") ){    # Ignore lines starting with # and blank lines
                            ($name, $value) = split (/=/, $resource_row);          # Split each line into name value pairs
                            $value =~ s/^\s+|\s+$//g;     # Remove spaces from both end
                            $name =~ s/^\s+|\s+$//g;
                            
                            
                            if ($name eq $temp_username){
                                if ( $value ne "") {
                                    $checkCount++;
                                    $param{'username'} = $value;
                                } else {
                                    print "CRITICAL: Macro $name is not configured in the resource file: $filename\n";
                                    log_msg("CRITICAL", "Macro $name is not configured in the resource file: $filename\n");
                                    exit $UNKNOWN;
                                }
                            }elsif ($name eq $temp_password){
                                if ($value ne "" ){
                                    $checkCount++;
                                    $param{'password'} = $value;
                                } else {
                                    print "CRITICAL: Macro $name is not configured in the resource file: $filename\n";
                                    log_msg("CRITICAL", "Macro $name is not configured in the resource file: $filename\n");
                                    exit $UNKNOWN;
                                }
                                
                            }
                            if($checkCount == 2){
                                last;
                            }
                        } 
                    }
                }else {
                    print "CRITICAL: Error in opening resource file: $resource_file\n";
                    log_msg("CRITICAL", "Error in opening resource file: $resource_file.\n");
                    exit $UNKNOWN;
                }
            } else {
                print "CRITICAL: Missing resource file: $resource_file\n";
                log_msg("CRITICAL", "$resource_file not found.\n");
                exit $UNKNOWN;
            }
        } else {
            print "CRITICAL: Error in opening the file $filename\n";
            log_msg("CRITICAL", "Error in opening the file $filename\n");
            exit $UNKNOWN;
        }
    } else {
        print "CRITICAL: Filepath is invalid : $filename\n";
        log_msg("CRITICAL", "Filepath is invalid : $filename\n");
        exit $UNKNOWN;
    }
    
    my $calculated_timeout = ($param{'timeout'} * ($param{'retries'} + 1) + 120);
    $plugin_timeout = $plugin_timeout > $calculated_timeout ? $plugin_timeout: $calculated_timeout ;

    $wsman_client = new openwsman::Client::($param{'hostname'},
                                               $param{'port'},
                                               '/wsman', 
                                               'https',
                                               $param{'username'},
                                               $param{'password'})

        or $wsman_status = 1;
    if ($wsman_status == 1) {
        print "Error while creating Wsman client Session";
        log_msg("CRITICAL ","Error while creating Wsman client Session.\n");
        exit $UNKNOWN;
    } else {
        log_msg("INFO ","Success while creating Wsman client Session.\n");
    }

    $filter = new openwsman::Filter::()
      or $wsman_status = 1;
    if ($wsman_status == 1) {
        print "Error while creating Wsman Filter Session";
        log_msg("CRITICAL ","Error while creating Wsman Filter Session.\n");
        exit $UNKNOWN;
    } else {
        log_msg("INFO ","Success while creating Wsman Filter Session.\n");
    }

    $wsman_client->transport()->set_auth_method($openwsman::BASIC_AUTH_STR);
    $wsman_client->transport()->set_timeout($param{'timeout'});

    if ($param{'certificateCheck'} == 0) {
        openwsman::wsman_transport_set_verify_peer($wsman_client, 0);
        openwsman::wsman_transport_set_verify_host($wsman_client, 0);
    }

    return;
}

sub get_wsman_result{
    my ($uri,$selector,$merge_attribute) = @_;
    my $final_uri = $fixed_uri . $uri  ;
    my $selector_counter = 0;

    for ($selector_counter = 0 ; $selector_counter <  $#{$selector} + 1   ; $selector_counter = $selector_counter + 2 ){
        $option->add_selector ($selector->[$selector_counter],$selector->[$selector_counter + 1 ] );
    }  
    my $result = $wsman_client->get($option,  $final_uri);
    unless($result && $result->is_fault eq 0) {
        if (( defined $result) and (defined $result->fault)) {
            print "WSMAN Error while retreiving data: ", $result->fault->reason ;
        } else {
            print "WSMAN Error while communicating with host $opt{'hostname'}";
        }
        log_msg("CRITICAL ","WSMAN Error while retreiving data\n");
        exit $UNKNOWN;
    }

    my $info = $result->body()->child();

    my $items;
    for((my $cnt = 0) ; ($cnt<$info->size()) ; ($cnt++)) {
        $items->{$info->get($cnt)->name()} = $info->get($cnt)->text();
    }

    foreach my $items_keys ( keys %{$items}){
        $temp_list{$items->{$merge_attribute}}->{$items_keys} = $items->{$items_keys};
    }

}

sub enumerate_wsman_result{

    my ($uri,$filter_query,$selector,$merge_attribute,$max_elements) = @_;
    my $result = undef;
    my $final_uri = $fixed_uri . $uri  ;
    my $selector_counter = 0;
    for ($selector_counter = 0 ; $selector_counter <  $#{$selector} + 1   ; $selector_counter = $selector_counter + 2 ){
        $option->add_selector ($selector->[$selector_counter],$selector->[$selector_counter + 1 ] );
    } 
    if (defined $max_elements) {
        $option->set_flags($openwsman::FLAG_ENUMERATION_OPTIMIZATION);
        $option->set_max_elements($max_elements);
    }

    my $count = 0;
    my $test_flag = 1;
    for ($count = 0; (($count < ($param{'retries'} + 1)) and ($test_flag == 1)) ; $count = $count + 1){ 
        if( defined $filter_query){
            $filter->wql($filter_query);
            $result = $wsman_client->enumerate($option, $filter, $final_uri);
        } else {
            $result = $wsman_client->enumerate($option, undef, $final_uri);
        }

        unless($result && $result->is_fault eq 0) {
            $test_flag = 1;
            next;
        }
        $test_flag = 0;
        
    }
    if ($test_flag == 1){
        if (( defined $result) and (defined $result->fault)) {
                print "WSMAN Error while retreiving data: ", $result->fault->reason ;
                log_msg("CRITICAL ",$result->fault->reason);
            } else {
                print "WSMAN Error while communicating with host $opt{'hostname'}";
                log_msg("CRITICAL ","WSMAN Error while communicating with host $opt{'hostname'}");
        }
        exit $UNKNOWN;
    }
    
    my $nodes = $result->body()->find(undef, "Items");
    if (defined $nodes){
        my $node;
        for((my $cnt1 = 0) ; ($cnt1<$nodes->size()) ; ($cnt1++)) {
            my $items;
            $node = $nodes->get($cnt1);
            for((my $cnt2 = 0) ; ($cnt2<$node->size()) ; ($cnt2++)) {
                $items->{$node->get($cnt2)->name()} = $node->get($cnt2)->text();
            }
            my $creationClassName = $items->{'CreationClassName'};
            my $Name              = $items->{'Name'};
            if ($creationClassName eq "Dell_IOMPackage")
            {
                delete $items->{'Name'};
                $items->{'IOModuleName'} = $Name;
                $creationClassName = "";
            }
            foreach my $items_keys ( keys %{$items}){
                $temp_list{$items->{$merge_attribute}}->{$items_keys} = $items->{$items_keys};

            }
        }
    }
    # Get context.
    my $context = $result->context();

    while($context) {
        $result = $wsman_client->pull($option, $filter, $final_uri, $context);

        next unless($result);
        $nodes = $result->body()->find(undef, "Items");
        if (defined $nodes){
            my $node;
            for((my $cnt1 = 0) ; ($cnt1<$nodes->size()) ; ($cnt1++)) {
                my $items;
                $node = $nodes->get($cnt1);
                for((my $cnt2 = 0) ; ($cnt2<$node->size()) ; ($cnt2++)) {
                    $items->{$node->get($cnt2)->name()} = $node->get($cnt2)->text();
                }
                foreach my $items_keys ( keys %{$items}){
                    $temp_list{$items->{$merge_attribute}}->{$items_keys} = $items->{$items_keys};
                }
            }
        }
        $context = $result->context();
    }
    # Release context.
    $wsman_client->release($option, $uri, $context) if($context);

}

sub get_Chassis_Information{
    foreach my $profile ( @chassis_information_profile ){
        enumerate_wsman_result($profile->{'uri'},
                               $profile->{'filter_value'},
                               $profile->{'selector'}, 
                               $profile->{'merge_attribute'});
        update_chassis_Information($profile->{'key_attribute'});    
    }

    print_chassis_info();
    exit $OK;
}

sub update_chassis_Information{

    my ($key_attribute) = @_;
    foreach my $key ( keys %temp_list){
        my $temp_hash = $temp_list{$key};     
        if( (defined $key_attribute) and  (defined $temp_hash->{$key_attribute})){
            $list{$temp_hash->{$key_attribute}} = $temp_hash->{"CurrentValue"};
        }else {
            foreach my $keys ( keys %$temp_hash){
                if (($temp_hash->{$keys} ne "") && ($keys ne "InstanceID"))    {
                    $list{$keys} = $temp_hash->{$keys};
                }
            }
        }
    }
}

sub print_chassis_info {

    for (my $list_counter = 0 ; $list_counter <  @chassis_info_item_list ; $list_counter = $list_counter + 1 ){
        if (($list{"URLString"} eq "") || ( uc($list{"URLString"}) eq "NULL" )) {
            if (ip_is_ipv6($opt{hostname}))
            {
                $list{"URLString"} = "https://[$opt{hostname}]";
            }
            else
            {
                $list{"URLString"} = "https://$opt{hostname}";
            }
        }
        if ((defined $list{$chassis_info_item_list[$list_counter]}) and ( length($list{$chassis_info_item_list[$list_counter]}) ne 0)) {
            $printmsg = $printmsg . "$chassis_info_map_print{$chassis_info_item_list[$list_counter]} = $list{$chassis_info_item_list[$list_counter]}$nextline";
        } else {
            $printmsg = $printmsg . "$chassis_info_map_print{$chassis_info_item_list[$list_counter]} = Not Available$nextline";
        }
    }
    $printmsg =~ s/^\s+|\s+$//g;
    print $printmsg = substr($printmsg, 0, -length($nextline));

}

sub print_chassis_pci {
	my $instance_count = 1;
	foreach my $pciinstance ( keys %list){
		 $printmsg = $printmsg . "#$instance_count ";
		for (my $list_pci_counter = 0 ; $list_pci_counter <  @chassis_pci_item_list ; $list_pci_counter = $list_pci_counter + 1 ){
			if ((defined $list{$pciinstance}->{$chassis_pci_item_list[$list_pci_counter]}) and ( length($list{$pciinstance}->{$chassis_pci_item_list[$list_pci_counter]}) ne 0)) {
				$printmsg =  $printmsg ."$chassis_pci_item_list[$list_pci_counter] = $list{$pciinstance}->{$chassis_pci_item_list[$list_pci_counter]}, ";
			} else {
				$printmsg = $printmsg . "$chassis_pci_item_list[$list_pci_counter] = Not Available, ";
			}
			}
		$printmsg = substr($printmsg, 0, -2);
		$printmsg = $printmsg.$nextline;
		$instance_count = $instance_count + 1;
	}
    $printmsg =~ s/^\s+|\s+$//g;
    print $printmsg = substr($printmsg, 0, -length($nextline));

}


############################################################
# MAIN Function
############################################################

# Initialize wsman

log_msg("INFO ","...Service is STARTED for the IP $opt{'hostname'} and component $opt{'component'}...\n");
log_msg("INFO ", "Log initializing\n");
wsman_initialize();

# Setting timeout
$SIG{ALRM} = sub {
    print "PLUGIN TIMEOUT: dell_check_chassis.pl timed out after $plugin_timeout seconds$nextline";
    exit $UNKNOWN;
};

alarm $plugin_timeout;

# Check Arguments
if (defined $opt{'component'}){
    if(lc$opt{'component'} eq 'info'){    
       get_Chassis_Information();
    } elsif (lc$opt{'component'} eq 'ghs' ) {
        get_chassis_component_health('ghs','Status', 'Overall Chassis','Enumerate',$max_elements_map{'lowest_max_element'},$check_overall_health{'no'});
    } elsif (lc$opt{'component'} eq 'ps' ) {
        get_chassis_component_health('ps','FQDD','Status','Enumerate',$max_elements_map{'average_max_element'},$check_overall_health{'no'});
    } elsif(lc$opt{'component'} eq 'fan') {
        get_chassis_component_health('fan','FQDD', 'Status','Enumerate',$max_elements_map{'maximum_max_element'},$check_overall_health{'no'});
    } elsif(lc$opt{'component'} eq 'io') {
        get_chassis_component_health('io','FQDD', 'Status','Enumerate',$max_elements_map{'maximum_max_element'},$check_overall_health{'no'});
    } elsif(lc$opt{'component'} eq 'kvm'){
        get_chassis_component_health('kvm','Name', 'Status','Enumerate',$max_elements_map{'maximum_max_element'},$check_overall_health{'no'});
	} elsif(lc$opt{'component'} eq 'slot'){
        get_chassis_component_health('slot','SlotNumber', 'Status','Enumerate',$max_elements_map{'maximum_max_element'},$check_overall_health{'no'});
	} elsif(lc$opt{'component'} eq 'pd'){
        get_chassis_component_health('pd','FQDD', 'Status','Enumerate',$max_elements_map{'maximum_max_element'},$check_overall_health{'no'});
	} elsif(lc$opt{'component'} eq 'vd'){
        get_chassis_component_health('vd','FQDD', 'Status','Enumerate',$max_elements_map{'maximum_max_element'},$check_overall_health{'no'});
	} elsif(lc$opt{'component'} eq 'enc'){
        get_chassis_component_health('enc','FQDD', 'Status','Enumerate',$max_elements_map{'maximum_max_element'},$check_overall_health{'no'});
	} elsif(lc$opt{'component'} eq 'ctl'){
        get_chassis_component_health('ctl','FQDD', 'Status','Enumerate',$max_elements_map{'maximum_max_element'},$check_overall_health{'no'});
    } elsif(lc$opt{'component'} eq 'pci'){
        get_chassis_component_health('pci','FQDD', 'Status','Enumerate',$max_elements_map{'maximum_max_element'},$check_overall_health{'no'});
    }
    else {
        print "Invalid component name $opt{'component'}$nextline";
        log_msg ("CRITICAL", "Invalid component name $opt{'component'}\n");
        exit $UNKNOWN;
    }
}

#-----------------------------------------------------------------
# Simple log-writing method
#-----------------------------------------------------------------

sub log_msg
{
    my ($severity,$message) = @_;

    my $tm = localtime(time);
    # time in following format : 2013-01-16 18:57:37 
    my $current_time = sprintf '%d-%02d-%02d %02d:%02d:%02d ', $tm->year + 1900, $tm->mon+1, $tm->mday, $tm->hour , $tm->min , $tm->sec;    
    
    eval
    {
        $message = $current_time . q{ } . $severity . q{ } . q{Dell_} . $opt{'component'} . q{ } . "_WSMAN " . $opt{'hostname'} . q{ } .  $message ;    

        if ($opt{opt_log})
        {
            open(FILE,">>$opt_logfile") ;
            print FILE "$message" or warn "Error writing $message to $opt_logfile: $!";
            close FILE;
        }
    };
    return 1;
}
