#! /usr/bin/perl

##########################################################################
#Title:         Dell Device Plugin Script
#Version:       2.0 
#Creation Date: 22nd May 2015
#Description:   This script provides Dell EqualLogic overall health 
#               and component health. 
#
#Copyright (c) 2015 Dell Inc.
#All Rights Reserved.
##########################################################################

use Getopt::Long qw(:config no_ignore_case);
use Time::localtime;
use File::Spec;
use Net::IP qw(:PROC);

# Global (package) variables used throughout the code
use vars qw($OK $WARNING $CRITICAL $UNKNOWN $HELP 
            $snmp_session $snmp_error $nextline 
            %opt %Nagios_ExitStatus_String_mapping 
    );

our $plugin_timeout = 15;
our $printmsg = "";
our $final_exit_code = undef;
our $invalid_ipv4 = "0.0.0.0";
our $eqlInetAddrEntIfName = '1.3.6.1.4.1.12740.1.1.1.1.54';

#Exit Codes
$OK       = 0;
$WARNING  = 1;
$CRITICAL = 2;
$UNKNOWN  = 3;

# Error Code for Nagios Number to String 
%Nagios_ExitStatus_String_mapping = (
    'OK'         => $OK,
    'WARNING'    => $WARNING,
    'CRITICAL'   => $CRITICAL,
    'UNKNOWN'    => $UNKNOWN,
);


my $eqlMemberIdx = "";

############################################################
# EQL Info
############################################################

#EQL inventory OIDs and corresponding display names
our %eqlMem_oid = (
        '1.3.6.1.4.1.12740.2.1.1.1.9.1'  	 =>'Name',
		'1.3.6.1.4.1.12740.2.1.11.1.9.1' 	 =>'Product Family',
		'1.3.6.1.4.1.12740.2.1.11.1.8.1' 	 =>'Service Tag',
		'1.3.6.1.4.1.12740.2.1.11.1.1.1' 	 =>'Model',
		'1.3.6.1.4.1.12740.2.1.11.1.7.1' 	 =>'Chassis Type',
		'1.3.6.1.4.1.12740.2.1.11.1.4.1' 	 =>'Disk Count',
		'1.3.6.1.4.1.12740.2.1.13.1.1.1' 	 =>'Raid Status',
		'1.3.6.1.4.1.12740.2.1.10.1.1.1' 	 =>'Capacity',
		'1.3.6.1.4.1.12740.2.1.10.1.2.1' 	 =>'Used Storage',
		'1.3.6.1.4.1.12740.2.1.1.1.21.1' 	 =>'Controller Major Version',
		'1.3.6.1.4.1.12740.2.1.1.1.22.1' 	 =>'Controller Minor Version',
		'1.3.6.1.4.1.12740.2.1.1.1.23.1' 	 =>'Controller Maintenance Version',
    );
our %eqlRaidPolicy_oid = (
		'1.3.6.1.4.1.12740.2.1.15.1.3.1' 	 =>'Raid Policy',		
    );
	
our %eqlGrp_oid = (
		'1.3.6.1.4.1.12740.1.1.1.1.19' 	 =>'Group Name',
		'1.3.6.1.4.1.12740.1.1.1.1.20' 	 =>'Group IP',
		'1.3.6.1.4.1.12740.1.1.2.1.13' 	 =>'Member Count',
		'1.3.6.1.4.1.12740.1.1.2.1.12' 	 =>'Volume',
    );
	
our %eqlPool_oid = (
		'1.3.6.1.4.1.12740.16.1.1.1.3' 	 =>'Storage Pool',		
    );
	
our %eqlPoolIndex_oid = (
		'1.3.6.1.4.1.12740.2.1.15' 	 =>'Storage Pool Index',		
    );
	
our %eqlChassisType = (
		'0' => 'unknown',
		'1' => 't1403',
		'2' => 't1603',
		'3' => 't4835',
		'4' => 'tDELLSBB2u1235',
		'5' => 'tDELLSBB2u2425',
		'6' => 'tDELLSBB4u2435',
		'7' => 'tDELL2WB1425V1',
		'8' => 'tDELLSBB5u6035',
		'9' => 'tDELLQAR5u8435',
	);
	
our %eqlMemberRaidStatus = (
		'1' => 'Ok',
		'2' => 'Degraded',
		'3' => 'Verifying',
		'4' => 'Reconstructing',
		'5' => 'Failed',
		'6' => 'CatastrophicLoss',
		'7' => 'Expanding',
		'8' => 'Mirroring',
	);

our %eqlDriveGroupRaidPolicy = (
		'0'  => 'Unconfigured',
		'1'  => 'RAID 50',
		'2'  => 'RAID 10',
		'3'  => 'RAID 5',
		'4'  => 'RAID 50-nospares',
		'5'  => 'RAID 10-nospares',
		'6'  => 'RAID 5-nospares',
		'7'  => 'RAID 6',
		'8'  => 'RAID 6-nospares',
		'9'  => 'RAID 6-accelerated',
		'10' => 'Hvs-storage',
	);

our %memghs_overall_oid = (
        '1.3.6.1.4.1.12740.2.1.5.1.1.1' => 'Overall Member',
    );
	
our %complete_memghs = (
        'oid'           => \%memghs_overall_oid,
	);

#############################################################
#  Member Physical Disk related OID and enums 
############################################################
our %memphydisk_oid
      = (
        '1.3.6.1.4.1.12740.3.1.1.1.8'     =>'Status',
        '1.3.6.1.4.1.12740.3.1.1.1.11'    =>'Slot',
        '1.3.6.1.4.1.12740.3.1.1.1.3'     =>'Model',
        '1.3.6.1.4.1.12740.3.1.1.1.5'     =>'SerialNumber',
        '1.3.6.1.4.1.12740.3.1.1.1.4'     =>'FirmwareVersion',
        '1.3.6.1.4.1.12740.3.1.1.1.6'     =>'TotalSize(GB)',
    );

our %memphydisk_Status_map = (
        1  => 'online',
        2  => 'spare',
        3  => 'failed',
        4  => 'offline',
        5  => 'alt-sig',
        6  => 'too-small',
        7  => 'history-of-failures',
        8  => 'unsupported-version',
        9  => 'unhealthy',
        10 => 'replacement',
        11 => 'encrypted',
        12 => 'notApproved',
        13 => 'preempt-failed',
    );
	
our %memphydisk_enums = (
        'Status'         => \%memphydisk_Status_map,
    );

our %complete_memphydisk = (
        'oid'           => \%memphydisk_oid,
        'enums'         => \%memphydisk_enums,
    );
############################################################
# EqualLogic Group Volume Status
############################################################

our %grpvol_oid
      = (
        '.1.3.6.1.4.1.12740.5.1.7.1.1.4'   =>'Name',
        '.1.3.6.1.4.1.12740.5.1.7.1.1.8'   =>'TotalSize(GB)',
        '.1.3.6.1.4.1.12740.5.1.7.7.1.8'   =>'Status',
        '.1.3.6.1.4.1.12740.5.1.7.1.1.22'  =>'StoragePollIndex',
        );

our %grpvol_strgpoll_oid
      = (
        '.1.3.6.1.4.1.12740.16.1.1.1.3'    =>'AssociatedPool',
        );
        
our %grpvol_strgpoll_state_map
      = (
         1  => 'online',
         2  => 'offline',
         3  => 'offline (snap reserve met)',
         4  => 'offline (member down)',
         5  => 'offline (lost blocks)',
         6  => 'offline (thin max grow met)',
         7  => 'offline (nospace auto grow)',
         8  => 'offline (missing pages)',
         9  => 'unavailable due to SyncRep',
         10 => 'available (no new connections)',
         11 => 'unavailable due to internal error',
        );

our %complete_grpvol = (
        'oid'               => \%grpvol_oid,
        'strgpoloid'        => \%grpvol_strgpoll_oid,
    );
    
############################################################
# EqualLogic Group Storage Pool details
############################################################
our %grpstor_oid
      = (
        '.1.3.6.1.4.1.12740.16.1.1.1.3'   =>'Name',
        '.1.3.6.1.4.1.12740.16.1.2.1.8'   =>'MemberCount',
        '.1.3.6.1.4.1.12740.16.1.2.1.16'  =>'VolumeCount',
        );

our %complete_grpstor = (
        'oid'               => \%grpstor_oid,
    );

########################################
# All OID in a hash with its references.
########################################
our %main_oid = (
			'memghs'           => \%complete_memghs,
			'mempd'            => \%complete_memphydisk,
			'grpvol'           => \%complete_grpvol,
			'grpstor'          => \%complete_grpstor,
	);

#########################################
our %memghs_mapping = (
		0	=> 'UNKNOWN',
		1	=> 'OK',
		2	=> 'WARNING',
		3	=> 'CRITICAL',
	);

############################################################
# Func:         get_compellent_component_health
# Input:        Component name, Severity name, overall health check flag 
# Output:       No output.
# Description:  Main function which is getting callled by each component
#               and calling other function to display the status 
#               of the component.
############################################################

sub get_eql_component_health {
	
	my ($component,$severity_name,$slot,$check_overall_health) = @_;
	my %output = ();
	my @severity_array = ();
    my $result = undef;
	my $tmpStatus = undef;
	my $tempoid = undef;
	my $oid = $main_oid{$component}->{'oid'};
	
    $result = $snmp_session->get_entries(-columns => [keys %{$oid}]);
	
	if ((!defined $result)) 
	{
        print "ERROR: SNMP : ", $snmp_session->error;
        log_msg("CRITICAL", $snmp_session->error);
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
        exit $UNKNOWN;
    }
	else 
	{
        log_msg("INFO", "Success in getting value from Dell agent.\n");
    }
	
	if ($component eq 'memghs')
	{

	    foreach my $resultoid ( keys %{$result}) 
		{
			$tempoid = $resultoid;
			$tempoid =~ s/^\s+|\s+$//g;
			
			my $eqlMemHealthOid = "1.3.6.1.4.1.12740.2.1.5.1.1";
			my $eqlGrpId 		= "1";
				
			if(("$tempoid" eq "$eqlMemHealthOid.$eqlGrpId.$eqlMemberIdx") && (length($result->{$resultoid}) != 0 ))
			{
				$tmpStatus = $memghs_mapping{$result->{$resultoid}};
				if ((!defined $tmpStatus)) 
				{
					$tmpStatus = 'UNKNOWN';
				}
				$printmsg = $printmsg . "$memghs_overall_oid{substr($resultoid, 0, -(length($eqlMemberIdx)+1) )} = $tmpStatus";
				$final_exit_code = $Nagios_ExitStatus_String_mapping{$tmpStatus};
			}
		}
	}
    else
    {
        %output = %{arrange_result($result, $oid) };

        if( !%output)
        {
            print "Component Information = UNKNOWN";
            exit $UNKNOWN;
        }
        my $count = 1;

        if ($component eq "grpvol")
        {
            #get the associated storage pool name
            my $result2 = $snmp_session->get_entries(-columns => [keys %{$main_oid{$component}->{'strgpoloid'}}]);

            my $criticalExit = undef;
            my $okExit       = undef;
            foreach my $temp (keys %output)
            {
                my $volumeName          = setNAValue($result->{'.1.3.6.1.4.1.12740.5.1.7.1.1.4.' .$temp});
                if ($volumeName ne "vss-control" && $volumeName ne "pe-control-vol" && $volumeName ne "xpr-control-vol")
                {
                    #capacity size in GB
                    my $volumeSizeinGB  = setNAValue($result->{'.1.3.6.1.4.1.12740.5.1.7.1.1.8.' .$temp});
                    if ($volumeSizeinGB ne "Not Available")
                    {
                        $volumeSizeinGB = sprintf '%.2f', $volumeSizeinGB /1024;
                    }
                    #volume Status
                    my $volumeStateVal  = $result->{'.1.3.6.1.4.1.12740.5.1.7.7.1.8.' .$temp};
                    my $volumeState     = setNAValue($grpvol_strgpoll_state_map{$volumeStateVal});
                    #associated storage pool 
                    my $strgPoolIndex   = $result->{'.1.3.6.1.4.1.12740.5.1.7.1.1.22.' .$temp};
                    my $strgPoolName    = setNAValue($result2->{'.1.3.6.1.4.1.12740.16.1.1.1.3.1.' .$strgPoolIndex});

                    $printmsg = $printmsg . "#$count" . " Status = " .          $volumeState
													  . ", Name = " .            $volumeName
                                                      . ", TotalSize(GB) = " .   $volumeSizeinGB
                                                      . ", AssociatedPool = " . $strgPoolName . $nextline;
                    $count++;
                    if ($volumeStateVal > 2 && $volumeStateVal != 10) 
                    { 
                        $criticalExit = $CRITICAL;
                    }
                    elsif($volumeStateVal == 1 || $volumeStateVal == 2 || $volumeStateVal == 10)
                    {
                        $okExit = $OK;
                    }
                }
            }

            if (defined $criticalExit)
            {
                $final_exit_code = $CRITICAL;
            }
            elsif (defined $okExit)
            {
                $final_exit_code = $OK;
            }
            else
            {
                $final_exit_code = $UNKNOWN;
            }
        }
        elsif ($component eq "grpstor")
        {
            my $hashSize = keys %output;

            foreach my $temp (keys %output)
            {
                $printmsg = $printmsg . "#$count" . " Name = "      . setNAValue($result->{'.1.3.6.1.4.1.12740.16.1.1.1.3.' .$temp})
                                               . ", MemberCount = " . setNAValue($result->{'.1.3.6.1.4.1.12740.16.1.2.1.8.' .$temp})
                                               . ", VolumeCount = " . setNAValue($result->{'.1.3.6.1.4.1.12740.16.1.2.1.16.' .$temp}) . $nextline;
                $count++;
            }
            if ($hashSize > 0)
            {
                $final_exit_code = $OK;
            }
            else
            {
                $final_exit_code = $UNKNOWN;
            }
        }  
        elsif($component eq 'mempd')
        {

            foreach my $pdkey (keys %output)
            {
                if (defined $output{$pdkey}->{'TotalSize(GB)'})
                {
                    $output{$pdkey}->{'TotalSize(GB)'} = sprintf '%.2f', $output{$pdkey}->{'TotalSize(GB)'} / 1024;
                }
            }

            @severity_array = @{severity_arrange($component, $severity_name, \%output)};

            my_printing(\@severity_array,\%output, $component,$severity_name,$slot);

            if ($check_overall_health == 0) 
            {
                if(defined $severity_array[2][0])
                {
                    $final_exit_code = $CRITICAL;
                } 
                elsif (defined  $severity_array[1][0]) 
                {
                    $final_exit_code = $WARNING;
                }
                elsif (defined  $severity_array[0][0]) 
                {
                    $final_exit_code = $OK;
                } 
                else 
                {
                    #Set exit code UNKNOWN
                    $final_exit_code = $UNKNOWN;
                }
            }
        }
		if(length($printmsg) == 0)
		{
			$printmsg = $printmsg .  "Component Information = UNKNOWN";
			$final_exit_code = $UNKNOWN;
		}
		else
		{
			$printmsg = substr ($printmsg, 0, -4);
		}
    }
	
    if(defined $opt{servicename}){
        my $command = $nagioshomedir . "/libexec/eventhandlers/submit_check_result " .  $opt{hostname} . q{ } . "\"" .$opt{servicename}."\""  . q{ } . $final_exit_code . q{ } . "\"" . $printmsg . "\"";
        system($command);
    } else {
        print $printmsg;
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
        exit $final_exit_code;
    }
}

##################################################################
# If value is invalid then set value to "Not Available" 
##################################################################
sub setNAValue
{
   my $value = shift;
   if ($value =~ /^\s*$/) 
   {
       $value = "Not Available";
   }
   return $value;
}

##################################################################
# Func :         my_printing
# Input:         severity_array, arranged result hash, component name, severity name, 
# Output:        NO output
# Description :  This function prints all the instances of the component 
#                by iterating through the array and hash. 
# 
##################################################################

sub my_printing {
    my ($sevArray, $output, $component,$severity_name,$slot) = @_;
    my $severity;
    my $severity_index = 0;
	my $check_enum_flag = 0;
    my $instance_count = 1;
	
    for ($severity = 3 ; $severity >= 0; $severity-- ) {
        if (exists $sevArray->[$severity]){
            for ($severity_index = 0 ; exists $sevArray->[$severity][$severity_index]; $severity_index++){
                $printmsg = $printmsg . "#$instance_count ";
                my $print_index_key =  $sevArray->[$severity][$severity_index];

                $printmsg = $printmsg .  "$severity_name = $main_oid{$component}->{'enums'}->{'Status'}->{$output->{$print_index_key}->{'Status'}}, ";
				$printmsg = $printmsg .  "$slot = $output->{$print_index_key}->{'Slot'}, ";

                delete $output->{$print_index_key}->{$severity_name};
				delete $output->{$print_index_key}->{$slot};

                delete $output->{$print_index_key}->{$severity_name};

                foreach my $output_key (sort keys %{$output->{$print_index_key}})
				{
					my $value_len = length($output->{$print_index_key}->{$output_key});
					if ($value_len != 0)
					{
						foreach my $enum_name (keys %{$main_oid{$component}->{'enums'}})
						{
							if ($output_key eq $enum_name){     
								if (exists $main_oid{$component}->{'enums'}->{$enum_name}->{$output->{$print_index_key}->{$output_key}}){
									$printmsg = $printmsg . "$output_key = $main_oid{$component}->{'enums'}->{$enum_name}->{$output->{$print_index_key}->{$output_key}}, ";
								} else {
									$printmsg = $printmsg . "$output_key = Other($output->{$print_index_key}->{$output_key}), ";
								}
								$check_enum_flag = 1;
								last;
							}
						}
						if ($check_enum_flag != 1)
						{
							$printmsg = $printmsg . "$output_key = $output->{$print_index_key}->{$output_key}, ";
						}
						$check_enum_flag = 0;
					}
					else 
                    {
                        $printmsg = $printmsg . "$output_key = Not Available, ";
                    }
				}
                chop ($printmsg);
                chop ($printmsg);
                $printmsg = $printmsg . $nextline;
                $instance_count = $instance_count + 1;
            }
        }
    }
}

##################################################################
# Func: arrange_result
# Input: snmp query result, all oid hash
# outout: Return a reference of arranged result based on index value.
# Description :  This function takes snmp querry result and all oid 
#                hash reference and return a reference of arranged 
#                hash based on index
##################################################################
sub arrange_result {
    my ($result,$oidref) = @_;
    my %output = ();
    my $tempoid = undef;
    foreach my $refoid (keys %{$oidref}){
        $tempoid = $refoid . '.';
        foreach my $resoid (keys %{$result}){
            if ($resoid =~ /\Q$tempoid\E/) {
                my $key = length($resoid) - length($tempoid);
                my $key1 = substr $resoid,length($tempoid),$key;
                if ((index($key1 , $eqlMemberIdx) != -1) || ($eqlMemberIdx eq "NA") )
                {
                    my $value = ($result->{$resoid});
                    $value =~ s/^\s+|\s+$//g;
                    $output{$key1}{$oidref->{$refoid}} = $value;
                }
            }
        }
    }
    return \%output;
}

##################################################################
# Func: severity_arrange
# Input: severity name string, arranged snmp result hash 
# outout: Return an array of indexes based on severity.
# Description :  This function takes arranged snmp result hash and return
#                a array of indexes based on severity. 
##################################################################
sub severity_arrange {
    my ($component, $severity_name, $oidref) = @_;
    my @finaloutput = ();
    my $all_ok_index = 0;
    my $all_critical_index = 0;
    my $all_warn_index = 0;
	my $all_unknown_index = 0;

        foreach my $refoid (keys %{$oidref})
		{
            if( ($oidref->{$refoid}{$severity_name} == 1)  ||
			    ($oidref->{$refoid}{$severity_name} == 2)  ||
				($oidref->{$refoid}{$severity_name} == 5)  ||
				($oidref->{$refoid}{$severity_name} == 10) ||
				($oidref->{$refoid}{$severity_name} == 11) ) 
			{
                # All Ok status Index[0]
                $finaloutput[0][$all_ok_index] = $refoid;
                $all_ok_index = $all_ok_index + 1;
            } 
			elsif ( ($oidref->{$refoid}{$severity_name} == 4) ||
			        ($oidref->{$refoid}{$severity_name} == 7) ||
					($oidref->{$refoid}{$severity_name} == 9) ||
                    ($oidref->{$refoid}{$severity_name} == 12) ) 
			{
                # All Warning Status Index[1] 
                $finaloutput[1][$all_warn_index] = $refoid;
                $all_warn_index = $all_warn_index + 1;
            } 
			elsif ( ($oidref->{$refoid}{$severity_name} == 3) ||
                    ($oidref->{$refoid}{$severity_name} == 6) || 
					($oidref->{$refoid}{$severity_name} == 8) ||
					($oidref->{$refoid}{$severity_name} == 13) )
			{
                # All Critical Status Index[2]
                $finaloutput[2][$all_critical_index] = $refoid;
                $all_critical_index = $all_critical_index + 1;
            } 
			else 
			{
			    # All Unknown Status Index[3]
                $finaloutput[3][$all_unknown_index] = $refoid;
                $all_unknown_index = $all_unknown_index + 1;
			}
        }  
    return \@finaloutput;
}

sub get_eql_Info {

    snmp_initialize();
	
    my $finalString  = undef;
	
	if ($eqlMemberIdx ne "NA")
	{			
		my $resultEqlMem	= $snmp_session->get_entries(-columns => [keys %eqlMem_oid]);
		if (!defined $resultEqlMem ) {
			log_msg("ERROR: $snmp_session->error\n");
		}

		
		my $resultEqlRaid 	= $snmp_session->get_entries(-columns => [keys %eqlRaidPolicy_oid]);
		if (!defined $resultEqlRaid ) {
			log_msg("ERROR: $snmp_session->error\n");
		}
		
		my $resultEqlGrp 	= $snmp_session->get_entries(-columns => [keys %eqlGrp_oid]);
		if (!defined $resultEqlGrp ) {
			log_msg("ERROR: $snmp_session->error\n");
		}
		
		my $resultEqlPool 	= $snmp_session->get_entries(-columns => [keys %eqlPool_oid]);
		if (!defined $resultEqlPool ) {
			log_msg("ERROR: $snmp_session->error\n");
		}
		
		my $resultEqlPoolIndex 	= $snmp_session->get_entries(-columns => [keys %eqlPoolIndex_oid]);
		if (!defined $resultEqlPoolIndex ) {
			log_msg("ERROR: $snmp_session->error\n");
		}

		if ( !defined $resultEqlMem and !defined $resultEqlRaid and !defined $resultEqlGrp and !defined $resultEqlPool and !defined $resultEqlPoolIndex)
		{
			printf "ERROR: SNMP Session error while retrieving information from the device.";
			log_msg("ERROR: $snmp_session->error\n");
			if (defined ($snmp_session))
			{ 
				$snmp_session->close();
			}
			exit $UNKNOWN;
		}
		else
		{
			my $tempoid = undef;

			log_msg("INFO: Success in getting value from Dell EQL storage array device.\n");
			
			my $eql_mem_name 			= "Not Available";
			my $eql_prod_family 		= "Not Available";
			my $eql_mem_svctag 			= "Not Available";
			my $eql_model 				= "Not Available";
			my $eql_chassis_type 		= "Not Available";
			my $eql_grp_name 			= "Not Available";
			my $eql_grp_ip 				= "Not Available";
			my $eql_mem_storage_pool 	= "Not Available";
			my $eql_disk_count 			= "Not Available";
			my $eql_raid_status 		= "Not Available";
			my $eql_raid_policy 		= "Not Available";
			my $eql_mem_capacity 		= "Not Available";
			my $eql_mem_free_space 		= "Not Available";
			my $eql_mem_fw_version 		= "Not Available";
			my $eql_mem_storage_pool_index = '1';
			
			my $totalStorage;
			my $usedStorage;
			
			my $controllerMajorVersion = -1;
			my $controllerMinorVersion = -1;
			my $controllerMaintenanceVersion = -1;
			
			foreach my $resultoid ( keys %{$resultEqlMem}) 
			{
				$tempoid = $resultoid;
				$tempoid =~ s/^\s+|\s+$//g;
				
				if (("$tempoid" eq "1.3.6.1.4.1.12740.2.1.1.1.9.1.$eqlMemberIdx") && (length($resultEqlMem->{$resultoid}) != 0 ))
				{
					$eql_mem_name = $resultEqlMem->{$resultoid};
				}
				elsif ( ("$tempoid" eq "1.3.6.1.4.1.12740.2.1.11.1.9.1.$eqlMemberIdx") && (length($resultEqlMem->{$resultoid}) != 0 ) )
				{
					$eql_prod_family = $resultEqlMem->{$resultoid};
				}
				elsif ( ("$tempoid" eq "1.3.6.1.4.1.12740.2.1.11.1.8.1.$eqlMemberIdx") && (length($resultEqlMem->{$resultoid}) != 0 ) )
				{
					$eql_mem_svctag = $resultEqlMem->{$resultoid};
				}
				elsif ( ("$tempoid" eq "1.3.6.1.4.1.12740.2.1.11.1.1.1.$eqlMemberIdx") && (length($resultEqlMem->{$resultoid}) != 0 ) )
				{
					$eql_model = $resultEqlMem->{$resultoid};
				}
				elsif ( ("$tempoid" eq "1.3.6.1.4.1.12740.2.1.11.1.7.1.$eqlMemberIdx") && (length($resultEqlMem->{$resultoid}) != 0 ) )
				{
					$eql_chassis_type = $eqlChassisType{$resultEqlMem->{$resultoid}};
				}
				elsif ( ("$tempoid" eq "1.3.6.1.4.1.12740.2.1.11.1.4.1.$eqlMemberIdx") && (length($resultEqlMem->{$resultoid}) != 0 ) )
				{
					$eql_disk_count = $resultEqlMem->{$resultoid};
				}
				elsif ( ("$tempoid" eq "1.3.6.1.4.1.12740.2.1.13.1.1.1.$eqlMemberIdx") && (length($resultEqlMem->{$resultoid}) != 0 ) )
				{
					$eql_raid_status = $eqlMemberRaidStatus{$resultEqlMem->{$resultoid}};
				}
				elsif ( ("$tempoid" eq "1.3.6.1.4.1.12740.2.1.10.1.1.1.$eqlMemberIdx") && (length($resultEqlMem->{$resultoid}) != 0 ) )
				{
					$totalStorage = $resultEqlMem->{$resultoid};	
				}
				elsif ( ("$tempoid" eq "1.3.6.1.4.1.12740.2.1.10.1.2.1.$eqlMemberIdx") && (length($resultEqlMem->{$resultoid}) != 0 ) )
				{
					$usedStorage = $resultEqlMem->{$resultoid};	
				}
				elsif ( ("$tempoid" eq "1.3.6.1.4.1.12740.2.1.1.1.21.1.$eqlMemberIdx") && (length($resultEqlMem->{$resultoid}) != 0 ) )
				{
					$controllerMajorVersion = $resultEqlMem->{$resultoid};	
				}
				elsif ( ("$tempoid" eq "1.3.6.1.4.1.12740.2.1.1.1.22.1.$eqlMemberIdx") && (length($resultEqlMem->{$resultoid}) != 0 ) )
				{
					$controllerMinorVersion = $resultEqlMem->{$resultoid};
				}
				elsif ( ("$tempoid" eq "1.3.6.1.4.1.12740.2.1.1.1.23.1.$eqlMemberIdx") && (length($resultEqlMem->{$resultoid}) != 0 ) )
				{
					$controllerMaintenanceVersion = $resultEqlMem->{$resultoid};
				}
			}
			
			if( ($controllerMajorVersion != -1) and ($controllerMinorVersion != -1) and ($controllerMaintenanceVersion != -1) )
			{
				$eql_mem_fw_version =  $controllerMajorVersion.".".$controllerMinorVersion.".".$controllerMaintenanceVersion;
			}

			
			$eql_mem_capacity = sprintf "%.2f", $totalStorage/1024;
			
			my $freeSpace;
			$freeSpace = ($totalStorage - $usedStorage)/1024;
			$eql_mem_free_space = sprintf "%.2f", $freeSpace;
			
			foreach my $resultoid ( keys %{$resultEqlGrp}) 
			{
				$tempoid = $resultoid;
				$tempoid =~ s/^\s+|\s+$//g;
				if (("$tempoid" eq "1.3.6.1.4.1.12740.1.1.1.1.19.1") && (length($resultEqlGrp->{$resultoid}) != 0 ))
				{
					$eql_grp_name = $resultEqlGrp->{$resultoid};
				}
				elsif (("$tempoid" eq "1.3.6.1.4.1.12740.1.1.1.1.20.1") && (length($resultEqlGrp->{$resultoid}) != 0 ))
				{
					$eql_grp_ip = $resultEqlGrp->{$resultoid};
					if ($eql_grp_ip eq $invalid_ipv4)
					{ #if group ip comes "0.0.0.0" for given IP address then only execute below code
						my @oids = ($eqlInetAddrEntIfName);
			#get the eqlInetAddrEntIfName OID value which comes without colonk
			my $ipv6addNoColon = ($snmp_session->get_entries(-columns => \@oids,))->{$eqlInetAddrEntIfName.'.1'};

			if (index(uc($ipv6addNoColon), '0X') == 0)
			{                                     #remove '0x' from eqlInetAddrEntIfName OID value, so make value to upper case and compare
				$ipv6addNoColon = substr($ipv6addNoColon,2); #first two characters are '0x' so removing
			}
			$ipv6addNoColon =~ s/(.{1,4})/$1:/gs; #inserting ':' after 4th character in value
			chop($ipv6addNoColon);                #removing last ':' from value
			$eql_grp_ip = $ipv6addNoColon;
					}
				}
			}
			
			foreach my $resultEqlPoolIndexoid ( keys %{$resultEqlPoolIndex}) 
			{
				$tempoid = $resultEqlPoolIndexoid;
				$tempoid =~ s/^\s+|\s+$//g;
				if (("$tempoid" eq "1.3.6.1.4.1.12740.2.1.15.1.2.1.$eqlMemberIdx.1") && (length($resultEqlPoolIndex->{$resultEqlPoolIndexoid}) != 0 ))
				{
					$eql_mem_storage_pool_index = $resultEqlPoolIndex->{$resultEqlPoolIndexoid};
				}
			}
			
			foreach my $resultoid ( keys %{$resultEqlPool}) 
			{
				$tempoid = $resultoid;
				$tempoid =~ s/^\s+|\s+$//g;
				if (("$tempoid" eq "1.3.6.1.4.1.12740.16.1.1.1.3.1.$eql_mem_storage_pool_index") && (length($resultEqlPool->{$resultoid}) != 0 ))
				{
					$eql_mem_storage_pool = $resultEqlPool->{$resultoid};
				}
			}
			
			foreach my $resultoid ( keys %{$resultEqlRaid}) 
			{
				$tempoid = $resultoid;
				$tempoid =~ s/^\s+|\s+$//g;
				if ( ("$tempoid" eq "1.3.6.1.4.1.12740.2.1.15.1.3.1.$eqlMemberIdx.1") && (length($resultEqlRaid->{$resultoid}) != 0 ) )
				{
					$eql_raid_policy = $eqlDriveGroupRaidPolicy{$resultEqlRaid->{$resultoid}};
				}		
			}
			
			$finalString = "Member Name = $eql_mem_name" . "$nextline"."Product Family = $eql_prod_family" . "$nextline"."Model Name = $eql_model" . "$nextline"."Service Tag = $eql_mem_svctag" . "$nextline"."Firmware Version = $eql_mem_fw_version" . "$nextline"."Chassis Type = $eql_chassis_type" . "$nextline"."Disk Count = $eql_disk_count" . "$nextline"."Capacity(GB) = $eql_mem_capacity" . "$nextline"."Free Space(GB) = $eql_mem_free_space" . "$nextline"."RAID Policy = $eql_raid_policy" . "$nextline"."RAID Status = $eql_raid_status" . "$nextline"."Group Name = $eql_grp_name" . "$nextline"."Group IP = $eql_grp_ip" . "$nextline"."Storage Pool = $eql_mem_storage_pool";
						
		}
		
		if (defined ($snmp_session))
		{ 
			$snmp_session->close();
		}
		print "$finalString";
		exit $OK;
	}
	elsif ($eqlMemberIdx eq "NA")
	{
		my  $result = $snmp_session->get_entries(-columns => [keys %eqlGrp_oid]) or $snmpStatus = "false";

		if (!defined $result) {
			printf "ERROR: SNMP Session error while retrieving information from the device.";
			log_msg("ERROR: $snmp_session->error\n");
			if (defined ($snmp_session))
			{ 
				$snmp_session->close();
			}
			exit $UNKNOWN;
		} 
		else 
		{
			my $tempoid = undef;
			log_msg("INFO: Success in getting value from Dell EQL storage array.\n");
			
			my $eql_grp_name 	= "Not Available";
			my $eql_grp_url 	= "Not Available";
			my $eql_mem_count 	= "Not Available";
			my $eql_vol_count 	= "Not Available";
			
			foreach my $resultoid ( keys %{$result}) 
			{
				$tempoid = $resultoid;
				$tempoid =~ s/^\s+|\s+$//g;
				if (("$tempoid" eq "1.3.6.1.4.1.12740.1.1.1.1.19.1") && (length($result->{$resultoid}) != 0 ))
				{
					$eql_grp_name = $result->{$resultoid};
				}
				elsif (("$tempoid" eq "1.3.6.1.4.1.12740.1.1.1.1.20.1") && (length($result->{$resultoid}) != 0 ))
				{
					$eql_grp_url = $result->{$resultoid};
				}
				elsif (("$tempoid" eq "1.3.6.1.4.1.12740.1.1.2.1.13.1") && (length($result->{$resultoid}) != 0 ))
				{
					$eql_mem_count = $result->{$resultoid};
				}
				elsif (("$tempoid" eq "1.3.6.1.4.1.12740.1.1.2.1.12.1") && (length($result->{$resultoid}) != 0 ))
				{
					$eql_vol_count = $result->{$resultoid};
				}
			}
			if ($eql_grp_url eq "0.0.0.0")
			{
				if (ip_is_ipv6($opt{hostname}))
				{
					$eql_grp_url = "http://[$opt{hostname}]";
				}
				else
				{
					$eql_grp_url = "http://$opt{hostname}";
				}
			}
			else
			{
				$eql_grp_url = "http://" . $eql_grp_url;
			}
			
			$finalString = "Group Name = $eql_grp_name" . "$nextline"."Group URL = $eql_grp_url" . "$nextline"."Member Count = $eql_mem_count" . "$nextline"."Volume Count = $eql_vol_count";	
		}	
		if (defined ($snmp_session))
		{ 
			$snmp_session->close();
		}
		print "$finalString";
		exit $OK;		
	}
}

###############################################################

# Help text
$HELP = <<'END_HELP';
Usage: dell_check_equallogic.pl -H <HOSTNAME> [OPTION]...

OPTIONS:
    -i, --item          Component name.
OPTIONAL:
    -h, --help          Display this help text
    -F, --file          Host configuration file with absolute path 
    -s, --servicename   Service name.
END_HELP

# Options with default values
%opt = (
    'hostname'     => undef,
    'filepath'     => undef,
    'help'         => 0,
    'component'    => undef,
    'opt_log'      => 0,
    'service'      => undef,
	'memindex'	   => undef,
    
);

# Get options
GetOptions( 
    'H|hostname=s'      => \$opt{hostname},
    'F|file=s'          => \$opt{filepath},
    'h|help'            => \$opt{help},
    'i|item=s'          => \$opt{component},
    'l|log=i'           => \$opt{opt_log},
    's|servicename=s'   => \$opt{servicename},
	'x|memberindex=s'   => \$opt{memindex},
) or do { 
    print $HELP; 
    exit $UNKNOWN; 
};


# If user requested help
if ($opt{'help'}) {
    print $HELP;
    exit $OK;
}

if ($opt{'memindex'}) {
	$eqlMemberIdx = $opt{'memindex'};
}

# Error if hostname option is not present
if ((!defined $opt{hostname}) and (!defined $opt{component}) )  {
    print $HELP;
    exit $UNKNOWN;
}

# Default line break
$nextline = '<br>';

my $tm = localtime(time);
my $tm_month = sprintf "%02d",$tm->mon + 1;
my $tm_day = sprintf "%02d",$tm->mday;
my $tm_year = $tm->year + 1900;

my ($volume, $directory, $file) = File::Spec->splitpath(__FILE__);

our $opt_logfile = undef;
our $nagioshomedir = undef;
my $config_cfg_path = $directory . "dellconfig.cfg";
if(-e $config_cfg_path) {
    my $log_path = undef;
    my $row = undef;
    if(open(my $fh,"<" , $config_cfg_path)) {
        while ($row  =  <$fh> ){
            chomp $row;
            if(index($row, "NAGIOS_HOME") != -1){
            $row =~ s/\s//g;
            $nagioshomedir = substr($row,12);
            last;
            }
        }
        $log_path = $nagioshomedir . "/var/dell/";
        if(!( -d $log_path )) {
            system ("mkdir -p $log_path");
        }
        $opt_logfile = $log_path . "EqualLogicServices_" . $tm_year . $tm_month  . $tm_day . ".dbg";
    } 
}
 
#---------------------------------------------------------------------
# Functions
#---------------------------------------------------------------------

##################################################################
# Func: snmp_initialize 
# Input: No input
# outout: No Output
# Description :  This function intializes the snmp session object
#                which will be used for making snmp querries. 
##################################################################
sub snmp_initialize {
    my $temp_community;
    my %param
      = (
     '-hostname'    => $opt{hostname},
     '-version'     => 2,
     '-community'   => 'public',
     '-port'        => 161,
     '-timeout'     => 3,
     '-retries'     => 1,
     '-domain'        => 'UDP/IPv4',
    );

    my $filename = undef;
    my @snmp_params;
	my @eql_params;
    # Parameters to Net::SNMP->session()


    if (defined $opt{'filepath'}) {
        $filename = $opt{'filepath'};
    }elsif(defined $opt{servicename}){
        my $file_check  = $nagioshomedir . "/dell/config/objects/" . $opt{hostname} . ".cfg";
        if( -e $file_check) {
            $filename = $file_check;
        } else {
				if (eval { require  Socket; 1}) { 
						require  Socket;
                    } 
				else{ 
                         log_msg("ERROR: Required perl module Socket not found."); 
                         print "ERROR: Required perl module Socket not found\n"; 
                         exit $UNKNOWN;
                    }
            my $fqdnName = gethostbyaddr(inet_aton("$opt{hostname}"), AF_INET);
            $file_check = $nagioshomedir . "/dell/config/objects/" . $fqdnName . ".cfg";
            if ( -e $file_check) {
                $filename = $file_check;
            }
        }
    }
 
    if (defined $filename){   
        if(open(my $fh, "<", $filename) ) {
            log_msg("INFO ", "Success in opening the file $filename\n");
            while (my $row = <$fh>) {
                chomp $row;
					if (index($row, "_dell_comm_params") != -1){
                    $row =~ s/\s//g;
                    $row = substr($row,17);
                    @snmp_params = split(',',$row);
					last;
                }                 
            }
            if ($snmp_params[0] eq 'SNMP') {
                $temp_community = $snmp_params[1];
                $param{'-version'}   = $snmp_params[2];
                $param{'-timeout'}   = $snmp_params[3];
                $param{'-retries'}   = $snmp_params[4];
                $param{'-port'}      = $snmp_params[5];
                $param{'-domain'}    = $snmp_params[6];
			} else {
                print "CRITICAL: Internal Error - Invalid snmp params\n";
                log_msg("CRITICAL", "Internal Error - Invalid snmp params\n");
                exit $UNKNOWN;
            }
			
			if(defined $opt{servicename}){
				while (my $row = <$fh>) {
					chomp $row;
						if (index($row, "_INDEX") != -1){
						$row =~ s/\s//g;
						$row = substr($row,6);
						$eqlMemberIdx = $row;
						last;
					}                 
				}
			}			

			if ($param{'-domain'} eq "UDP/IPv6"){
				if (eval { require  Socket6; 1}) { 
						require  Socket6;
                     } 
				else { 
                         log_msg("ERROR: Required perl module Socket6 not found."); 
                         print "ERROR: Required perl module Socket6 not found\n"; 
                         exit $UNKNOWN;
                     }
            }
            else{
				if (eval { require  Socket; 1}) { 
						require  Socket;
                    } 
				else{ 
                         log_msg("ERROR: Required perl module Socket not found."); 
                         print "ERROR: Required perl module Socket not found\n"; 
                         exit $UNKNOWN;
                    }
            }

            my $resource_file = $nagioshomedir . "/dell/resources/dell_resource.cfg";
            my $name;
            my $value;

            if ( -e $resource_file){
                if(open(my $rfh, "<", $resource_file)){
                    while (my $resource_row = <$rfh> ) {
                        chomp $resource_row;
                        $resource_row =~ s/^\s+|\s+$//g;
                        if ( ($resource_row !~ /^#/) && ($resource_row ne "") ){    # Ignore lines starting with # and blank lines
                            ($name, $value) = split (/=/, $resource_row);          # Split each line into name value pairs
                            $value =~ s/^\s+|\s+$//g;     # Remove spaces at the start of the line
                            $name =~ s/^\s+|\s+$//g;
                            
                            if ($name eq $temp_community){
								if ($value ne ""){
									$param{'-community'} = $value;
									last;
								} else {
									print "CRITICAL: Macro $name is not configured in the resource file: $filename\n";
									log_msg("CRITICAL", "Macro $name is not configured in the resource file: $filename\n");
									exit $UNKNOWN;
								}
							}	
                        } 
                    }
			    } else {
					print "CRITICAL: Error in opening resource file: $resource_file\n";
					log_msg("CRITICAL", "Error in opening resource file: $resource_file.\n");
					exit $UNKNOWN;
				}
            } else {
				print "CRITICAL: Missing resource file: $resource_file\n";
				log_msg("CRITICAL", "$resource_file not found.\n");
				exit $UNKNOWN;
			}
			
        } else {
            log_msg("WARNING", "Error in opening the file $filename; Proceeding with default value.\n");
        }
    } else {
        print "CRITICAL: Filepath is invalid : $filename\n";
        log_msg("CRITICAL", "Filepath is invalid : $filename\n");
        exit $UNKNOWN;
    }
     
    my $calculated_timeout = ($param{'-timeout'} * ($param{'-retries'} + 1) + 120);
    $plugin_timeout = $plugin_timeout > $calculated_timeout ? $plugin_timeout: $calculated_timeout ;

    # Parameters for SNMP v2c or v1
    if ($param{'-version'} != 2 and $param{'-version'} != 1) {
        print "SNMP: This Plugin doesn't support SNMP version other than 1 and 2.";
        log_msg ("CRITICAL","SNMP: This Plugin doesn't support SNMP version other than 1 and 2\n");
        exit $UNKNOWN;
    }    

    # Try to initialize the SNMP session
    if (eval {require Net::SNMP; 1}) {
        ($snmp_session, $snmp_error) = Net::SNMP->session( %param );
        if (!defined ($snmp_session)){ 
            print "Error while creating SNMP Session.";
            log_msg("CRITICAL ","Error while creating SNMP Session.");
            exit $UNKNOWN;
        } else {
            log_msg ("INFO","Success in creating the session.\n");
        }
    } else {
        print "ERROR: Package: Required perl module Net::SNMP not found";
        log_msg("CRITICAL","Package: Required perl module Net::SNMP not found");
        exit $UNKNOWN;
    }
    return;
}

############################################################
# MAIN Function
############################################################

# Initialize SNMP

log_msg("INFO", "Log initializing\n");
snmp_initialize();

# Setting timeout
$SIG{ALRM} = sub {
    print "PLUGIN TIMEOUT: dell_check_equallogic.pl timed out after $plugin_timeout seconds$nextline";
	if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
    exit $UNKNOWN;
};

alarm $plugin_timeout;

# Check Arguments
if (defined $opt{'component'}){
	my $comp = lc($opt{'component'});
    if (( "$comp" eq 'meminfo' ) or ("$comp" eq 'grpinfo' )) 
	{
         get_eql_Info();
    } 
	elsif (lc($opt{'component'}) eq 'memghs' )
	{
         get_eql_component_health('memghs','NA','NA',0);
	}
    elsif (lc($opt{'component'}) eq 'grpvol' )
	{
         get_eql_component_health('grpvol','Status','NA',0);
	}
    elsif (lc($opt{'component'}) eq 'grpstor' )
	{
         get_eql_component_health('grpstor','NA','NA',0);
	}
    elsif (lc($opt{'component'}) eq 'mempd' )
	{
         get_eql_component_health('mempd','Status','Slot',0);
	}
	else 
	{
        print "Invalid component name $opt{'component'}$nextline";
        log_msg ("CRITICAL", "Invalid component name $opt{'component'}\n");
		exit $UNKNOWN;
    }
}

#-----------------------------------------------------------------
# Simple log-writing method
#-----------------------------------------------------------------

sub log_msg
{

    my ($severity,$message) = @_;

    my $tm = localtime(time);
    # time in following format : 2013-01-16 18:57:37 
    my $current_time = sprintf '%d-%02d-%02d %02d:%02d:%02d ', $tm->year + 1900, $tm->mon+1, $tm->mday, $tm->hour , $tm->min , $tm->sec;    
    
    eval
    {
        $message = $current_time . q{ } . $severity . q{ } . q{Dell_} . $opt{'component'} . q{ } . $opt{'hostname'} . q{ } .  $message ;    

        if ($opt{opt_log})
        {
            open(FILE,">>$opt_logfile") ;
            print FILE "$message" or warn "Error writing $message to $opt_logfile: $!";
            close FILE;
        }
    };
    
    return 1;
}
if (defined ($snmp_session))
	{ 
        $snmp_session->close();
    }
exit;
 
