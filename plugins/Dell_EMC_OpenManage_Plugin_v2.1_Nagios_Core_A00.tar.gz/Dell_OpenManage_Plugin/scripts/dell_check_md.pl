#! /usr/bin/perl

##########################################################################
#Title:         Dell Device Plugin Script
#Version:       2.0 
#Creation Date: 1st June 2015
#Description:   This script provides Dell MD Array overall health 
#               and component health. 
#
#Copyright (c) 2015 Dell Inc.
#All Rights Reserved.
##########################################################################

use Getopt::Long qw(:config no_ignore_case);
use Time::localtime;
use File::Spec;

# Global (package) variables used throughout the code
use vars qw($OK $WARNING $CRITICAL $UNKNOWN $HELP 
            $snmp_session $snmp_error $nextline 
            %opt %Nagios_ExitStatus_String_mapping 
    );

our $plugin_timeout = 15;
our $printmsg = "";
our $final_exit_code = undef;

#Exit Codes
$OK       = 0;
$WARNING  = 1;
$CRITICAL = 2;
$UNKNOWN  = 3;

# Error Code for Nagios Number to String 
%Nagios_ExitStatus_String_mapping = (
    $OK         => 'OK',
    $WARNING    => 'WARNING',
    $CRITICAL   => 'CRITICAL',
    $UNKNOWN    => 'UNKNOWN',
);

our %mdghs_mapping = (
		0	=> 'OK',
		1  	=> 'WARNING',
	);	
	
# Error Code for Nagios Number to String 
%Nagios_String_ExitStatus_mapping = (
    'OK' 	   => $OK,
    'WARNING'  => $WARNING,
    'CRITICAL' => $CRITICAL,
    'UNKNOWN'  => $UNKNOWN,
);

our %md_ghs_oid = (
		'1.3.6.1.4.1.674.10893.2.31.500.1.7' => 'Overall Storage Array',
    );
	

############################################################
# MD Array Info
############################################################

#MD Array inventory base OID
my $mdInfoBaseOid = '1.3.6.1.4.1.674.10893.2.31.500.1';

sub get_Md_Info {

    snmp_initialize();
	
    my $displayString  = undef;
	
	my @mdOID = ($mdInfoBaseOid);		
	my $result = $snmp_session->get_entries(-columns => \@mdOID,);
		
	if ( !defined $result )
	{
		printf "ERROR: SNMP Session error while retrieving information from the device.";
		log_msg("ERROR: $snmp_session->error\n");
		if (defined ($snmp_session))
		{ 
			$snmp_session->close();
		}
		exit $UNKNOWN;
	}
	else
	{
		my $tempoid = undef;
		my $dummySvcTag;

		log_msg("INFO: Success in getting value from Dell MD storage array device.\n");
		
		my $md_name 			= "Not Available";
		my $md_wwid 			= "Not Available";
		my $md_svctag 			= "Not Available";
		my $md_productid		= "Not Available";
				
		foreach my $resultoid ( keys %{$result}) 
		{
			$tempoid = $resultoid;
			$tempoid =~ s/^\s+|\s+$//g;
			
			if (("$tempoid" eq "1.3.6.1.4.1.674.10893.2.31.500.1.1.0") && (length($result->{$resultoid}) != 0 ))
			{
				$md_name = $result->{$resultoid};
				log_msg("INFO ", "MD Storage Array name: $md_name\n");
			}
			elsif (("$tempoid" eq "1.3.6.1.4.1.674.10893.2.31.500.1.2.0") && (length($result->{$resultoid}) != 0 ))
			{
				$md_wwid = $result->{$resultoid};
				log_msg("INFO ", "MD Storage Array WWID: $md_wwid\n");
			}
			elsif (("$tempoid" eq "1.3.6.1.4.1.674.10893.2.31.500.1.3.0") && (length($result->{$resultoid}) != 0 ))
			{
				$dummySvcTag = $result->{$resultoid};;
				my @splitSvcTag = split / /, $dummySvcTag;
				$md_svctag = $splitSvcTag[1];
				log_msg("INFO ", "MD Storage Array service tag: $md_svctag\n");
			}
			elsif (("$tempoid" eq "1.3.6.1.4.1.674.10893.2.31.500.1.5.0") && (length($result->{$resultoid}) != 0 ))
			{
				$md_productid = $result->{$resultoid};
				log_msg("INFO ", "MD Storage Array product id: $md_productid\n");
			}
		}
			
		$displayString = "Storage Name = $md_name"."$nextline"."Product ID = $md_productid"."$nextline"."Service Tag = $md_svctag"."$nextline"."World-wide ID = $md_wwid";		
	}
	
	if (defined ($snmp_session))
	{ 
		$snmp_session->close();
	}
	print "$displayString";
	exit $OK;
}

###############################################################

############################################################
# Func:         get_Md_OverallHealth
# Description:  Main function which is getting callled for
#				getting PowerVault MD overall health
############################################################

sub get_Md_OverallHealth {
	
	my $tmpStatus = undef;
	my $result = $snmp_session->get_entries(-columns => [keys %md_ghs_oid]);
	
	if ((!defined $result)) {
        print "ERROR: SNMP : ", $snmp_session->error;
        log_msg("CRITICAL", $snmp_session->error);
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
        exit $UNKNOWN;
    } else {
        log_msg("INFO", "Success in getting value from Dell agent.\n");
    }
	
	foreach my $mdghskey ( keys %{$result}) {
		$tmpStatus = $mdghs_mapping{$result->{$mdghskey}};
		if ((!defined $tmpStatus)) {
			$tmpStatus = 'UNKNOWN';
		}
		$printmsg = $printmsg . "$md_ghs_oid{substr($mdghskey, 0, -2)} = $tmpStatus";
		$final_exit_code = $Nagios_String_ExitStatus_mapping{$tmpStatus};
	}
	
    if(defined $opt{servicename})
    {
        my $command = $nagioshomedir . "/libexec/eventhandlers/submit_check_result " . $opt{hostname} . q{ } . "\"".$opt{servicename}."\"" . q{ } . $final_exit_code . q{ } . "\"" . $printmsg . "\"";
        log_msg("INFO: Command: $command\n");
        system($command);
    }
    else
    {
        print $printmsg;
        if (defined ($snmp_session))
        { 
            $snmp_session->close();
        }
    }
    
    exit $final_exit_code;
		
	}
	
# Help text
$HELP = <<'END_HELP';
Usage: dell_check_md.pl -H <HOSTNAME> [OPTION]...

OPTIONS:
    -i, --item          Component name.
OPTIONAL:
    -h, --help          Display this help text
    -F, --file          Host configuration file with absolute path 
    -s, --servicename   Service name.
END_HELP

# Options with default values
%opt = (
    'hostname'     => undef,
    'filepath'     => undef,
    'help'         => 0,
    'component'    => undef,
    'opt_log'      => 0,
    'service'      => undef,   
);

# Get options
GetOptions( 
    'H|hostname=s'      => \$opt{hostname},
    'F|file=s'          => \$opt{filepath},
    'h|help'            => \$opt{help},
    'i|item=s'          => \$opt{component},
    'l|log=i'           => \$opt{opt_log},
    's|servicename=s'   => \$opt{servicename},
) or do { 
    print $HELP; 
    exit $UNKNOWN; 
};


# If user requested help
if ($opt{'help'}) {
    print $HELP;
    exit $OK;
}

# Error if hostname option is not present
if ((!defined $opt{hostname}) and (!defined $opt{component}) )  {
    print $HELP;
    exit $UNKNOWN;
}

# Default line break
$nextline = '<br>';

my $tm = localtime(time);
my $tm_month = sprintf "%02d",$tm->mon + 1;
my $tm_day = sprintf "%02d",$tm->mday;
my $tm_year = $tm->year + 1900;

my ($volume, $directory, $file) = File::Spec->splitpath(__FILE__);

our $opt_logfile = undef;
our $nagioshomedir = undef;
my $config_cfg_path = $directory . "dellconfig.cfg";
if(-e $config_cfg_path) {
    my $log_path = undef;
    my $row = undef;
    if(open(my $fh,"<" , $config_cfg_path)) {
        while ($row  =  <$fh> ){
            chomp $row;
            if(index($row, "NAGIOS_HOME") != -1){
            $row =~ s/\s//g;
            $nagioshomedir = substr($row,12);
            last;
            }
        }
        $log_path = $nagioshomedir . "/var/dell/";
        if(!( -d $log_path )) {
            system ("mkdir -p $log_path");
        }
        $opt_logfile = $log_path . "MDServices_" . $tm_year . $tm_month  . $tm_day . ".dbg";
    } 
}
 
#---------------------------------------------------------------------
# Functions
#---------------------------------------------------------------------

##################################################################
# Func: snmp_initialize 
# Input: No input
# outout: No Output
# Description :  This function intializes the snmp session object
#                which will be used for making snmp querries. 
##################################################################
sub snmp_initialize {
    my $temp_community;
    my %param
      = (
     '-hostname'    => $opt{hostname},
     '-version'     => 2,
     '-community'   => 'public',
     '-port'        => 161,
     '-timeout'     => 3,
     '-retries'     => 1,
     '-domain'        => 'UDP/IPv4',
    );

    my $filename = undef;
    my @snmp_params;
	my @eql_params;
    # Parameters to Net::SNMP->session()


    if (defined $opt{'filepath'}) {
        $filename = $opt{'filepath'};
    }elsif(defined $opt{servicename}){
        my $file_check  = $nagioshomedir . "/dell/config/objects/" . $opt{hostname} . ".cfg";
        if( -e $file_check) {
            $filename = $file_check;
        } else {
				if (eval { require  Socket; 1}) { 
						require  Socket;
                    } 
				else{ 
                         log_msg("ERROR: Required perl module Socket not found."); 
                         print "ERROR: Required perl module Socket not found\n"; 
                         exit $UNKNOWN;
                    }
            my $fqdnName = gethostbyaddr(inet_aton("$opt{hostname}"), AF_INET);
            $file_check = $nagioshomedir . "/dell/config/objects/" . $fqdnName . ".cfg";
            if ( -e $file_check) {
                $filename = $file_check;
            }
        }
    }
 
    if (defined $filename){   
        if(open(my $fh, "<", $filename) ) {
            log_msg("INFO ", "Success in opening the file $filename\n");
            while (my $row = <$fh>) {
                chomp $row;
					if (index($row, "_dell_comm_params") != -1){
                    $row =~ s/\s//g;
                    $row = substr($row,17);
                    @snmp_params = split(',',$row);
					last;
                }                 
            }
            if ($snmp_params[0] eq 'SNMP') {
                $temp_community = $snmp_params[1];
                $param{'-version'}   = $snmp_params[2];
                $param{'-timeout'}   = $snmp_params[3];
                $param{'-retries'}   = $snmp_params[4];
                $param{'-port'}      = $snmp_params[5];
                $param{'-domain'}    = $snmp_params[6];
			} else {
                print "CRITICAL: Internal Error - Invalid snmp params\n";
                log_msg("CRITICAL", "Internal Error - Invalid snmp params\n");
                exit $UNKNOWN;
            }
			
			if ($param{'-domain'} eq "UDP/IPv6"){
				if (eval { require  Socket6; 1}) { 
						require  Socket6;
                     } 
				else { 
                         log_msg("ERROR: Required perl module Socket6 not found."); 
                         print "ERROR: Required perl module Socket6 not found\n"; 
                         exit $UNKNOWN;
                     }
            }
            else{
				if (eval { require  Socket; 1}) { 
						require  Socket;
                    } 
				else{ 
                         log_msg("ERROR: Required perl module Socket not found."); 
                         print "ERROR: Required perl module Socket not found\n"; 
                         exit $UNKNOWN;
                    }
            }

            my $resource_file = $nagioshomedir . "/dell/resources/dell_resource.cfg";
            my $name;
            my $value;

            if ( -e $resource_file){
                if(open(my $rfh, "<", $resource_file)){
                    while (my $resource_row = <$rfh> ) {
                        chomp $resource_row;
                        $resource_row =~ s/^\s+|\s+$//g;
                        if ( ($resource_row !~ /^#/) && ($resource_row ne "") ){    # Ignore lines starting with # and blank lines
                            ($name, $value) = split (/=/, $resource_row);          # Split each line into name value pairs
                            $value =~ s/^\s+|\s+$//g;     # Remove spaces at the start of the line
                            $name =~ s/^\s+|\s+$//g;
                            
                            if ($name eq $temp_community){
								if ($value ne ""){
									$param{'-community'} = $value;
									last;
								} else {
									print "CRITICAL: Macro $name is not configured in the resource file: $filename\n";
									log_msg("CRITICAL", "Macro $name is not configured in the resource file: $filename\n");
									exit $UNKNOWN;
								}
							}	
                        } 
                    }
			    } else {
					print "CRITICAL: Error in opening resource file: $resource_file\n";
					log_msg("CRITICAL", "Error in opening resource file: $resource_file.\n");
					exit $UNKNOWN;
				}
            } else {
				print "CRITICAL: Missing resource file: $resource_file\n";
				log_msg("CRITICAL", "$resource_file not found.\n");
				exit $UNKNOWN;
			}
			
        } else {
            log_msg("WARNING", "Error in opening the file $filename; Proceeding with default value.\n");
        }
    } else {
        print "CRITICAL: Filepath is invalid : $filename\n";
        log_msg("CRITICAL", "Filepath is invalid : $filename\n");
        exit $UNKNOWN;
    }
     
    my $calculated_timeout = ($param{'-timeout'} * ($param{'-retries'} + 1) + 120);
    $plugin_timeout = $plugin_timeout > $calculated_timeout ? $plugin_timeout: $calculated_timeout ;

    # Parameters for SNMP v2c or v1
    if ($param{'-version'} != 2 and $param{'-version'} != 1) {
        print "SNMP: This Plugin doesn't support SNMP version other than 1 and 2.";
        log_msg ("CRITICAL","SNMP: This Plugin doesn't support SNMP version other than 1 and 2\n");
        exit $UNKNOWN;
    }    

    # Try to initialize the SNMP session
    if (eval {require Net::SNMP; 1}) {
        ($snmp_session, $snmp_error) = Net::SNMP->session( %param );
        if (!defined ($snmp_session)){ 
            print "Error while creating SNMP Session.";
            log_msg("CRITICAL ","Error while creating SNMP Session.");
            exit $UNKNOWN;
        } else {
            log_msg ("INFO","Success in creating the session.\n");
        }
    } else {
        print "ERROR: Package: Required perl module Net::SNMP not found";
        log_msg("CRITICAL","Package: Required perl module Net::SNMP not found");
        exit $UNKNOWN;
    }
    return;
}

############################################################
# MAIN Function
############################################################

# Initialize SNMP

log_msg("INFO", "Log initializing\n");
snmp_initialize();

# Setting timeout
$SIG{ALRM} = sub {
    print "PLUGIN TIMEOUT: dell_check_md.pl timed out after $plugin_timeout seconds$nextline";
	if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
    exit $UNKNOWN;
};

alarm $plugin_timeout;

# Check Arguments
if (defined $opt{'component'}){
    if (( lc($opt{'component'}) eq 'mdinfo' )) {
         get_Md_Info();
    } elsif (( lc($opt{'component'}) eq 'mdghs' )) {
         get_Md_OverallHealth();
    } 
	else {
        print "Invalid component name $opt{'component'}$nextline";
        log_msg ("CRITICAL", "Invalid component name $opt{'component'}\n");
		exit $UNKNOWN;
    }
}

#-----------------------------------------------------------------
# Simple log-writing method
#-----------------------------------------------------------------

sub log_msg
{

    my ($severity,$message) = @_;

    my $tm = localtime(time);
    # time in following format : 2013-01-16 18:57:37 
    my $current_time = sprintf '%d-%02d-%02d %02d:%02d:%02d ', $tm->year + 1900, $tm->mon+1, $tm->mday, $tm->hour , $tm->min , $tm->sec;    
    
    eval
    {
        $message = $current_time . q{ } . $severity . q{ } . q{Dell_} . $opt{'component'} . q{ } . $opt{'hostname'} . q{ } .  $message ;    

        if ($opt{opt_log})
        {
            open(FILE,">>$opt_logfile") ;
            print FILE "$message" or warn "Error writing $message to $opt_logfile: $!";
            close FILE;
        }
    };
    
    return 1;
}
if (defined ($snmp_session))
	{ 
        $snmp_session->close();
    }
exit;
 
