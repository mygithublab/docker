#! /usr/bin/perl

##########################################################################
#Title:         Dell Device Plugin Script
#Version:       1.0
#Creation Date: 17th November 2014
#Description:   This script provides Dell Server health and component
#               health via Agent-free mode using SNMP and Wsman protocol.
#
#Copyright (c) 2014 Dell Inc.
#All Rights Reserved.
##########################################################################



use warnings;
use Socket;
use Net::IP;
use Net::IP qw(:PROC);
use Getopt::Long qw(:config no_ignore_case);
use File::Spec;


our %opt = (
    'hostname'     => undef,
    'component'    => undef,
    'service'      => undef,
);



# Get options
GetOptions(
    'H|hostname=s'      => \$opt{hostname},
    'i|item=s'          => \$opt{component},
    's|servicename=s'   => \$opt{servicename},
);



my ($volume, $directory, $file) = File::Spec->splitpath(__FILE__);
my @wsman_params;
my $command;
my $cmdvalue;
my $deviceIPAddress = $opt{hostname};
my $isIPv6Address = 0;
if (ip_is_ipv6($deviceIPAddress))
{
	$deviceIPAddress = new Net::IP ($deviceIPAddress);
	$deviceIPAddress = $deviceIPAddress->ip();
	$isIPv6Address = 1;
}
my $filename = $directory."../config/objects/$deviceIPAddress".".cfg" ; 
my $file_check = $filename;
 if( -e $file_check) {
        $filename = $file_check;
        $cmdvalue = $deviceIPAddress;
		} else {
			my $fqdnName = "";
			if ($isIPv6Address == 1)
			{
				require Socket6;
				my @addrs = Socket6::getaddrinfo($deviceIPAddress, 0 );
			    my $family = -1;
			    while (scalar(@addrs) >= 5) 
			    {
			      ($family, $socktype, $proto, $saddr, $canonname, @addrs) = @addrs;
			      ($host, $port) = Socket6::getnameinfo($saddr);
			    }
				$fqdnName = $host;
			}
			else
			{ 
            	$fqdnName = gethostbyaddr(inet_aton("$opt{hostname}"), AF_INET);
			}
			$file_check = $directory."../config/objects/" . $fqdnName . ".cfg";
        	if ( -e $file_check) 
			{
            	$filename = $file_check;
				$cmdvalue = $fqdnName;
       		}
}

if (defined $filename){
        if(open(my $fh, "<", $filename) ) {
            while (my $row = <$fh>) {
                chomp $row;
                if(index($row, "_dell_comm_params") != -1){
                    $row =~ s/\s//g;
                    $row = substr($row,17);
                    @wsman_params = split(',',$row);
                    last;
                }
            }
            if($wsman_params[0] eq 'WSMAN'){
            $command = $directory."dell_check_idrac_wsman.pl -H  $cmdvalue"." -F $filename -i  $opt{'component'} -s". " \"".  $opt{'servicename'}. "\"";          
            
         }elsif ($wsman_params[0] eq 'SNMP'){
            $command = $directory."dell_check_idrac_snmp.pl -H  $cmdvalue"." -F $filename -i  $opt{'component'} -s". " \"".  $opt{'servicename'}. "\"";          
            }
		system($command);
    }
}
