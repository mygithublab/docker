#!/usr/bin/perl

#####################################################################################
#Title:dell_device_discovery.pl 
#Version:2.0 
#Description: dell_device_discovery.pl is a plugin that discovers and generates 
#             host, service definitions for Dell Agent-free Servers, Chassis and 
#             Storage devices.
#Copyright (c) 2014-2015 Dell Inc.
#All Rights Reserved.
#####################################################################################
use Net::IP;
use Net::IP qw(:PROC);
use File::Spec;
use Getopt::Long qw(:config no_ignore_case);
use Time::localtime;
use IO::Handle;
use Socket;

##wsman default values
use constant WSMANPATH      => '/wsman';
use constant WSMANSCHEME    => 'https';
use constant SNMP           => 1;
use constant WSMAN          => 2;

## configuration files
use constant DELLCONFIGPATH         => 'dellconfig.cfg';
use constant DELLCOMMCONFIGFILE     => '.dell_device_comm_params.cfg';
use constant DELLSERVICECONFIGFILE  => 'dell_device_services_template.cfg';
use constant DELLRESOURCEFILE       => 'dell_resource.cfg';
use constant DELLPLUGINCONFIG       => 'dell_pluginconfig.cfg';

### Exit codes
use constant SUCCESS            => 0;
use constant FAILURE            => 1;
use constant LOGMODULE          => 'DellDiscovery';

my $max_elements = 10;
my $communicationProtocol = "snmp";
my %opt;
my %snmpParams
    =(
    'snmp.version'     => '',
    'snmp.community'   => '',
    'snmp.port'        => '',
    'snmp.timeout'     => '',
    'snmp.retries'     => '',
    'process.count'    => '',
    );

my %wsmanParams
    =(    
    'wsman.username' => '',      
    'wsman.password' => '',
    'wsman.port'     =>  '',    
    'wsman.timeout'  =>  '',
    'wsman.scheme'   =>  WSMANSCHEME,
    'wsman.path'     =>  WSMANPATH,
    'wsman.retries'  => '',
    'process.count'  => '',    
    );
    
my ($volume, $directory, $file) = File::Spec->splitpath(__FILE__);
my $dellConfigFile              = "$directory".DELLCONFIGPATH;
my $dellCommConfigFile          = "$directory".DELLCOMMCONFIGFILE;
my $dellServiceConfigFile       = "$directory".DELLSERVICECONFIGFILE;
my $resourceFile                = DELLRESOURCEFILE;
my $pluginconfigFile            = DELLPLUGINCONFIG;
my $dell_pluginconfigFile       = "$directory../resources/".$pluginconfigFile;
my $dellResourceFile            = "$directory../resources/".$resourceFile;
my $NAGIOS_HOME                 = readConfigFile ("$dellConfigFile", "NAGIOS_HOME" );
if ($NAGIOS_HOME eq "")
{
    print "NAGIOS_HOME is not set. Exiting discovery.";
    exit FAILURE;
}

my $CONFIG_DIR          = "$NAGIOS_HOME/dell/config";
my $HOST_CONFIG_DIR     = "$CONFIG_DIR/objects";
my $DELL_NAGIOS_LOG_DIR = "$NAGIOS_HOME/var/dell";
if(! -d $DELL_NAGIOS_LOG_DIR)
{
    system("mkdir -p $DELL_NAGIOS_LOG_DIR");
}
if(!-d $HOST_CONFIG_DIR)
{
    system("mkdir -p $HOST_CONFIG_DIR");
}

our $opt_log     = 1;
my $tm           = localtime(time);
my $tm_month     = sprintf "%02d",$tm->mon + 1;
my $tm_day       = sprintf "%02d",$tm->mday;
my $tm_year      = $tm->year + 1900;
my $tm_hour      = sprintf "%02d",$tm->hour;
my $tm_minute    = sprintf "%02d",$tm->min;
my $tm_second    = sprintf "%02d",$tm->sec;
our $opt_logfile = "$DELL_NAGIOS_LOG_DIR/discovery_" . $tm_year . $tm_month  . $tm_day . $tm_hour .$tm_minute . $tm_second .".dbg";

my @IpList;
my $fileWriteEnable = "n";
my $deviceAddress   = "";
my $serviceOption   = "basic";
my $servicesCreated = "false";
my $wsmanUser       = undef;
my $wsmanPasswd     = undef;
my $snmpCommunity   = undef;

## Redirect all stderr messages to logfile
open ERROR,  '>>',  $opt_logfile  or print "Cannot open $opt_logfile file for stderr logging\n";     
STDERR->fdopen( \*ERROR,  'w' ) or print "Cannot open $opt_logfile file for stderr logging\n";

#----------------------------------------------------------------------
# Function prints help and usage of script dell_oob_server_discovery.pl
#----------------------------------------------------------------------
# Help text
$HELP = <<'END_HELP';

Usage: perl dell_device_discovery.pl -H <Host IP address>  | -F <IP address list file> | -S <Subnet with mask> [-P <Protocol>] [-c <Protocol specific config file>] [-t <Service template>] [-f] [-d] 

OPTIONS:
        -h, --help              Display help text.
        -H, --host              Host IP address or FQDN name.
        -S, --subnet            Subnet with mask.
        -F, --filewithiplist    File with absolute path containing list of newline separated IP address or FQDN name.
        -P, --protocol          Protocol used for monitoring. Allowed options 1(SNMP) and 2(WSMAN).
        -c, --configfile        Protocol specific configuration file.
        -t, --template          Template file with absolute path for customized service monitoring.
        -f, --force             Force rewrite of config file.
        -d, --detailedservice   All Services monitor option based on services defined in service template file.
END_HELP


my $noOfChild = 1;
our $default_no_process = 20;

## process the command line args and validate configuration params
processArgs();

#MIB oids to be queried
my $sysObjectIdOid        = '1.3.6.1.2.1.1.2.0';
my $deviceType            = "";
my $sysObjectID           = "";
my $sysName               = undef;
my $racURL                = undef;
my $racType               = undef;
my $hostName              = undef;
my $serviceTag            = undef;
my $hostObjectName        = "";
my $hostGroupName         = "";

#MIB oids for OOB
my $racUrlOid                   = '1.3.6.1.4.1.674.10892.5.1.1.6.0';
my $oobServerSysObjectIdValue   = '1.3.6.1.4.1.674.10892.5';
my $oobServiceTag               = '1.3.6.1.4.1.674.10892.5.1.3.2';
my $oobdevice                   = "iDRAC";

#MIB oids for the EqualLogic device
my $eqlSysObjId           = '1.3.6.1.4.1.12740.17.1';
my $eqlGroupIpOID         = '1.3.6.1.4.1.12740.1.1.1.1.20';
my $eqlGroupNameOID       = '1.3.6.1.4.1.12740.1.1.1.1.19';
my $eqlInetAddrEntIfName  = '1.3.6.1.4.1.12740.9.5.1.3';
my $eqlServiceTagOID      = '1.3.6.1.4.1.12740.2.1.11.1.8';
my $eqlGroupInet6Addr     = '1.3.6.1.4.1.12740.1.1.1.1.54';
my $eqlfile               = "equallogic_ips.txt";
my $eqldevice             = "EqualLogic";
my $eqlGroupDevice        = "equallogicgroup";
my $eqlMemberDevice       = "equallogicmember";    
my $eqlgroupIP            = "";
my $eqlgroupName          = "";
my $eqlMemberIndex        = "";
my $storagehostObject     = "Dell EMC Storage";
my $storagehostGroup      = "Dell EMC Storage";


#MIB oids for chassis
my $chassisSysObjIDValue      = '1.3.6.1.4.1.674.10892.2';
my $chassisProductTypeOID     = '1.3.6.1.4.1.674.10892.2.1.1.14.0';
my $chassisServiceTag         = '1.3.6.1.4.1.674.10892.2.1.1.6.0';
my $chassisdevice             = "CMC";
my $cmcM1000edevice           = "M1000e";
my $cmcVRTXdevice             = "VRTX";
my $cmcFX2device              = "FX2";
my $cmcFX2sdevice             = "FX2s";
my $chassishostObject         = "Dell EMC Chassis";
my $chassishostGroup          = "Dell EMC Chassis";
my $chassisURL                = "";

#MIB oids for Compellent
my $compellentSysObjIDValue = '1.3.6.1.4.1.8072.3.2.8';
my $compellentMgmtIPOID     = '1.3.6.1.4.1.674.11000.2000.500.1.2.29.1.8';
my $compellentCtlIPOID      = '1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.5';
my $compellentSvcTagOID     = '1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.8';
my $compellentMgmtIPIPv6OID = '1.3.6.1.4.1.674.11000.2000.500.1.2.29.1.11';
my $compellentCtlIPIPv6OID  = '1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.10';
my $compellentMgmtIp        = "";
my $compellentCtlIndex      = "";
my $compllentdevice         = "Compellent";
my $compellentMgmtdevice    = "CompellentMgmt";
my $compellentCtldevice     = "CompellentCtl";

#MIB oids for MD tribes
my $sysNameOid              = "1.3.6.1.2.1.1.5";
my $mdServiceTagOID         = '1.3.6.1.4.1.674.10893.2.31.500.1.3';
my $mdSysObjIDValue         = '1.3.6.1.4.1.674.10893.2.31';
my $mddevice                = "MDTribes";

my $deviceIPfromName        = "";
my $deviceIPfromHostName    = "";
my $key;
my $value;
my %temphash = ();

my $flag_SNMP_fails = "false";
my $error_response  = "error";

my %serviceArgs
        =(
        'Dell EMC Server Information'               => 'info',
        'Dell EMC Server Overall Health Status'     => 'ghs',
        'Dell EMC Server CPU Status'                => 'cpu',
        'Dell EMC Server Memory Status'             => 'mem',
        'Dell EMC Server Fan Status'                => 'fan',
        'Dell EMC Server Battery Status'            => 'bat',
        'Dell EMC Server Power Supply Status'       => 'ps',
        'Dell EMC Server Temperature Probe Status'  => 'temp',
        'Dell EMC Server Voltage Probe Status'      => 'vlt',
        'Dell EMC Server Intrusion Status'          => 'int',
        'Dell EMC Server Network Device Status'     => 'nic',
        'Dell EMC Server Physical Disk Status'      => 'pd',
        'Dell EMC Server Virtual Disk Status'       => 'vd',
        'Dell EMC Server Controller Status'         => 'ctl',
        'Dell EMC Server Amperage Probe Status'     => 'amp',
        'Dell EMC Server SD Card Status'            => 'sd',
        'Dell EMC Server FC NIC Status'             => 'fcnic',
		'Dell EMC Server Warranty Information' 		=> 'warranty',
        'Dell EMC Chassis Information'              => 'info',
        'Dell EMC Chassis Overall Health Status'    => 'ghs',
        'Dell EMC Chassis Power Supply Status'      => 'ps',
        'Dell EMC Chassis Fan Status'               => 'fan',
        'Dell EMC Chassis I/O Module Status'        => 'io',
        'Dell EMC Chassis Slot Information'         => 'slot',
        'Dell EMC Chassis KVM Status'               => 'kvm',
        'Dell EMC Chassis Enclosure Status'         => 'enc',
        'Dell EMC Chassis Controller Status'        => 'ctl',
        'Dell EMC Chassis Physical Disk Status'     => 'pd',
        'Dell EMC Chassis Virtual Disk Status'      => 'vd',
        'Dell EMC Chassis PCIe Devices Status'      => 'pci',
		'Dell EMC Chassis Warranty Information'  	=> 'warranty',
        'Dell EMC Storage PS-Series Member Information'           => 'meminfo',
        'Dell EMC Storage PS-Series Member Overall Health Status' => 'memghs',
        'Dell EMC Storage PS-Series Member Physical Disk Status'  => 'mempd',
        'Dell EMC Storage PS-Series Group Volume Status'          => 'grpvol',
        'Dell EMC Storage PS-Series Group Information'            => 'grpinfo',
        'Dell EMC Storage PS-Series Group Storage Pool Information'    => 'grpstor', 
		'Dell EMC Storage PS-Series Member Warranty Information'  => 'warranty',
        'Dell EMC Storage SC-Series Information'                  => 'mnginfo',
        'Dell EMC Storage SC-Series Overall Health Status'        => 'mngghs',
        'Dell EMC Storage SC-Series Physical Disk Status'         => 'mngpd',
        'Dell EMC Storage SC-Series Volume Status'                => 'mngvol',
        'Dell EMC Storage SC-Series Controller Information'       => 'ctlinfo',
        'Dell EMC Storage SC-Series Controller Overall Health Status'  => 'ctlghs',
		'Dell EMC Storage SC-Series Controller Warranty Information'  => 'warranty',
        'Dell EMC Storage MD-Series Information'               => 'mdinfo',
        'Dell EMC Storage MD-Series Overall Health Status'     => 'mdghs',
		'Dell EMC Storage MD-Series Warranty Information'  	   => 'warranty',
        );

#########################################################################
#Device Service declaration
#########################################################################

my %idracsnmpdefinedservice;
my %idracwsmandefinedservice;
my %chassisdefinedservice;
my %vrtxdefinedservice;
my %vrtxfx2definedservice;
my %eqlgrpdefinedservice;
my %eqlmemdefinedservice;
my %compelmgmtdefinedservice;
my %compelctrldefinedservice;
my %mddefinedservice;

# Basic service details

my %delliDracSnmpBasic;
my %delliDracWsmanBasic;
my %dellChassisWsmanBasic;
my %dellEqlMemberSnmpBasic;
my %dellEqlGroupSnmpBasic;
my %dellCompelMgmtSnmpBasic;
my %dellCompelCtrlSnmpBasic;
my %dellMdSnmpBasic;

my %delldevicebasic;
$delldevicebasic{'idrac.snmp'}                   = \%delliDracSnmpBasic;
$delldevicebasic{'idrac.wsman'}                  = \%delliDracWsmanBasic;
$delldevicebasic{'chassis.wsman'}                = \%dellChassisWsmanBasic;
$delldevicebasic{'equallogicmember.snmp'}        = \%dellEqlMemberSnmpBasic;
$delldevicebasic{'equallogicgroup.snmp'}         = \%dellEqlGroupSnmpBasic;
$delldevicebasic{'compellentmanagement.snmp'}    = \%dellCompelMgmtSnmpBasic;
$delldevicebasic{'compellentcontroller.snmp'}    = \%dellCompelCtrlSnmpBasic;
$delldevicebasic{'md.snmp'}                      = \%dellMdSnmpBasic;

# Detailed service details
my %delliDracSnmpDet;
my %delliDracWsmanDet;
my %dellChassisWsmanDet;
my %dellVrtxWsmanDet;
my %dellEqlMemberSnmpDet;
my %dellEqlGroupSnmpDet;
my %dellCompelMgmtSnmpDet;
my %dellCompelCtrlSnmpDet;
my %dellMdSnmpDet;
my %dellVrtxFX2WsmanDet;

my %delldevicedet;
$delldevicedet{'idrac.snmp'}                   = \%delliDracSnmpDet;
$delldevicedet{'idrac.wsman'}                  = \%delliDracWsmanDet;
$delldevicedet{'chassis.wsman'}                = \%dellChassisWsmanDet;
$delldevicedet{'vrtx.wsman'}                   = \%dellVrtxWsmanDet;
$delldevicedet{'vrtxfx2.wsman'}                = \%dellVrtxFX2WsmanDet;
$delldevicedet{'equallogicmember.snmp'}        = \%dellEqlMemberSnmpDet;
$delldevicedet{'equallogicgroup.snmp'}         = \%dellEqlGroupSnmpDet;
$delldevicedet{'compellentmanagement.snmp'}    = \%dellCompelMgmtSnmpDet;
$delldevicedet{'compellentcontroller.snmp'}    = \%dellCompelCtrlSnmpDet;
$delldevicedet{'md.snmp'}                        = \%dellMdSnmpDet;

initializeiDRACServices();
initializeChassisServices();
initializeStorageService();

sub initializeiDRACServices
{
   #iDRAC basic SNMP
   $delliDracSnmpBasic{"dellemcserverinformation"}         = "Dell EMC Server Information";
   $delliDracSnmpBasic{"dellemcservertraps"}               = "Dell EMC Server Traps";
   $delliDracSnmpBasic{"dellemcserveroverallhealthstatus"} = "Dell EMC Server Overall Health Status";
   
   #iDRAC basic WSMAN
   $delliDracWsmanBasic{"dellemcserverinformation"}         = "Dell EMC Server Information";
   $delliDracWsmanBasic{"dellemcservertraps"}               = "Dell EMC Server Traps";
   $delliDracWsmanBasic{"dellemcserveroverallhealthstatus"} = "Dell EMC Server Overall Health Status";
   
   #iDRAC detailed SNMP
   $delliDracSnmpDet{"dellemcserverinformation"}               = "Dell EMC Server Information";
   $delliDracSnmpDet{"dellemcservertraps"}                     = "Dell EMC Server Traps";
   $delliDracSnmpDet{"dellemcserveroverallhealthstatus"}       = "Dell EMC Server Overall Health Status";
   $delliDracSnmpDet{"dellemcserverphysicaldiskstatus"}        = "Dell EMC Server Physical Disk Status";
   $delliDracSnmpDet{"dellemcserverbatterystatus"}             = "Dell EMC Server Battery Status";
   $delliDracSnmpDet{"dellemcserverfanstatus"}                 = "Dell EMC Server Fan Status";
   $delliDracSnmpDet{"dellemcserverintrusionstatus"}           = "Dell EMC Server Intrusion Status";
   $delliDracSnmpDet{"dellemcservervirtualdiskstatus"}         = "Dell EMC Server Virtual Disk Status";
   $delliDracSnmpDet{"dellemcservernetworkdevicestatus"}       = "Dell EMC Server Network Device Status";
   $delliDracSnmpDet{"dellemcservercpustatus"}                 = "Dell EMC Server CPU Status";
   $delliDracSnmpDet{"dellemcserverpowersupplystatus"}         = "Dell EMC Server Power Supply Status";
   $delliDracSnmpDet{"dellemcservermemorystatus"}              = "Dell EMC Server Memory Status";
   $delliDracSnmpDet{"dellemcservertemperatureprobestatus"}    = "Dell EMC Server Temperature Probe Status";
   $delliDracSnmpDet{"dellemcservervoltageprobestatus"}        = "Dell EMC Server Voltage Probe Status";
   $delliDracSnmpDet{"dellemcserveramperageprobestatus"}       = "Dell EMC Server Amperage Probe Status";
   $delliDracSnmpDet{"dellemcservercontrollerstatus"}          = "Dell EMC Server Controller Status";
   $delliDracSnmpDet{"dellemcserverwarrantyinformation"}       = "Dell EMC Server Warranty Information";
   
   
   #iDRAC detailed WSMAN
   $delliDracWsmanDet{"dellemcserverinformation"}         = "Dell EMC Server Information";
   $delliDracWsmanDet{"dellemcservertraps"}               = "Dell EMC Server Traps";
   $delliDracWsmanDet{"dellemcserveroverallhealthstatus"} = "Dell EMC Server Overall Health Status";
   $delliDracWsmanDet{"dellemcserverphysicaldiskstatus"}  = "Dell EMC Server Physical Disk Status";
   $delliDracWsmanDet{"dellemcserverbatterystatus"}       = "Dell EMC Server Battery Status";
   $delliDracWsmanDet{"dellemcserverfanstatus"}           = "Dell EMC Server Fan Status";
   $delliDracWsmanDet{"dellemcserverintrusionstatus"}     = "Dell EMC Server Intrusion Status";
   $delliDracWsmanDet{"dellemcservervirtualdiskstatus"}   = "Dell EMC Server Virtual Disk Status";
   $delliDracWsmanDet{"dellemcservernetworkdevicestatus"} = "Dell EMC Server Network Device Status";
   $delliDracWsmanDet{"dellemcserversdcardstatus"}        = "Dell EMC Server SD Card Status";
   $delliDracWsmanDet{"dellemcservervoltageprobestatus"}  = "Dell EMC Server Voltage Probe Status";
   $delliDracWsmanDet{"dellemcserveramperageprobestatus"} = "Dell EMC Server Amperage Probe Status";
   $delliDracWsmanDet{"dellemcservercontrollerstatus"}    = "Dell EMC Server Controller Status";
   $delliDracWsmanDet{"dellemcserverfcnicstatus"}         = "Dell EMC Server FC NIC Status";
   $delliDracWsmanDet{"dellemcservertemperatureprobestatus"}    = "Dell EMC Server Temperature Probe Status";
   $delliDracWsmanDet{"dellemcserverpowersupplystatus"}         = "Dell EMC Server Power Supply Status";
   $delliDracWsmanDet{"dellemcservermemorystatus"}         = "Dell EMC Server Memory Status";
   $delliDracWsmanDet{"dellemcservercpustatus"}                 = "Dell EMC Server CPU Status";
   $delliDracWsmanDet{"dellemcserverwarrantyinformation"}       = "Dell EMC Server Warranty Information";
}

sub initializeChassisServices
{
   #chassis basic wsman
   $dellChassisWsmanBasic{"dellemcchassisinformation"}         = "Dell EMC Chassis Information";
   $dellChassisWsmanBasic{"dellemcchassistraps"}               = "Dell EMC Chassis Traps";
   $dellChassisWsmanBasic{"dellemcchassisoverallhealthstatus"} = "Dell EMC Chassis Overall Health Status";
   #chassis detailed wsman
   $dellChassisWsmanDet{"dellemcchassisinformation"}         = "Dell EMC Chassis Information";
   $dellChassisWsmanDet{"dellemcchassistraps"}               = "Dell EMC Chassis Traps";
   $dellChassisWsmanDet{"dellemcchassisoverallhealthstatus"} = "Dell EMC Chassis Overall Health Status";
   $dellChassisWsmanDet{"dellemcchassispowersupplystatus"}   = "Dell EMC Chassis Power Supply Status";
   $dellChassisWsmanDet{"dellemcchassisfanstatus"}           = "Dell EMC Chassis Fan Status";
   $dellChassisWsmanDet{"dellemcchassisi/omodulestatus"}     = "Dell EMC Chassis I/O Module Status";
   $dellChassisWsmanDet{"dellemcchassisslotinformation"}     = "Dell EMC Chassis Slot Information";
   $dellChassisWsmanDet{"dellemcchassiskvmstatus"}           = "Dell EMC Chassis KVM Status";
   $dellChassisWsmanDet{"dellemcchassiswarrantyinformation"} = "Dell EMC Chassis Warranty Information";
   #vrtx chassis detailed wsman
   $dellVrtxWsmanDet{"dellemcchassisinformation"}         = "Dell EMC Chassis Information";
   $dellVrtxWsmanDet{"dellemcchassistraps"}               = "Dell EMC Chassis Traps";
   $dellVrtxWsmanDet{"dellemcchassisoverallhealthstatus"} = "Dell EMC Chassis Overall Health Status";
   $dellVrtxWsmanDet{"dellemcchassispowersupplystatus"}   = "Dell EMC Chassis Power Supply Status";
   $dellVrtxWsmanDet{"dellemcchassisfanstatus"}           = "Dell EMC Chassis Fan Status";
   $dellVrtxWsmanDet{"dellemcchassisi/omodulestatus"}     = "Dell EMC Chassis I/O Module Status";
   $dellVrtxWsmanDet{"dellemcchassisslotinformation"}     = "Dell EMC Chassis Slot Information";
   $dellVrtxWsmanDet{"dellemcchassiskvmstatus"}           = "Dell EMC Chassis KVM Status";
   $dellVrtxWsmanDet{"dellemcchassisenclosurestatus"}     = "Dell EMC Chassis Enclosure Status";
   $dellVrtxWsmanDet{"dellemcchassiscontrollerstatus"}    = "Dell EMC Chassis Controller Status";
   $dellVrtxWsmanDet{"dellemcchassisphysicaldiskstatus"}  = "Dell EMC Chassis Physical Disk Status";
   $dellVrtxWsmanDet{"dellemcchassisvirtualdiskstatus"}   = "Dell EMC Chassis Virtual Disk Status";
   $dellVrtxFX2WsmanDet{"dellemcchassispciedevicesstatus"} = "Dell EMC Chassis PCIe Devices Status";
   $dellVrtxWsmanDet{"dellemcchassiswarrantyinformation"} = "Dell EMC Chassis Warranty Information";
}
sub initializeStorageService
{
   initializeEqlServices();
   initializeCompellentServices();
   initializeMDServices();
}

sub initializeEqlServices
{
   #equallogic member basic services
   $dellEqlMemberSnmpBasic{"dellemcstorageps-seriesmemberinformation"}    = "Dell EMC Storage PS-Series Member Information";
   $dellEqlMemberSnmpBasic{"dellemcstorageps-seriesmemberoverallhealthstatus"}  = "Dell EMC Storage PS-Series Member Overall Health Status";
   $dellEqlMemberSnmpBasic{"dellemcstorageps-seriesmembertraps"}          = "Dell EMC Storage PS-Series Member Traps";
   #equallogic group basic services
   $dellEqlGroupSnmpBasic{"dellemcstorageps-seriesgroupinformation"}      = "Dell EMC Storage PS-Series Group Information";
   $dellEqlGroupSnmpBasic{"dellemcstorageps-seriesgrouptraps"}            = "Dell EMC Storage PS-Series Group Traps";
   
   #equallogic member detailed services
   $dellEqlMemberSnmpDet{"dellemcstorageps-seriesmemberinformation"}        = "Dell EMC Storage PS-Series Member Information";
   $dellEqlMemberSnmpDet{"dellemcstorageps-seriesmemberoverallhealthstatus"}      = "Dell EMC Storage PS-Series Member Overall Health Status";
   $dellEqlMemberSnmpDet{"dellemcstorageps-seriesmembertraps"}              = "Dell EMC Storage PS-Series Member Traps";
   $dellEqlMemberSnmpDet{"dellemcstorageps-seriesmemberphysicaldiskstatus"} = "Dell EMC Storage PS-Series Member Physical Disk Status";
   $dellEqlMemberSnmpDet{"dellemcstorageps-seriesmemberwarrantyinformation"} = "Dell EMC Storage PS-Series Member Warranty Information";

   #equallogic group detailed services
   $dellEqlGroupSnmpDet{"dellemcstorageps-seriesgroupinformation"}       = "Dell EMC Storage PS-Series Group Information";
   $dellEqlGroupSnmpDet{"dellemcstorageps-seriesgroupvolumestatus"}      = "Dell EMC Storage PS-Series Group Volume Status";
   $dellEqlGroupSnmpDet{"dellemcstorageps-seriesgroupstoragepoolinformation"} = "Dell EMC Storage PS-Series Group Storage Pool Information";
   $dellEqlGroupSnmpDet{"dellemcstorageps-seriesgrouptraps"}             = "Dell EMC Storage PS-Series Group Traps";
   
}

sub initializeCompellentServices
{
   #compellent mgmt basic services
   $dellCompelMgmtSnmpBasic{"dellemcstoragesc-seriesinformation"}     = "Dell EMC Storage SC-Series Information";
   $dellCompelMgmtSnmpBasic{"dellemcstoragesc-seriesoverallhealthstatus"}   = "Dell EMC Storage SC-Series Overall Health Status";
   $dellCompelMgmtSnmpBasic{"dellemcstoragesc-seriesmanagementtraps"} = "Dell EMC Storage SC-Series Management Traps";
   #compellent controller basic services
   $dellCompelCtrlSnmpBasic{"dellemcstoragesc-seriescontrollerinformation"}    = "Dell EMC Storage SC-Series Controller Information";
   $dellCompelCtrlSnmpBasic{"dellemcstoragesc-seriescontrolleroverallhealthstatus"}  = "Dell EMC Storage SC-Series Controller Overall Health Status";
   $dellCompelCtrlSnmpBasic{"dellemcstoragesc-seriescontrollertraps"}          = "Dell EMC Storage SC-Series Controller Traps";
   
   #compellent mgmt detailed services
   $dellCompelMgmtSnmpDet{"dellemcstoragesc-seriesinformation"}         = "Dell EMC Storage SC-Series Information";
   $dellCompelMgmtSnmpDet{"dellemcstoragesc-seriesoverallhealthstatus"}       = "Dell EMC Storage SC-Series Overall Health Status";
   $dellCompelMgmtSnmpDet{"dellemcstoragesc-seriesmanagementtraps"}     = "Dell EMC Storage SC-Series Management Traps";
   $dellCompelMgmtSnmpDet{"dellemcstoragesc-seriesphysicaldiskstatus"}  = "Dell EMC Storage SC-Series Physical Disk Status";
   $dellCompelMgmtSnmpDet{"dellemcstoragesc-seriesvolumestatus"}        = "Dell EMC Storage SC-Series Volume Status";
	
   #compellent controller detailed services
   $dellCompelCtrlSnmpDet{"dellemcstoragesc-seriescontrollerinformation"}    = "Dell EMC Storage SC-Series Controller Information";
   $dellCompelCtrlSnmpDet{"dellemcstoragesc-seriescontrolleroverallhealthstatus"}  = "Dell EMC Storage SC-Series Controller Overall Health Status";
   $dellCompelCtrlSnmpDet{"dellemcstoragesc-seriescontrollertraps"}          = "Dell EMC Storage SC-Series Controller Traps";
   $dellCompelCtrlSnmpDet{"dellemcstoragesc-seriescontrollerwarrantyinformation"}  = "Dell EMC Storage SC-Series Controller Warranty Information";
}

sub initializeMDServices
{
   #md basic services
   $dellMdSnmpBasic{"dellemcstoragemd-seriesinformation"}    = "Dell EMC Storage MD-Series Information"; 
   $dellMdSnmpBasic{"dellemcstoragemd-seriesoverallhealthstatus"}  = "Dell EMC Storage MD-Series Overall Health Status";
   $dellMdSnmpBasic{"dellemcstoragemd-seriestraps"}          = "Dell EMC Storage MD-Series Traps";
   #md detailed services
   $dellMdSnmpDet{"dellemcstoragemd-seriesinformation"}         = "Dell EMC Storage MD-Series Information"; 
   $dellMdSnmpDet{"dellemcstoragemd-seriesoverallhealthstatus"}       = "Dell EMC Storage MD-Series Overall Health Status";
   $dellMdSnmpDet{"dellemcstoragemd-seriestraps"}               = "Dell EMC Storage MD-Series Traps";
   $dellMdSnmpDet{"dellemcstoragemd-serieswarrantyinformation"} = "Dell EMC Storage MD-Series Warranty Information";
}

##Component status service Details
my $oobServerComponentHealthServiceName     = "Dell EMC Device Component Status";
my $oobServerComponentHealthServiceCommand  = "check_dell_oob_server_component_";
my $chassisComponentHealthServiceCommand    = "check_dell_chassis_component";
my $eqlComponentHealthServiceCommand        = "check_dell_equallogic_component";
my $compellentComponentHealthServiceCommand = "check_dell_compellent_component";
my $mdComponentHealthServiceCommand         = "check_dell_md_component";
my $warrantyInformationCommand        	    = "dell_check_warranty";

##Trap Service Decription
my $dellDeviceTrapServiceName = "Dell EMC Traps";
my $oobServerTrapServiceDescription = "Dell EMC Server Traps";

##Dell EMC Server Information
my $dellServerInfoTemplateEntry = "Dell EMC Server Information";
my $dellServerInfoServiceName = "Dell EMC Device Inventory Information";
##Dell EMC Server Overall Health Status 
my $dellServerGHSTemplateEntry = "Dell EMC Server Overall Health Status";
my $dellServerGHSServiceName = "Dell EMC Device Health Status";

my $hostObject   = "Dell EMC Agent-free Server";
my $hostGroup    = "Dell EMC Agent-free Servers";
my $image        =  "idrac.png";
my $chassisImage = "chassis.png";
my $storageImage = "equallogic.png";
my $comStgImage  = "compellent.png";
my $mdStgImage   = "MdArray.png";
my $host_file    = "";
my $snmpttInstalled = "true";
my $javaInstalled = "true";
log_msg("INFO: Starting Dell EMC device discovery... ");
print STDOUT ("Starting Dell EMC device discovery... \n");

###Get the configured service from template file
if($serviceOption eq "all")
{
    %services = readServiceConfigurationNew($dellServiceConfigFile,$communicationProtocol,"all", %delldevicedet);
}else
{
    %services = readServiceConfigurationNew($dellServiceConfigFile,$communicationProtocol,"basic", %delldevicebasic);
}

###Check service availability in template file. If not exit discovery.
my $hashSize = keys %services;

if($hashSize <= 0) 
{
    print "No services are configured/defined in $dellServiceConfigFile. Exiting discovery.\n";
    log_msg("WARNING: No services are configured/defined in $dellServiceConfigFile. Exiting discovery.");
    exit $FAILURE;    
}else
{
	###Check for TRAP service availability.
	$snmpttInstalled = readConfigFile ("$dellConfigFile", "SNMPTTINI" );
	if($snmpttInstalled eq "")
	{
		$snmpttInstalled = "false";
		log_msg("INFO: SNMPTT is not installed/configured. Following services will not be created.");
		log_msg("INFO: Dell EMC Chassis Traps");
		log_msg("INFO: Dell EMC Server Traps");
		log_msg("INFO: Dell EMC Storage SC-Series Controller Traps");
		log_msg("INFO: Dell EMC Storage SC-Series Management Traps");
		log_msg("INFO: Dell EMC Storage PS-Series Member Traps");
		log_msg("INFO: Dell EMC Storage PS-Series Group Traps");
		log_msg("INFO: Dell EMC Storage MD-Series Traps");
		
		print STDOUT "\nSNMPTT is not installed/configured. Following services will not be created.\n";
		print STDOUT "Dell EMC Chassis Traps\n";
		print STDOUT "Dell EMC Server Traps\n";
		print STDOUT "Dell EMC Storage SC-Series Controller Traps\n";
		print STDOUT "Dell EMC Storage SC-Series Management Traps\n";
		print STDOUT "Dell EMC Storage PS-Series Member Traps\n";
		print STDOUT "Dell EMC Storage PS-Series Group Traps\n";
		print STDOUT "Dell EMC Storage MD-Series Traps\n";
	}
	
	###Check for Warranty service availability.
	$javaInstalled = readConfigFile ("$dellConfigFile", "JAVAINSTALLPATH" );
	if($javaInstalled eq "")
	{
		$javaInstalled = "false";
		log_msg("INFO: Java 1.6 or above is not installed/configured. Following services will not be created.");
		log_msg("INFO: Dell EMC Server Warranty Information");
		log_msg("INFO: Dell EMC Chassis Warranty Information");
		log_msg("INFO: Dell EMC Storage PS-Series Member Warranty Information");
		log_msg("INFO: Dell EMC Storage SC-Series Controller Warranty Information");
		log_msg("INFO: Dell EMC Storage MD-Series Warranty Information");
		
		print STDOUT "\nJava 1.6 or above is not installed/configured. Following services will not be created.\n";
		print STDOUT "Dell EMC Server Warranty Information\n";
		print STDOUT "Dell EMC Chassis Warranty Information\n";
		print STDOUT "Dell EMC Storage PS-Series Member Warranty Information\n";
		print STDOUT "Dell EMC Storage SC-Series Controller Warranty Information\n";
		print STDOUT "Dell EMC Storage MD-Series Warranty Information\n";
	}
	
	checkModule();
	
    log_msg("INFO: The following services are configured for the Dell EMC device(s) to be discovered, as applicable.");
    print STDOUT "\nThe following services are configured for the Dell EMC device(s) to be discovered, as applicable.\n";

    foreach my $serviceName (sort values %services)
    {
       if (index($serviceName, 'Traps') > 0)
       {
          if ($snmpttInstalled ne "false")
          {
             log_msg("INFO: $serviceName");
             print STDOUT "$serviceName\n";
          }
       } elsif (index($serviceName, 'Warranty') > 0)
       {
          if ($javaInstalled ne "false")
          {
             log_msg("INFO: $serviceName");
             print STDOUT "$serviceName\n";
          }
       }
       else
       {
          log_msg("INFO: $serviceName");
          print STDOUT "$serviceName\n";
       }
    }
}

print "\n\tPress Y and then press Enter to continue.\n\tPress any other key and then press Enter or press Enter to exit.\n";
$| = 1;
$toContinue = <STDIN>;
chomp ($toContinue);
$toContinue = uc($toContinue);
if ( $toContinue ne "Y")
{
    print "\n\nExiting discovery.\n\n";
	log_msg("INFO: Exiting discovery.");
    exit FAILURE;
}

###Iterate hosts array and start discovery
print "\nDell EMC device discovery is in progress...\n";
our $url_flag = 0;

my $size = @IpList;
my @children;
my $numberOfPartition;
my @array_of_arrays ;
log_msg("INFO: Number of child process: $noOfChild");
$numberOfPartition = int($size / $noOfChild);

my $sizeFlag =0;

for (my $i=0; $i<=$numberOfPartition; $i++)
{    
    for (my $j = 0; $j < $noOfChild; $j++)
    {
        if ( $sizeFlag < $size)
        {
           $array_of_arrays[$j][$i] = $IpList[$sizeFlag];
           $sizeFlag++;
        }
        else
        {
            $array_of_arrays[$j][$i] = " ";
        }
    }
} 

my @temp;
my $HostsAttempted = 0;
my $HostsUnreachable = 0;
my $HostsErrorReponse = 0;
my $HostsUnresponsive = 0;
my $HostsAlreadyDiscovered = 0;
my $HostsDiscovered = 0;
my $HostOOB         = 0;
my $HostChassis     = 0;
my $HostStorage     = 0;

my $THostsAttempted = 0;
my $THostsUnreachable = 0;
my $THostsErrorReponse = 0;
my $THostsUnresponsive = 0;
my $THostsAlreadyDiscovered = 0;
my $THostsDiscovered = 0;
my $THostOOB         = 0;
my $THostChassis     = 0;
my $THostStorage     = 0;

main();
collectSummaryFromProcess();
sub main
{
    foreach my $i ( reverse(0..$noOfChild-1) )
    {
        my $pid = fork();
 
        if( $pid )
        {
            #If $pid is non zero, then it is parent running
            push(@children, $pid);
        }
        else
        {
            # Else it is a child process ($pid == 0)
            my $rc = child1(@{$array_of_arrays[$i]});
            exit($rc);
        }
    }
}


sub collectSummaryFromProcess
{
   foreach my $n (@children)
   {
      my $pid = waitpid($n,0); # waitpid returns the pid that finished, see perldoc -f waitpid
      open(my $fh, '<', $pid . ".txt");			 
      while (my $row = <$fh>) 
      {
        $row =~ s/^\s*//;     # Remove spaces at the start of the line
        $row =~ s/\s*$//;     # Remove spaces at the end of the line
        chomp;
        push @temp, $row;
      }
      close $fh;   
      
      unlink ("$pid.txt"); 
    
      my $rc = $? >> 8; # remove signal / dump bits from rc
   }
   #makerelation();
   printSummary();
}

sub makerelation
{
   log_msg("INFO: Before hash reading");
   log_msg("INFO: file name : $eqlfile");
   open(my $fh, '<', $eqlfile);

   while (my $row = <$fh>) 
   {
       $row =~ s/^\s*//;     # Remove spaces at the start of the line
       $row =~ s/\s*$//;     # Remove spaces at the end of the line
       chomp;
       if ( ($row !~ /^#/) && ($row ne "") && ($row ne "/^\s*$/") )
       {
           ($key, $value) = split (/\|/, $row);          # Split each line into name value pairs
           $value =~ s/^\s*//;                           # Remove spaces at the start of the line
           $value =~ s/\s*$//;
           $key =~ s/^\s*//;
           $key =~ s/\s*$//;
           $temphash{$key} = $value;
       }
   }

   my @hashkeys = keys %temphash ;
   foreach my $name (keys %temphash) 
   {
       if (index($name, 'member#') ==0)
       {
           my $memParent = $temphash{"group#" . $temphash{$name}};
           ($key, $value) = split (/#/, $name);
           $value =~ s/^\s*//;                         # Remove spaces at the start of the line
           $value =~ s/\s*$//;
           $key =~ s/^\s*//;
           $key =~ s/\s*$//;
           my $memFilePath = "$HOST_CONFIG_DIR/" . "$value" . ".cfg";
           if (-e $memFilePath)
           {
               open( FILE, "<".$memFilePath );
               @LINES = <FILE>;
               close(FILE);
               open( FILE, ">".$memFilePath ); 
               foreach my $LINE ( @LINES ) 
               { 
                   if (index($LINE, "parents") != -1) 
                   {
                       print FILE "            parents                 " . $memParent . "\n";
                   }
                   else
                   {
                       print FILE $LINE;
                   }
               }
        # close the file.
        close FILE;           
           }
       }
   }
}

sub printSummary
{
    for (my $i =0; $i <= $#temp; $i++)
    {
      
       ($HostsAttempted, $HostsUnreachable, $HostsErrorReponse, $HostsUnresponsive, $HostsAlreadyDiscovered, $HostsDiscovered,$HostOOB,$HostChassis,$HostStorage)  = split (/\|/, $temp[$i]);              # Split each line into name value pairs
       $HostsAttempted         =~ s/^\s*//;                               # Remove spaces at the start of the line
       $HostsAttempted         =~ s/\s*$//;
       $HostsUnreachable       =~ s/^\s*//;
       $HostsUnreachable       =~ s/\s*$//;
       $HostsErrorReponse      =~ s/^\s*//;                               # Remove spaces at the start of the line
       $HostsErrorReponse      =~ s/\s*$//;
       $HostsUnresponsive      =~ s/^\s*//;
       $HostsUnresponsive      =~ s/\s*$//;
       $HostsAlreadyDiscovered =~ s/^\s*//;                               # Remove spaces at the start of the line
       $HostsAlreadyDiscovered =~ s/\s*$//;
       $HostsDiscovered        =~ s/^\s*//;
       $HostsDiscovered        =~ s/\s*$//;
       $HostOOB                =~ s/^\s*//;                               # Remove spaces at the start of the line
       $HostOOB                =~ s/\s*$//;
       $HostChassis            =~ s/^\s*//;
       $HostChassis            =~ s/\s*$//;
       $HostStorage            =~ s/^\s*//;
       $HostStorage            =~ s/\s*$//;
       
       $THostsAttempted         = $THostsAttempted + $HostsAttempted;
       $THostsUnreachable       = $THostsUnreachable + $HostsUnreachable;
       $THostsErrorReponse      = $THostsErrorReponse + $HostsErrorReponse;
       $THostsUnresponsive      = $THostsUnresponsive + $HostsUnresponsive;
       $THostsAlreadyDiscovered = $THostsAlreadyDiscovered + $HostsAlreadyDiscovered;
       $THostsDiscovered        = $THostsDiscovered + $HostsDiscovered; 
       $THostOOB                = $THostOOB + $HostOOB;
       $THostChassis            = $THostChassis + $HostChassis;
       $THostStorage            = $THostStorage + $HostStorage;
    }
    log_msg("INFO: Total number of Dell EMC device(s) attempted               :$THostsAttempted");
    log_msg("INFO: Total number of Dell EMC device(s) unreachable             :$THostsUnreachable");
    log_msg("INFO: Total number of Dell EMC device(s) with error response     :$THostsErrorReponse");
    log_msg("INFO: Total number of Dell EMC device(s) with no response        :$THostsUnresponsive");
    log_msg("INFO: Total number of Dell EMC device(s) already discovered      :$THostsAlreadyDiscovered");
    log_msg("INFO: Total number of Dell EMC Agent-free Server(s) discovered   :$THostOOB");
    log_msg("INFO: Total number of Dell EMC Chassis discovered                :$THostChassis");
    log_msg("INFO: Total number of Dell EMC Storage Arrays discovered         :$THostStorage");
    log_msg("INFO: Total number of Dell EMC device(s) discovered successfully :$THostsDiscovered");    

    print ("\nTotal number of Dell EMC device(s) attempted               :$THostsAttempted\n");
    print ("Total number of Dell EMC device(s) unreachable             :$THostsUnreachable\n");
    print ("Total number of Dell EMC device(s) with error response     :$THostsErrorReponse\n");
    print ("Total number of Dell EMC device(s) with no response        :$THostsUnresponsive \n");
    print ("Total number of Dell EMC device(s) already discovered      :$THostsAlreadyDiscovered\n");
    print ("Total number of Dell EMC Agent-free Server(s) discovered   :$THostOOB\n");
    print ("Total number of Dell EMC Chassis discovered                :$THostChassis\n");
    print ("Total number of Dell EMC Storage Arrays discovered         :$THostStorage\n");
    print ("Total number of Dell EMC device(s) discovered successfully :$THostsDiscovered\n");
    log_msg ("INFO: Dell EMC device discovery completed.");
    print  STDOUT ("\nDell EMC device discovery completed.\n\n");
    if( $THostsDiscovered > 0 )
    {
        print STDOUT ("Please verify the Nagios configuration and restart the Nagios service.\n\n");
    }
}

sub child1
{
   my @arg = @_;
   my $size = @arg;
   ##Discovery counters
   my $totalHostsAttempted         = 0;
   my $totalHostsUnreachable       = 0;
   my $totalErrorReponseHosts      = 0;
   my $totalUnresponsiveHosts      = 0;
   my $totalhostsAlreadyDiscovered = 0;
   my $totalhostsDiscovered        = 0;
   my $totalOOBDiscovered          = 0;
   my $totalChassisDiscovered      = 0;
   my $totalStorageDiscovered      = 0;
   foreach (@arg) 
   {
       my $fqdnName = "";
       my $snmpStat = "true";
       my $ipAddressType = "ipv4";
       my $deviceInfoRet = "fail";
       $flag_SNMP_fails  = "false";
    
       $sysObjectID = "";
       $deviceType      = "";
       $sysName         = "";
       $eqlMemberIndex  = "";
       $serviceTag      = "";
       $chassisURL	 = "";
    
       $domain = "UDP/IPv4";
       $deviceAddress = $_;
       chomp  $deviceAddress;
       $deviceAddress =~ s/^\s+|\s+$//g; #remove the leading spaces
       my $ipAddress = $deviceAddress;
       if( $deviceAddress eq "")
       {
           next;
       }
       $totalHostsAttempted = $totalHostsAttempted + 1;
       log_msg("INFO: Starting discovery of $deviceAddress");
       $url_flag  = 0;
       if (ip_is_ipv4($deviceAddress))
       {
           system("ping $deviceAddress -c 2 > /dev/null 2>&1");
           log_msg("INFO: $deviceAddress is an ipv4 address");
           if ($? != 0){
           log_msg("ERROR: Host $deviceAddress is not reachable");
           $totalHostsUnreachable = $totalHostsUnreachable + 1;
           next;
       }

       if (eval { require Socket; 1}) { 
           $fqdnName = gethostbyaddr(Socket::inet_aton($deviceAddress), AF_INET)
                       or  log_msg("WARNING: Failed to resolve IP to FQDN name $deviceAddress");
       } else {
            log_msg("ERROR: Required perl module Socket not found.");
            print "\nERROR: Required perl module Socket not found\n";
            exit;
       }
   }   
   elsif(ip_is_ipv6($deviceAddress))
   {
       $deviceAddress = new Net::IP ($deviceAddress);
       $deviceAddress = $deviceAddress->ip();
       system("ping6 $deviceAddress -c 2 > /dev/null 2>&1");
       log_msg("INFO: $deviceAddress is an ipv6 address");
       if ($? != 0)
       {
           log_msg("ERROR: Host $deviceAddress is not reachable");
           $totalHostsUnreachable = $totalHostsUnreachable + 1;
           next;
       }
       if (eval { require Socket6; 1}) { 
           my $hostname = "";
           my @res = Socket6::getaddrinfo($deviceAddress, 443);
           my $family = -1;
           my $socktype;
           my $proto;
           my $saddr; 
           my $canonname;
           my $port;
           
           while (scalar(@res) >= 5) {
               ($family, $socktype, $proto, $saddr, $canonname, @res) = @res;
               ($hostname, $port) = Socket6::getnameinfo($saddr);
           }
           if($hostname eq "")
           {
               log_msg("WARNING: Failed to resolve IP $deviceAddress to FQDN name ");
           }
           else
           {        
               if ( ip_is_ipv6($hostname))
               {
                   $url_flag = 1;
                   $fqdnName = $deviceAddress;
               }
               else
               {
                   $fqdnName = $hostname;
               }
           }
           $ipAddressType = "ipv6";
           $domain = "UDP/IPv6";
       } else {
            log_msg("ERROR: Required perl module Socket6 not found.");
            print "\nERROR: Required perl module Socket6 not found\n";
            exit;
       }
   }else{
        system("ping $deviceAddress -c 2 > /dev/null 2>&1");
        log_msg("INFO: $deviceAddress is an hostname");
        if ($? != 0)
        {
            system("ping6 $deviceAddress -c 2 > /dev/null 2>&1");
            if ($? != 0)
            {
                log_msg("ERROR: Host $deviceAddress is not reachable");
                $totalHostsUnreachable = $totalHostsUnreachable + 1;
                next;    
            }
            else
            {
                if (eval { require  Socket6; 1}) {
                    $ipAddressType = "ipv6";
                    $domain = "UDP/IPv6";
               } else {
                    log_msg("ERROR: Required perl module Socket6 not found.");
                    print "\nERROR: Required perl module Socket6 not found\n";
                    $totalHostsUnreachable = $totalHostsUnreachable + 1;
                    next; 
                
               }
           }
                
        }
            $fqdnName = $deviceAddress;
   }

   if($fqdnName ne "")
   {
       $host_file = "$HOST_CONFIG_DIR/"."$fqdnName".".cfg";
   }else{
       $host_file = "$HOST_CONFIG_DIR/"."$deviceAddress".".cfg";
       $fqdnName = $deviceAddress;
   }

### Setting URL for console launch

####################################################################################### 
#set the url for CMC(M1000e, VRTX, FX2 and FX2s), iDRAC, Compellent, EqualLogic devices
#   but MD will not have 1X1 console launch 
#######################################################################################
    
   if ($url_flag == 0 ) 
   {
       $racURL = "http://" . $fqdnName; 
   } else {
       $racURL = "http://[" . $fqdnName . "]"; 
   }

   if ( -e "$host_file" ) {
       $totalhostsAlreadyDiscovered = $totalhostsAlreadyDiscovered + 1;
       if(lc($fileWriteEnable) eq "n")
       {
           log_msg("INFO: Previously discovered information is available and overwrite option is set to NO. So ignoring discovery for host $deviceAddress ");
           next;
       }        
   }

   if (eval{require Net::SNMP; 1}) 
   {
       my ($session, $error) = Net::SNMP->session( Hostname  => $deviceAddress,
                                                    Community => $snmpCommunity,
                                                    version   => $snmpParams{'snmp.version'},
                                                    retries   => $snmpParams{'snmp.retries'},
                                                    timeout   => $snmpParams{'snmp.timeout'},
                                                    domain    => $domain,  
                                                    port      => $snmpParams{'snmp.port'} ) 
                                or log_msg("ERROR: Failed to create session with $deviceAddress .");

       if (!defined($session) ||  $snmpStat eq "false") 
       {
           log_msg("ERROR: 1st Failed to create SNMP session for the host: $deviceAddress, \n",  $error);     
           $snmpStat = "true";
           $flag_SNMP_fails = "true";
           $deviceType = "UNKNOWN";
       }
       else
       {
           my $sysObjectIDResponse = $session->get_request("$sysObjectIdOid") or $snmpStat = "false";   
           $sysObjectID            = $sysObjectIDResponse->{"$sysObjectIdOid"};
           $snmpStat               = "true";            
           $session->close;
           log_msg("INFO: Retrieved sysObjectID: $sysObjectID for $deviceAddress");
           if ("$sysObjectID" ne "")
           {
               if ("$sysObjectID" eq "$oobServerSysObjectIdValue")
               {
                   if ($communicationProtocol eq "snmp")
                   {
                       $deviceType = $oobdevice;
                       log_msg ("INFO: Retrieved sysObjectID: $sysObjectID and device: $oobdevice for $deviceAddress");
                   }
               }
               elsif ("$sysObjectID" eq "$chassisSysObjIDValue")
               {
                   $deviceType = $chassisdevice;
                   log_msg ("INFO: Retrieved sysObjectID: $sysObjectID and device: $chassisdevice for $deviceAddress");                
               }
               elsif ("$sysObjectID" eq "$eqlSysObjId")
               {
                   $deviceType = $eqldevice;
                   log_msg ("INFO: Retrieved sysObjectID: $sysObjectID and device: $eqldevice for $deviceAddress");
               }
               elsif ("$sysObjectID" eq "$compellentSysObjIDValue")
               {
                   $deviceType = $compllentdevice;
                   log_msg ("INFO: Retrieved sysObjectID: $sysObjectID and device: $compllentdevice for $deviceAddress");
               }
               elsif ("$sysObjectID" eq "$mdSysObjIDValue")
               {
                   $deviceType = $mddevice;
                   log_msg ("INFO: Retrieved sysObjectID: $sysObjectID and device: $mddevice for $deviceAddress");
               }
               else	#device is not SNMP based or not a Dell EMC device
               {
                   $deviceType = "UNKNOWN";
                   log_msg("ERROR: Not a supported Dell EMC device sysObjectID: $sysObjectID for $deviceAddress");
               }
           }
           else
           {
               $flag_SNMP_fails = "true";
               $deviceType = "UNKNOWN";
           }
       }
   }

   if($flag_SNMP_fails eq "false") 
   {      
       log_msg("INFO: sysObjectID value is : $sysObjectID for IP Address and device: $deviceType using SNMP protocol for $deviceAddress");
       if ("$sysObjectID" eq "$oobServerSysObjectIdValue")
       {
           if ($communicationProtocol eq "snmp")
           {
               #get sysName and serviceTag from iDRAC
               my $returnCode = getiDRACDetails($deviceAddress, "snmp");
               if( $returnCode eq "fail" )
               {
                   log_msg ("INFO: Failed to retrieve iDRAC details. Skipping $deviceAddress discovery.");
                   $totalUnresponsiveHosts = $totalUnresponsiveHosts + 1;
                   next;
               }
               elsif($returnCode eq $error_response || $sysName eq "" || $serviceTag eq "" || $deviceType eq "" )
               {
                   log_msg ("INFO: Failed to retrieve iDRAC details due to error response. Skipping $deviceAddress discovery.");
                   $totalErrorReponseHosts = $totalErrorReponseHosts + 1;
                   next;
               }
               else
               {
                   $deviceInfoRet = "success";
                   $totalOOBDiscovered = $totalOOBDiscovered + 1;
               }
               log_msg ("INFO: Retrieved iDRAC sysName:$sysName and serviceTag:$serviceTag and device type:$deviceType using SNMP protocol from $deviceAddress.");
           }
       }
       elsif ("$sysObjectID" eq "$chassisSysObjIDValue") 
       {
           my $returnCode = getChassisDetails($deviceAddress);

           if($returnCode eq "fail")
           {
               log_msg ("INFO: Failed to retrieve chassis details. Skipping $deviceAddress discovery.");
               $totalUnresponsiveHosts = $totalUnresponsiveHosts + 1;
               next;
           }
           elsif($returnCode eq $error_response || $sysName eq "" || $serviceTag eq "" || $racType eq "" || $deviceType eq "")
           {
               log_msg ("INFO: Failed to retrieve iDRAC details due to error response. Skipping $deviceAddress discovery.");
               $totalErrorReponseHosts = $totalErrorReponseHosts + 1;
               next;
           }
           else
           {
               $deviceInfoRet = "success";
               $totalChassisDiscovered = $totalChassisDiscovered + 1;
           }
           log_msg ("INFO: Chassis details sysName:$sysName ,racType:$racType ,device type:$deviceType and serviceTag:$serviceTag for $deviceAddress.");
       }
       elsif ("$sysObjectID" eq "$eqlSysObjId")
       {
           my $returnCode = getEqualDetails($deviceAddress,$ipAddressType);                    
           log_msg ("INFO: EqualLogic details sysName:$sysName, device Type:$deviceType ,serviceTag:$serviceTag for $deviceAddress");
           log_msg ("INFO: EqualLogic details Group IP:$eqlgroupIP, Group Name:$eqlgroupName and Member index:$eqlMemberIndex for $deviceAddress.");
           
           if ($returnCode eq "fail")
           {
               $totalUnresponsiveHosts = $totalUnresponsiveHosts + 1;
               log_msg ("INFO: Failed to retrieve EqualLogic details. Skipping $deviceAddress discovery.");
               next;
           }
           elsif ($returnCode eq $error_response || $sysName eq "" || $deviceType eq "" || $eqlgroupIP eq "" || $eqlgroupName eq "" || $serviceTag eq "" || $eqlMemberIndex eq "")
           {
               $totalErrorReponseHosts = $totalErrorReponseHosts + 1;
               log_msg ("INFO: Failed to retrieve EqualLogic details due to error response. Skipping $deviceAddress discovery.");
               next;
           }
           else
           {
               $deviceInfoRet = "success";
               $totalStorageDiscovered = $totalStorageDiscovered + 1;
           }
       }
       elsif ("$sysObjectID" eq "$compellentSysObjIDValue")
       {
           my $returnCode = getCompellentDetails($deviceAddress,$ipAddressType);                     
           log_msg ("INFO: Compellent sysName:$sysName, serviceTag:$serviceTag, device Type:$deviceType, management IP:$compellentMgmtIp and controller index:$compellentCtlIndex using SNMP protocol.");
           
           if ($returnCode eq "fail")
           {
               $totalUnresponsiveHosts = $totalUnresponsiveHosts + 1;
               log_msg ("INFO: Failed to retrieve Compellent details. Skipping $deviceAddress discovery.");
               next;
           }
           elsif ($returnCode eq $error_response || $sysName eq "" || $deviceType eq "" || $compellentMgmtIp eq "" || $serviceTag eq "" || $compellentCtlIndex eq "")
           {
               $totalErrorReponseHosts = $totalErrorReponseHosts + 1;
               log_msg ("INFO: Failed to retrieve Compellent details due to error response. Skipping $deviceAddress discovery.");
               next;
           }
           else
           {
               $deviceInfoRet = "success";
               $totalStorageDiscovered = $totalStorageDiscovered + 1;
           } 
       }
       elsif ("$sysObjectID" eq "$mdSysObjIDValue")
       {
           my $returnCode = getMdDetails($deviceAddress);                    
           log_msg ("INFO: MD Storage Array sysName:$sysName, serviceTag:$serviceTag, device Type:$deviceType using SNMP protocol.");
           
           if ($returnCode eq "fail")
           {
               $totalUnresponsiveHosts = $totalUnresponsiveHosts + 1;
               log_msg ("INFO: Failed to retrieve MD Storage Array details. Skipping $deviceAddress discovery.");
               next;
           }
           elsif ($returnCode eq $error_response || $sysName eq "" || $deviceType eq "" || $serviceTag eq "")
           {
               $totalErrorReponseHosts = $totalErrorReponseHosts + 1;
               log_msg ("INFO: Failed to retrieve MD Storage Array details due to error response. Skipping $deviceAddress discovery.");
               next;
           }
           else
           {
               $deviceInfoRet = "success";
               $totalStorageDiscovered = $totalStorageDiscovered + 1;
           } 
       }
       else
       {
           log_msg ("INFO: $deviceAddress is not supported dell EMC device.");
           $totalErrorReponseHosts = $totalErrorReponseHosts + 1;
           next;
       }
    
   }
   log_msg("INFO: condition for doing discovery based on protocol:$communicationProtocol ,SNMP flag:$flag_SNMP_fails device details return:$deviceInfoRet for $deviceAddress");
   if(($communicationProtocol eq "wsman" || $flag_SNMP_fails eq "true") && $deviceInfoRet eq "fail")
   {
       my $returnCode = getiDRACDetails($deviceAddress, "wsman");
       
       if ($flag_SNMP_fails eq "true" && $returnCode eq "fail")
       {
           log_msg("ERROR: Failed to retrieve the iDRAC device details, get chassis details for $deviceAddress");
           my $returnCode = getChassisDetails($deviceAddress);
           if ($returnCode eq "fail")
           {
               $totalUnresponsiveHosts = $totalUnresponsiveHosts + 1;
               log_msg("ERROR:Failed to retrieve the device details. Cannot discover $deviceAddress");
               next;
           }
           elsif($returnCode eq $error_response || $sysName eq "" || $serviceTag eq "" || $deviceType eq "" || $racType eq "")
           {
               log_msg ("INFO: Failed to retrieve device details due to error response. Skipping $deviceAddress discovery.");
               $totalErrorReponseHosts = $totalErrorReponseHosts + 1;
               next;
           }
           else
           {
               log_msg ("INFO: Chassis details sysName:$sysName ,racType:$racType ,device type:$deviceType and serviceTag:$serviceTag for $deviceAddress.");
               $deviceInfoRet = "success";
               $totalChassisDiscovered = $totalChassisDiscovered + 1;
           }
           
       }
       elsif ($sysName ne "" and $serviceTag ne "" and $deviceType ne "")
       {
           $deviceType = $oobdevice;
           $deviceInfoRet = "success";
           $totalOOBDiscovered = $totalOOBDiscovered + 1;
           log_msg ("INFO: Retrieved iDRAC sysName:$sysName and serviceTag:$serviceTag and device type:$deviceType using WSMAN protocol from $deviceAddress.");
       }
       elsif($returnCode eq $error_response || $sysName eq "" || $serviceTag eq "" || $deviceType eq "" )
       {
           log_msg ("INFO: Failed to retrieve iDRAC details. Skipping $deviceAddress discovery.");
           $totalErrorReponseHosts = $totalErrorReponseHosts + 1;
           next;
       }
       else
       {
           $totalUnresponsiveHosts = $totalUnresponsiveHosts + 1;
           log_msg("ERROR: Failed to retrieve the device details using both SNMP and WSMAN. Cannot discover $deviceAddress");
           next;
       }
   } 
   
   if($deviceType eq $oobdevice)
   {
       createiDRACcfgFile($host_file,$hostObject,$hostName,$fqdnName,$sysName,$serviceTag,$hostGroup,$communicationProtocol);
   }
   elsif($deviceType eq $cmcM1000edevice || $deviceType eq $cmcVRTXdevice || $deviceType eq $cmcFX2device)
   {
       createChassiscfgFile($host_file,$deviceType,$chassishostObject,$hostName,$fqdnName,$sysName,$serviceTag,$chassishostGroup,$communicationProtocol,$url_flag);
   }
   elsif($deviceType eq $eqlMemberDevice || $deviceType eq $eqlGroupDevice)
   {
       createEqlcfgFile($host_file,$deviceType,$storagehostObject,$hostName,$fqdnName,$sysName,$serviceTag,$eqlMemberIndex,$storagehostGroup,$eqlgroupIP,$deviceIPfromHostName);
   }
   elsif($deviceType eq $mddevice)
   {
       createMdcfgFile($host_file,$deviceType,$storagehostObject,$hostName,$fqdnName,$sysName,$serviceTag);
   }
   elsif($deviceType eq $compellentMgmtdevice || $deviceType eq $compellentCtldevice)
   {
       createCompcfgFile($host_file,$deviceType,$storagehostObject,$hostName,$fqdnName,$sysName,$serviceTag,$compellentMgmtIp,$compellentCtlIndex,$storagehostGroup);
   }  
   $sysName         = "";
   $hostName        = "";
   $deviceType      = "";
   $serviceTag      = "";
   $eqlgroupIP      = "";
   $eqlMemberIndex  = "";
   $compellentMgmtIp        = "";
   $compellentCtlIndex      = ""; 
   $deviceIPfromHostName    = "";      
   $totalhostsDiscovered    = $totalhostsDiscovered + 1 ;
}
unless(open FILE, ">$$.txt") 
{
   die "\nUnable to create $$.txt\n";
}
   my $returnVal = $totalHostsAttempted."|".$totalHostsUnreachable."|".$totalErrorReponseHosts."|".$totalUnresponsiveHosts."|".$totalhostsAlreadyDiscovered."|".    $totalhostsDiscovered."|".$totalOOBDiscovered."|".$totalChassisDiscovered."|".$totalStorageDiscovered;
   print  FILE "$returnVal"; 
   close FILE;
   
   return 2;
}

sub createCompcfgFile
{
   my ($host_file,$deviceType,$storagehostObject,$hostName,$fqdnName,$sysName,$serviceTag,$compellentMgmtIp,$compellentCtlIndex,$storagehostGroup) = @_;
   my $defaultParentsVal = "null";
   my $dellCommParams = "SNMP,"."$snmpParams{'snmp.community'},"."$snmpParams{'snmp.version'},"."$snmpParams{'snmp.timeout'},"."$snmpParams{'snmp.retries'},"."$snmpParams{'snmp.port'},"."$domain";
   if (ip_is_ipv4($compellentMgmtIp))
   {
       $racURL = "https://" . $compellentMgmtIp;
   }
   else
   {
       $racURL = "https://[" . $compellentMgmtIp . "]";
   }
   my %servicehash;
   if ($deviceType eq $compellentMgmtdevice )
   {
       %servicehash = %compelmgmtdefinedservice;
   }
   elsif($deviceType eq $compellentCtldevice)
   {
       %servicehash = %compelctrldefinedservice;
   } 
   
   my $warrantyInformationCommand  = "$warrantyInformationCommand!" . " " ."\"$host_file\"! "; 
   my $compellentComponentHealthServiceCommand  = "$compellentComponentHealthServiceCommand!" . " " ."\"$host_file\"! ";  
   #my $protocolUsed = "Protocol selected : SNMP";
   open OUTPUT1, '>', $host_file or log_msg ("ERROR: Can't create $host_file filehandle \n : $!");
   select OUTPUT1; $| = 1;  # make unbuffered
            
       print <<CONFIGEND;
       #======================================================================================
       #                Dell EMC Storage SC-Series host definition
       #======================================================================================

       define host{
           use                     $storagehostObject
           host_name               $hostName
           alias                   $hostName
           address                 $fqdnName
           display_name            $sysName
           icon_image              $comStgImage
           hostgroups              $storagehostGroup
           statusmap_image         $comStgImage
           action_url              $racURL
           _dell_comm_params       $dellCommParams
           _serviceTag             $serviceTag
           _INDEX                  $compellentCtlIndex
           parents                 $defaultParentsVal
        }

CONFIGEND

   foreach my $keyServiceName (keys %servicehash) 
   {
       if($servicehash{$keyServiceName} eq 'Dell EMC Storage SC-Series Management Traps' || $servicehash{$keyServiceName} eq 'Dell EMC Storage SC-Series Controller Traps')
        {
            if ($snmpttInstalled ne "false")
            { 
           print <<CONFIGEND;
        define service{
            use                     $dellDeviceTrapServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}
        }

CONFIGEND
        }
        log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ($servicehash{$keyServiceName} eq 'Dell EMC Storage SC-Series Information' || $servicehash{$keyServiceName} eq 'Dell EMC Storage SC-Series Controller Information')
        {
            print <<CONFIGEND;
        define service{
            use                     $dellServerInfoServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $compellentComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}}  
        }

CONFIGEND
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ($servicehash{$keyServiceName} eq 'Dell EMC Storage SC-Series Overall Health Status' || $servicehash{$keyServiceName} eq 'Dell EMC Storage SC-Series Controller Overall Health Status')
        {
            print <<CONFIGEND;
        define service{
            use                     $dellServerGHSServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $compellentComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}}  
        }

CONFIGEND
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ( ($servicehash{$keyServiceName} eq 'Dell EMC Storage SC-Series Controller Warranty Information'))
        {
		 if($javaInstalled ne "false"){	
            print <<CONFIGEND;
        define service{
            use                     $dellServerInfoServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $warrantyInformationCommand  $serviceArgs{$servicehash{$keyServiceName}}  
        }

CONFIGEND
		}
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        else
        {
            print <<CONFIGEND;
        define service{
            use                     $oobServerComponentHealthServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $compellentComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}}  
        }

CONFIGEND
        log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        } 

   }

   close(OUTPUT1);
}


sub createEqlcfgFile
{
   my ($host_file,$deviceType,$storagehostObject,$hostName,$fqdnName,$sysName,$serviceTag,$eqlMemberIndex,$storagehostGroup,$eqlgroupIP,$deviceIP) = @_;
   my $defaultParentsVal = "null";
   my $dellCommParams = "SNMP,"."$snmpParams{'snmp.community'},"."$snmpParams{'snmp.version'},"."$snmpParams{'snmp.timeout'},"."$snmpParams{'snmp.retries'},"."$snmpParams{'snmp.port'},"."$domain";
   if ($eqlgroupIP eq "NA")
   {  #unable to retrieve equallogic group ip but to launch eql console need to set member ip 
      $eqlgroupIP = $deviceIP;
   }
   if (ip_is_ipv4($eqlgroupIP))
   {
       $racURL = "http://" . $eqlgroupIP;
   }
   else
   {
       $racURL = "http://[" . $eqlgroupIP . "]";
   }
   my %servicehash;
   if ($deviceType eq $eqlGroupDevice )
   {
       %servicehash = %eqlgrpdefinedservice;
       $serviceTag  = "NA";
   }
   elsif($deviceType eq $eqlMemberDevice)
   {
       %servicehash = %eqlmemdefinedservice;
   } 
   
   my $warrantyInformationCommand  = "$warrantyInformationCommand!" . " " ."\"$host_file\"! "; 
   my $eqlComponentHealthServiceCommand  = "$eqlComponentHealthServiceCommand!" . " " ."\"$host_file\"! ";  
   #my $protocolUsed = "Protocol selected : SNMP";
   open OUTPUT1, '>', $host_file or log_msg ("ERROR: Can't create $host_file filehandle \n : $!");
   select OUTPUT1; $| = 1;  # make unbuffered
            
        print <<CONFIGEND;
        #======================================================================================
        #             Dell EMC Storage PS-Series host definition
        #======================================================================================

        define host{
            use                     $storagehostObject
            host_name               $hostName
            alias                   $hostName
            address                 $fqdnName
            display_name            $sysName
            icon_image              $storageImage
            hostgroups              $storagehostGroup
            statusmap_image         $storageImage
            action_url              $racURL
            _dell_comm_params       $dellCommParams
            _serviceTag             $serviceTag
            _INDEX                  $eqlMemberIndex
            parents                 $defaultParentsVal
        }

CONFIGEND
    
    foreach my $keyServiceName (keys %servicehash) 
    {
        if($servicehash{$keyServiceName} eq 'Dell EMC Storage PS-Series Member Traps' || $servicehash{$keyServiceName} eq 'Dell EMC Storage PS-Series Group Traps')
        {
            if ($snmpttInstalled ne "false")
            { 
            print <<CONFIGEND;
        define service{
            use                     $dellDeviceTrapServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}
        }

CONFIGEND
            }
            log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ($servicehash{$keyServiceName} eq 'Dell EMC Storage PS-Series Member Information' || $servicehash{$keyServiceName} eq 'Dell EMC Storage PS-Series Group Information')
        {
            print <<CONFIGEND;
        define service{
            use                     $dellServerInfoServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $eqlComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}} 
        }

CONFIGEND
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ($servicehash{$keyServiceName} eq 'Dell EMC Storage PS-Series Member Overall Health Status')
        {
            print <<CONFIGEND;
        define service{
            use                     $dellServerGHSServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $eqlComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}} 
        }

CONFIGEND
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ( ($servicehash{$keyServiceName} eq 'Dell EMC Storage PS-Series Member Warranty Information')  )
        {
		
		if($javaInstalled ne "false"){		
            print <<CONFIGEND;
        define service{
            use                     $dellServerInfoServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $warrantyInformationCommand  $serviceArgs{$servicehash{$keyServiceName}}  
        }
		

CONFIGEND
		}
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        else
        {
            print <<CONFIGEND;
        define service{
            use                     $oobServerComponentHealthServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $eqlComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}} 
        }

CONFIGEND
        log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        } 

    }

    close(OUTPUT1);
}

sub createMdcfgFile
{
   my ($host_file,$deviceType,$storagehostObject,$hostName,$fqdnName,$sysName,$serviceTag) = @_;
   
   my $defaultParentsVal = "null";
   my $dellCommParams = "SNMP,"."$snmpParams{'snmp.community'},"."$snmpParams{'snmp.version'},"."$snmpParams{'snmp.timeout'},"."$snmpParams{'snmp.retries'},"."$snmpParams{'snmp.port'},"."$domain";
   
   my %servicehash = %mddefinedservice;
	
   my $warrantyInformationCommand  = "$warrantyInformationCommand!" . " " ."\"$host_file\"! ";
   my $mdComponentHealthServiceCommand  = "$mdComponentHealthServiceCommand!" . " " ."\"$host_file\"! ";  

   open OUTPUT1, '>', $host_file or log_msg ("ERROR: Can't create $host_file filehandle \n : $!");
   select OUTPUT1; $| = 1;  # make unbuffered
            
        print <<CONFIGEND;
        #======================================================================================
        #              Dell EMC Storage MD-Series host definition
        #======================================================================================

        define host{
            use                     $storagehostObject
            host_name               $hostName
            alias                   $hostName
            address                 $fqdnName
            display_name            $sysName
            icon_image              $mdStgImage
            hostgroups              $storagehostGroup
            statusmap_image         $mdStgImage
            _dell_comm_params       $dellCommParams
            _serviceTag             $serviceTag
            parents                 $defaultParentsVal
        }

CONFIGEND
    
    foreach my $keyServiceName (keys %servicehash) 
    {
        if($servicehash{$keyServiceName} eq 'Dell EMC Storage MD-Series Traps')
        {
		    if ($snmpttInstalled ne "false")
            { 
            print <<CONFIGEND;
        define service{
            use                     $dellDeviceTrapServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}
        }

CONFIGEND
		}
            log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ($servicehash{$keyServiceName} eq 'Dell EMC Storage MD-Series Information')
        {
            print <<CONFIGEND;
        define service{
            use                     $dellServerInfoServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $mdComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}} 
        }

CONFIGEND
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ($servicehash{$keyServiceName} eq 'Dell EMC Storage MD-Series Overall Health Status')
        {
            print <<CONFIGEND;
        define service{
            use                     $dellServerGHSServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $mdComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}} 
        }
		
CONFIGEND
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ( $servicehash{$keyServiceName} eq 'Dell EMC Storage MD-Series Warranty Information')
        {
		   if($javaInstalled ne "false"){	
		   print <<CONFIGEND;
        define service{
            use                     $dellServerInfoServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $warrantyInformationCommand  $serviceArgs{$servicehash{$keyServiceName}}  
        }

CONFIGEND
		}
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        else
        {
            print <<CONFIGEND;
        define service{
            use                     $oobServerComponentHealthServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $mdComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}} 
        }

CONFIGEND
        log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        } 

    }

    close(OUTPUT1);
}

sub createiDRACcfgFile
{
   my ($host_file,$hostObject,$hostName,$fqdnName,$sysName,$serviceTag,$hostGroup,$communicationProtocol) = @_;
   my $defaultParentsVal = "null";
   my %servicehash;
   my $dellCommParams = "";
   if ($communicationProtocol eq "snmp")
   {
       %servicehash = %idracsnmpdefinedservice;
       $dellCommParams = "SNMP,"."$snmpParams{'snmp.community'},"."$snmpParams{'snmp.version'},"."$snmpParams{'snmp.timeout'},"."$snmpParams{'snmp.retries'},"."$snmpParams{'snmp.port'},"."$domain";
   }
   else
   {
       %servicehash = %idracwsmandefinedservice;
       $dellCommParams = "WSMAN,"."$wsmanParams{'wsman.username'},"."$wsmanParams{'wsman.password'},"."$wsmanParams{'wsman.timeout'},"."$wsmanParams{'wsman.port'},"."0,"."$wsmanParams{'wsman.retries'}";
   }
   my $warrantyInformationCommand  = "$warrantyInformationCommand!" . " " ."\"$host_file\"! "; 
   my $oobServerComponentHealthServiceCommand  = "$oobServerComponentHealthServiceCommand" . "$communicationProtocol!" ." " ."\"$host_file\"! ";  
   my $protocolUsed = "Protocol selected : " . uc($communicationProtocol);
   open OUTPUT1, '>', $host_file or log_msg ("ERROR: Can't create $host_file filehandle \n : $!");
   select OUTPUT1; $| = 1;  # make unbuffered
            
        print <<CONFIGEND;
        #======================================================================================
        #         Dell EMC Agent free Server host definition
        #======================================================================================

        define host{
            use                     $hostObject
            host_name               $hostName
            alias                   $hostName
            address                 $fqdnName
            display_name            $sysName
            icon_image              $image
            hostgroups              $hostGroup
            statusmap_image         $image
            action_url              $racURL
            _dell_comm_params       $dellCommParams
            _serviceTag             $serviceTag
            notes                   $protocolUsed
            parents                 $defaultParentsVal
        }

CONFIGEND
    
    foreach my $keyServiceName (keys %servicehash) 
    {
        if($servicehash{$keyServiceName} eq 'Dell EMC Server Traps')
        {
            if ($snmpttInstalled ne "false")
            {   
            print <<CONFIGEND;
        define service{
            use                     $dellDeviceTrapServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}
        }

CONFIGEND
            }
            log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ($servicehash{$keyServiceName} eq $dellServerInfoTemplateEntry)
        {
            print <<CONFIGEND;
        define service{
            use                     $dellServerInfoServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $oobServerComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}}
        }

CONFIGEND
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ($servicehash{$keyServiceName} eq $dellServerGHSTemplateEntry)
        {
            print <<CONFIGEND;
        define service{
            use                     $dellServerGHSServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $oobServerComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}}
        }

		
CONFIGEND
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ($servicehash{$keyServiceName} eq 'Dell EMC Server Warranty Information')
        {
		  if($javaInstalled ne "false"){	
		   print <<CONFIGEND;
        define service{
            use                     $dellServerInfoServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $warrantyInformationCommand  $serviceArgs{$servicehash{$keyServiceName}}  
        }
		
CONFIGEND
        }
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
		}
        else
        {
            print <<CONFIGEND;
        define service{
            use                     $oobServerComponentHealthServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $oobServerComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}}
        }

CONFIGEND
        log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        } 

    }

    close(OUTPUT1);
}

sub createChassiscfgFile
{
    my($host_file,$deviceType,$chassishostObject,$hostName,$fqdnName,$sysName,$serviceTag,$chassishostGroup,$protocolUsed,$isIPv4) = @_;
    
    my $dellCommParams = "WSMAN,"."$wsmanParams{'wsman.username'},"."$wsmanParams{'wsman.password'},"."$wsmanParams{'wsman.timeout'},"."$wsmanParams{'wsman.port'},"."0,"."$wsmanParams{'wsman.retries'}";
    my $defaultParentsVal = "null";
    my %servicehash;
    if ($deviceType eq $cmcM1000edevice || $deviceType eq $cmcFX2device || ($deviceType eq $cmcVRTXdevice && $serviceOption eq "basic"))
    {
        %servicehash = %chassisdefinedservice;
        if ($deviceType eq $cmcFX2device)
        {
            %servicehash = (%chassisdefinedservice,%vrtxfx2definedservice);
        }
    }
    else
    {
        %servicehash = %vrtxdefinedservice;
        %servicehash = (%vrtxdefinedservice,%vrtxfx2definedservice);
    }
	
	#This piece of code is written, incase no chassis URL is return from the device.
	if( $chassisURL eq "" )
	{
		if ($isIPv4 == 0 ) 
		{
			$chassisURL = "http://" . $fqdnName; 
		} 
		else 
		{
		   $chassisURL = "http://[" . $fqdnName . "]"; 
		}
    }
   
   my $warrantyInformationCommand  = "$warrantyInformationCommand!" . " " ."\"$host_file\"! "; 
   my $chassisComponentHealthServiceCommand  = "$chassisComponentHealthServiceCommand!" . " " ."\"$host_file\"! ";  
   #my $protocolUsed = "Protocol selected : WSMAN";
   open OUTPUT1, '>', $host_file or log_msg ("ERROR: Can't create $host_file filehandle \n : $!");
   select OUTPUT1; $| = 1;  # make unbuffered
            
        print <<CONFIGEND;
        #======================================================================================
        #               Dell EMC Chassis host definition
        #======================================================================================

        define host{
            use                     $chassishostObject
            host_name               $hostName
            alias                   $hostName
            address                 $fqdnName
            display_name            $sysName
            icon_image              $chassisImage
            hostgroups              $chassishostGroup
            statusmap_image         $chassisImage
            action_url              $chassisURL
            _dell_comm_params       $dellCommParams
            _serviceTag             $serviceTag
            parents                 $defaultParentsVal
        }

CONFIGEND
    
    foreach my $keyServiceName (keys %servicehash) 
    {
        if($servicehash{$keyServiceName} eq 'Dell EMC Chassis Traps')
        {
            if ($snmpttInstalled ne "false")
            { 
            print <<CONFIGEND;
        define service{
            use                     $dellDeviceTrapServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}
        }

CONFIGEND
            }
            log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ($servicehash{$keyServiceName} eq 'Dell EMC Chassis Information')
        {
            print <<CONFIGEND;
        define service{
            use                     $dellServerInfoServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $chassisComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}}
        }

CONFIGEND
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ($servicehash{$keyServiceName} eq 'Dell EMC Chassis Overall Health Status')
        {
            print <<CONFIGEND;
        define service{
            use                     $dellServerGHSServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $chassisComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}}
        }

CONFIGEND
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        }
        elsif ($servicehash{$keyServiceName} eq 'Dell EMC Chassis Warranty Information')
        {
          if($javaInstalled ne "false"){	
			print <<CONFIGEND;
        define service{
            use                     $dellServerInfoServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $warrantyInformationCommand  $serviceArgs{$servicehash{$keyServiceName}}  
        }
		
CONFIGEND
        }
		log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
		}
        else
        {
            print <<CONFIGEND;
        define service{
            use                     $oobServerComponentHealthServiceName
            host_name               $hostName
            service_description     $servicehash{$keyServiceName}   
            check_command           $chassisComponentHealthServiceCommand  $serviceArgs{$servicehash{$keyServiceName}}
        }

CONFIGEND
        log_msg("INFO: $servicehash{$keyServiceName} service created for host $deviceAddress");
        } 
    }
    close(OUTPUT1);    
}

sub getiDRACDetails
{
    $deviceAddress = shift;
    $protocolSelected = shift;
    my $snmpStat = "true";
    if ($communicationProtocol eq "snmp" && $protocolSelected eq "snmp")
    {
        if (eval { require Net::SNMP; 1}) 
        {
            my ($session, $error) = Net::SNMP->session( Hostname  => $deviceAddress,
                                                        Community => $snmpCommunity,
                                                        version   => $snmpParams{'snmp.version'},
                                                        retries   => $snmpParams{'snmp.retries'},
                                                        timeout   => $snmpParams{'snmp.timeout'},
                                                        domain    => $domain,  
                                                        port      => $snmpParams{'snmp.port'} ) 
                                    or log_msg("ERROR: Failed to create session with $deviceAddress .");
            if (!defined($session) || $snmpStat eq "false") 
            {
                log_msg("ERROR: Failed to create SNMP session for the host: $deviceAddress, \n",  $error);     
                $snmpStat = "true";
                return "fail";
            } 
            else
            {
                #get sysName
                my @oids = ($sysNameOid,$oobServiceTag);
                my $response1 = $session->get_entries(-columns => \@oids,);
                my $tempkey1 = $sysNameOid . '.0';
                my $tempkey2 = $oobServiceTag . '.0';
           
               foreach my $entry (keys  %{$response1})
               {
                   if ($entry eq $tempkey1)
                   {
                       $sysName = $response1->{$tempkey1};
                   }
                   elsif($entry eq $tempkey2)
                   {
                       $serviceTag = $response1->{$tempkey2};
                   }
               }
               if ($sysName eq "" or $serviceTag eq "" )
               {
                   $session->close;
                   log_msg("ERROR: Failed to retrieve iDRAC information. Cannot discover $deviceAddress");
                   return $error_response;
               }
               else
               {
                   $deviceType = $oobdevice;
                   $hostName =  $sysName;
               }
               $session->close;
               log_msg ("INFO: Retrieved sysName: $sysName ,device type: $deviceType and ,ServiceTag: $serviceTag using SNMP protocol for $deviceAddress.");
           }
       }
       else 
       {
           log_msg("ERROR: Required perl module Net::SNMP not found.");
           #print "\nERROR: Required perl module Net::SNMP not found\n";
           return "fail";
       }
   }
   elsif($communicationProtocol eq "wsman" && $protocolSelected eq "wsman")
   {
       if (eval { require openwsman; 1}) 
       {
           $sysName = "";
           $hostName = "";
           # Create client connection
           $wsmanClient = new openwsman::Client::($deviceAddress, $wsmanParams{'wsman.port'}, $wsmanParams{'wsman.path'}, $wsmanParams{'wsman.scheme'}, $wsmanUser, $wsmanPasswd )
                           or log_msg("ERROR: Failed to create wsman client handler for device $deviceAddress")  and print "[ERROR] Could not create wsmanClient handler.\n" && return "fail" ;
           
           # Set up wsmanClient options.
           my $options = new openwsman::ClientOptions::()
                          or log_msg("ERROR: Failed to create wsman client options for device $deviceAddress") and print "[ERROR] Could not create wsmanClient options handler.\n" and return "fail";
                     
           my $result; # Used to store obtained data.
           my $context = undef;    
           
           my $uri;
           my $filter;
           #get sysName and rac URL
           $uri = 'http://schemas.dell.com/wbem/wscim/1/cim-schema/2/DCIM_iDRACCardView';                

           $filter = new openwsman::Filter::()
                    or  log_msg("ERROR: Failed to create wsman filter for device $deviceAddress") &&  next;
           $filter->wql('SELECT DNSRacName from DCIM_iDRACCardView');  
           
           my @res =  enumerateWsman($wsmanClient, $options, $uri, $filter);
           foreach(@res)
           {
               my %myMap= %$_;
               if( exists($myMap{'DNSRacName'} ) )
               {
                   $sysName=$myMap{'DNSRacName'};
               }
           }
           if($sysName eq "")     
           {
               log_msg("ERROR: Retrieved sysName is null/failed to retrieve sysName. Cannot discover $deviceAddress");
               return "fail";
           }
           else
           {
               $uri = 'http://schemas.dell.com/wbem/wscim/1/cim-schema/2/DCIM_SystemView';          
           
               $filter = new openwsman::Filter::()
                         or  log_msg("ERROR: Failed to create wsman filter for device $deviceAddress") &&  return "fail";
               $filter->wql('SELECT ServiceTag from DCIM_SystemView'); 
           }
           ## get the values

           @res =  enumerateWsman($wsmanClient, $options, $uri, $filter);
           foreach(@res)
           {
               my %myMap= %$_;
               if( exists($myMap{'ServiceTag'} ) )
               {
                   $serviceTag=$myMap{'ServiceTag'};                                                   
               }
           }
           if ($serviceTag eq "" && $sysName eq "")
           {
               #Release the wsman context
               $wsmanClient->release($options, $uri, $context) if($context);	
               return $error_response;
           }
           else
           {
               $deviceType = $oobdevice;
               $hostName =  $sysName;
           }
           log_msg ("INFO: Retrieved sysName: $sysName and ServiceTag: $serviceTag values from $deviceAddress");  
           
           #Release the wsman context
           $wsmanClient->release($options, $uri, $context) if($context);
       }
       else 
       {
	       log_msg("ERROR: Required perl module openwsman not found.");
		   #print "\nERROR: Required perl module openwsman not found\n";
           return "fail";
       }    
   }
   else
   {
       return "fail";
   }
}

sub getChassisDetails 
{
   my $deviceAddress = shift;

   if (eval { require openwsman; 1}) 
   {
       $sysName = "";
       $hostName = "";
       # Create client connection
       $wsmanClient = new openwsman::Client::($deviceAddress, $wsmanParams{'wsman.port'}, $wsmanParams{'wsman.path'}, $wsmanParams{'wsman.scheme'}, $wsmanUser, $wsmanPasswd )         or  
                      log_msg("ERROR: Failed to create wsman client handler for device $deviceAddress")  
                      and print "[ERROR] Could not create wsmanClient handler.\n" && return "fail" ;
       
       # Set up wsmanClient options.
       my $options = new openwsman::ClientOptions::()
                     or log_msg("ERROR: Failed to create wsman client options for device $deviceAddress") 
                     and  print "[ERROR] Could not create wsmanClient options handler.\n" and return "fail";

       my $context = undef;
       my $uri;
       my $filter;
       #get sysName and rac type
       $uri = 'http://schemas.dell.com/wbem/wscim/1/cim-schema/2/root/dell/cmc/DCIM_ModularChassisView';                

       $filter = new openwsman::Filter::()
                 or log_msg("ERROR: Failed to create wsman filter for device $deviceAddress") && return "fail";
       $filter->wql('SELECT DNSCMCName,RACType,ServiceTag,URLString from DCIM_ModularChassisView'); 
            
       ## get the values
       my @res =  enumerateWsman($wsmanClient, $options, $uri, $filter);
       foreach(@res)
       {
           my %myMap= %$_;
           if( exists($myMap{'RACType'} ) && exists($myMap{'DNSCMCName'} ))
           {
               $racType=$myMap{'RACType'};
               $sysName=$myMap{'DNSCMCName'};
               $deviceType = $chassisdevice;
               if( exists($myMap{'ServiceTag'} ) )
               {
                   $serviceTag=$myMap{'ServiceTag'};
               }
               if( exists($myMap{'URLString'} ) )
               {
                   $chassisURL=$myMap{'URLString'};
               }
           }
       }
       if($racType eq "8")
       {
           $deviceType = $cmcM1000edevice;
       }
       elsif($racType eq "18")
       {
           $deviceType = $cmcVRTXdevice;
       }
       elsif($racType eq "19")
       {
           $deviceType = $cmcFX2device;
       }        
        
       log_msg ("INFO: Chassis details SysName: $sysName ,Rac Type: $racType,Servicetag: $serviceTag and Chassis Console URL: $chassisURL for $deviceAddress");
       if($sysName eq "" || $serviceTag eq "" || $racType eq "" || $deviceType eq "")     
       {
           log_msg("ERROR: Failed to retrieve chassis information. Cannot discover $deviceAddress");    
           #Release the wsman context
           $wsmanClient->release($options, $uri, $context) if($context);
           return $error_response;
       }
       $hostName =  $sysName;    
       #Release the wsman context
       $wsmanClient->release($options, $uri, $context) if($context);
   }
   else 
   {
	   log_msg("ERROR: Required perl module openwsman not found.");
	   #print "\nERROR: Required perl module openwsman not found\n";
       return "fail";
   }
}

sub getIPAddFromHostname
{
    my $deviceAddress = shift;
    my $addType = shift;
    my $address;
    my @getaddr;
    my $host;
    if ($addType eq "ipv6")
    {
       if (eval { require  Socket6; 1}) 
       {
          @getaddr = Socket6::getaddrinfo($deviceAddress, 0);
          # Get the pointer to the address itself, different fields in IPv4 and IPv6
          $address = (Socket6::unpack_sockaddr_in6($getaddr[3]))[1];
          $host = Socket6::inet_ntop($getaddr[0], $address);
          $host = new Net::IP ($host);
          $host = $host->ip();
       } 
       else 
       {
          log_msg("ERROR: Required perl module Socket6 not found");
          print "\nERROR: Required perl module Socket6 not found\n";
       }
    } 
    else 
    {
        my @addresses = gethostbyname($deviceAddress);       
        my @ips = map { inet_ntoa($_) } @addresses[4 .. $#addresses];         
        $host = $ips[0];
    }    
    return $host;
}

sub getEqualDetails
{
   my $deviceAddress = shift;
   my $addType = shift;
   my $snmpStat = "true";
   if (eval { require Net::SNMP; 1}) 
   {
       my ($session, $error) = Net::SNMP->session( Hostname  => $deviceAddress,
                                                        Community => $snmpCommunity,
                                                        version   => $snmpParams{'snmp.version'},
                                                        retries   => $snmpParams{'snmp.retries'},
                                                        timeout   => $snmpParams{'snmp.timeout'},
                                                        domain    => $domain,  
                                                        port      => $snmpParams{'snmp.port'} ) 
                                    or log_msg("ERROR: Failed to create session with $deviceAddress .");
       if (!defined($session) || $snmpStat eq "false") 
       {
           log_msg("ERROR: Failed to create SNMP session for the host: $deviceAddress, \n",  $error);     
           $snmpStat = "true";
           return "fail";
       } 
       else
       {
           #get sysName
           #in case of equallogic sysname will be device IP address
           
           my $isIPv6AddressOrHostName = "false";
           $deviceIPfromHostName = getIPAddFromHostname($deviceAddress,$addType);
           log_msg("INFO: Hostname from getIPAddFromHostname: $deviceIPfromHostName");
           my @oids1;
           my @oids2;
           my $tempkey1;
           my $tempkey2;   
           my $response1;  
           $sysName  = $deviceAddress;
           $hostName =  $sysName;      
           if (ip_is_ipv4($deviceIPfromHostName))
           {              
               @oids1 = ($eqlGroupIpOID,$eqlGroupNameOID);
               @oids2 = ($eqlInetAddrEntIfName);  
                            
               $tempkey1 = $eqlGroupIpOID . '.1';
               $tempkey2 = $eqlGroupNameOID . '.1';
               
               $response1 = $session->get_entries(-columns => \@oids1,);
   
               $eqlgroupIP = $response1->{$tempkey1};
               $eqlgroupName = $response1->{$tempkey2};
 
               if ($eqlgroupIP ne "" and $eqlgroupIP eq $deviceIPfromHostName)
               {
                   $deviceType = "equallogicgroup";
                   $serviceTag = "NA";
                   $eqlMemberIndex = "NA";
               }
               elsif ($eqlgroupIP ne "" and $eqlgroupIP ne $deviceIPfromHostName)
               {
                   $deviceType = "equallogicmember";
               }
               else
               {
                   log_msg("ERROR: Failed to retrieve EqualLogic details for $deviceAddress");
                   $session->close;
                   return $error_response;
               }              
           }
           elsif(ip_is_ipv6($deviceIPfromHostName))
           {               
               $isIPv6AddressOrHostName = "true";
               
               @oids1 = ($eqlGroupInet6Addr,$eqlGroupNameOID);
               @oids2 = ($eqlInetAddrEntIfName);
               
               $tempkey1 = $eqlGroupInet6Addr . '.1';
               $tempkey2 = $eqlGroupNameOID . '.1';
               
               $response1 = $session->get_entries(-columns => \@oids1,);
               
               $eqlgroupName = $response1->{$tempkey2};
               
               my $eqlgrpIPWithNoColon = $response1->{$tempkey1};
               
               log_msg("INFO: EqualLogic group IP without colon: $eqlgrpIPWithNoColon");
               #eql eqlInetAddrEntIfName oid gives group ip address without colon value so
               #to compare need to remove colon from device address.
               my @tempArrayIPv6Octet = split ':',  $deviceIPfromHostName;
               my $finalVal;
               foreach my $val (@tempArrayIPv6Octet)
               {
                   $finalVal = join "",$finalVal,$val;
               }
               $finalVal = '0x' . $finalVal;
               #final value received for comparision
               if (lc($eqlgrpIPWithNoColon) eq lc($finalVal))
               {
                   log_msg("INFO: device ip is a group ip for $deviceAddress");
                   $eqlgroupIP = $deviceIPfromHostName;
                   $deviceType = "equallogicgroup";                   
                   $serviceTag = "NA";
                   $eqlMemberIndex = "NA";
               }
               else
               {
                   log_msg("INFO: device ip is a member ip for $deviceAddress");
                   $deviceType = "equallogicmember";
                   $eqlgroupIP = "NA";
               }
           }           
           
           if ($deviceType eq "equallogicmember")
           {
               my $response2 = $session->get_entries(-columns => \@oids2,);
               my $tempdelimeter;
               my @tempArray1;
               my $tempsize;
               if ($isIPv6AddressOrHostName ne "true")
               { 
                   $tempdelimeter  = ".1.4." . $deviceIPfromHostName;
                   foreach my $entry (keys  %{$response2})
                   {
                       if (index($entry,$tempdelimeter) > 0)
                       {
                           @tempArray1 = split $tempdelimeter,$entry;
                           $tempsize = @tempArray1;
                           if ($tempsize == 1)
                           {
                               $tempdelimeter = $eqlInetAddrEntIfName . '.1.';
                               @tempArray1 = split $tempdelimeter,$tempArray1[0];
                               $tempsize = @tempArray1;
                               if ($tempsize == 2)
                               {
                                   $eqlMemberIndex = $tempArray1[1];
                               }
                           }
                       }
                   }
               }
               elsif ($isIPv6AddressOrHostName eq "true")
               {
                   my $ipv6ToHex = getHexStringFromIPv6($deviceIPfromHostName);
                   log_msg("INFO: IPv6 address to hex string value: $ipv6ToHex for $deviceAddress.");
                   foreach my $entry (keys  %{$response2})
                   {
                       $tempdelimeter  = $eqlInetAddrEntIfName . ".1.";
                       @tempArray1 = split $tempdelimeter,$entry;
                       $tempsize = @tempArray1; 
                       if ($tempsize == 2)
                       {
                           $tempdelimeter  = '.2.16' . $ipv6ToHex;
                           @tempArray1 = split $tempdelimeter,$tempArray1[1];
                           $tempsize = @tempArray1;
                           if ((index($tempArray1[0], '.') == -1) && $tempsize == 1)
                           {
                               $eqlMemberIndex = $tempArray1[0];
                               log_msg("INFO: Final response: @tempArray1 and size: $tempsize and member index: $eqlMemberIndex for $deviceAddress");
                               last;
                           }
                       }
                   }
               }
               my $eqlServiceTagOidResponse = $session->get_request("$eqlServiceTagOID") or log_msg ("ERROR: Failed to get serviceTag from $deviceAddress");
               $serviceTag = $eqlServiceTagOidResponse->{"$eqlServiceTagOID"};
           }
           
           if ($sysName eq "" or $deviceType eq "" or $eqlgroupName eq "" or $eqlgroupIP eq "" or $eqlMemberIndex eq "" or $serviceTag eq "" )
           {
              $session->close;
              return $error_response;
           }
           else
           {              
              log_msg("INFO: Retrieved sysName: $sysName ,device type: $deviceType ,groupIP: $eqlgroupIP ,group name : $eqlgroupName ,MemberIndex: $eqlMemberIndex and ,ServiceTag: $serviceTag from $deviceAddress");
           }
           $session->close;
#           my %eqltempHash;
#           if (open my $fh, '<', $eqlfile) 
#           {
#              # open was successful
#              while (my $row = <$fh>)
#              {
#                 $row =~ s/^\s*//;     # Remove spaces at the start of the line
#                 $row =~ s/\s*$//;     # Remove spaces at the end of the line
#                 chomp;
#                 if ( ($row !~ /^#/) && ($row ne "") && ($row ne "/^\s*$/") )
#                 {
#                    $eqltempHash{$row} = "true";
#                 }
#              }
#           }
#           # Use the open() function to create the file.
#           unless(open FILE, ">>$eqlfile") 
#           {
#               log_msg("\nERROR: Unable to write in $eqlfile for $deviceAddress");
#           } 
#           if(($deviceIPfromHostName eq "$eqlgroupIP") and ($deviceType eq "equallogicgroup"))
#           {
#               my $temp = "group#" . $deviceIPfromHostName . "|" . $eqlgroupName;
#               if ($eqltempHash{$temp} ne "true")
#               {
#                   print  FILE "group#$deviceIPfromHostName|$eqlgroupName\n";
#               }
#           }
#           else
#           {
#               my $temp = "member#" . $deviceIPfromHostName . "|" . $eqlgroupIP;
#               if ($eqltempHash{$temp} ne "true")
#               {
#                   print  FILE "member#$deviceIPfromHostName|$eqlgroupIP\n";
#               }
#           }
#           # close the file.
#           close FILE;
        }
    }
    else 
    {
        log_msg("ERROR: Required perl module Net::SNMP not found.");
        print "\nERROR: Required perl module Net::SNMP not found\n";
        return "fail";
    }
}

sub getMdDetails
{
	my $deviceAddress = shift;
	
	if (eval { require Net::SNMP; 1})
	{
		my ($session, $error) = Net::SNMP->session( Hostname  => $deviceAddress,
                                                        Community => $snmpCommunity,
                                                        version   => $snmpParams{'snmp.version'},
                                                        retries   => $snmpParams{'snmp.retries'},
                                                        timeout   => $snmpParams{'snmp.timeout'},
                                                        domain    => $domain,  
                                                        port      => $snmpParams{'snmp.port'} ) 
                                    or log_msg("ERROR: Failed to create session with $deviceAddress .");
									
		if (!defined($session)) 
		{
			log_msg("ERROR: Failed to create SNMP session for the host: $deviceAddress, \n",  $error);     
			return "fail";
		}
		else
		{
		    my $dummySvcTag;
			
			#Get sysName ServiceTag of MD.
			my @oids = ($sysNameOid,$mdServiceTagOID);
			my $response = $session->get_entries(-columns => \@oids,);
			my $tempkey1 = $sysNameOid . '.0';
			my $tempkey2 = $oobServiceTag . '.0';
	   
			foreach my $entry (keys  %{$response})
			{
				if ($entry eq '1.3.6.1.2.1.1.5.0')
				{
					$sysName = $response->{$entry};
				}
				elsif($entry eq '1.3.6.1.4.1.674.10893.2.31.500.1.3.0')
				{
					$dummySvcTag = $response->{$entry};
					my @splitSvcTag = split / /, $dummySvcTag;
					$serviceTag = $splitSvcTag[1];
				}
			}
			if ($sysName eq "" or $serviceTag eq "" )
			{
				$session->close;
				log_msg("ERROR: Failed to retrieve MD information. Cannot discover $deviceAddress");
				return $error_response;
			}
			else
			{
				$deviceType = $mddevice;
				$hostName =  $sysName;
			}
			$session->close;
			log_msg ("INFO: Retrieved sysName: $sysName ,device type: $deviceType and ,ServiceTag: $serviceTag using SNMP protocol for $deviceAddress.");
		}
	}
	else 
	{
		log_msg("ERROR: Required perl module Net::SNMP not found.");
		print "\nERROR: Required perl module Net::SNMP not found\n";
		return "fail";
	}
}

#------------------------------------------------------------------
# This function converts the ipv6 add into hex string
#------------------------------------------------------------------
sub getHexStringFromIPv6
{
   my $ipv6Add = shift;
   my $finalVal;
   my $tempDelimeter = ':';
   my @tempArray = split ($tempDelimeter,$ipv6Add);
   foreach my $val (@tempArray)
   {
       my $res1 = hex substr $val, 0, 2; 
       my $res2 = hex substr $val, 2, 2;
       $finalVal = join '.', $finalVal, $res1, $res2;
   }
   return $finalVal;
}

sub getCompellentDetails
{
    my $deviceIPAddress = shift;
    my $addType = shift;
    my $snmpStat = "true";
    if (eval { require Net::SNMP; 1}) 
    {
       my ($session, $error) = Net::SNMP->session( Hostname  => $deviceIPAddress,
                                                        Community => $snmpCommunity,
                                                        version   => $snmpParams{'snmp.version'},
                                                        retries   => $snmpParams{'snmp.retries'},
                                                        timeout   => $snmpParams{'snmp.timeout'},
                                                        domain    => $domain,  
                                                        port      => $snmpParams{'snmp.port'} ) 
                                    or log_msg("ERROR: Failed to create session with $deviceIPAddress .");
       if (!defined($session) || $snmpStat eq "false") 
       {
           log_msg("ERROR: Failed to create SNMP session for the host: $deviceIPAddress, \n",  $error);     
           $snmpStat = "true";
           $flag_SNMP_fails = "true";
       } 
       else
       {
           #get sysName
           #in case of compellent sysname will be device IP address
           my @oids;
           my $tempMgmtkey;
           my $isIPv6Address = "false";           
           $deviceIPfromHostName = getIPAddFromHostname($deviceIPAddress,$addType);
           if (ip_is_ipv4($deviceIPfromHostName))
           {
               @oids = ($compellentMgmtIPOID,$compellentCtlIPOID, $compellentSvcTagOID);
               #getting the mgmt ip and related details
               $tempMgmtkey = $compellentMgmtIPOID . '.1';
           }
           elsif(ip_is_ipv6($deviceIPfromHostName))
           {
               @oids = ($compellentMgmtIPIPv6OID,$compellentCtlIPIPv6OID, $compellentSvcTagOID);
               #getting the mgmt ip and related details
               $tempMgmtkey = $compellentMgmtIPIPv6OID . '.1';
               $isIPv6Address = "true";
           }
           $sysName  = $deviceIPAddress;
           $hostName =  $sysName;
           log_msg ("INFO: sysName: $sysName and IP address: $deviceIPfromHostName for $deviceIPAddress");   
           
           my $result = $session->get_entries(-columns => \@oids,);
           $session->close;
           
           #getting the mgmt ip and related details
           $compellentMgmtIp = $result->{$tempMgmtkey};
           if ($isIPv6Address eq "true")
           {   #changing the Compellent Management IP into full octect form to get the correct comparision result.
               $compellentMgmtIp = new Net::IP ($compellentMgmtIp);
               $compellentMgmtIp = $compellentMgmtIp->ip();               
           }
           if ($compellentMgmtIp ne "")
           {
               if ($deviceIPfromHostName eq $compellentMgmtIp)
               {
                   $deviceType = $compellentMgmtdevice;
                   $serviceTag = "NA";
                   $compellentCtlIndex = "NA";
                   log_msg ("INFO: $deviceIPAddress is a Compellent Mgmt IP and sysName is: $sysName ");
               }
               else
               {
                   $deviceType = $compellentCtldevice;
                   log_msg ("INFO: $deviceIPAddress is a Compellent Controller IP and sysName is: $sysName ");
               }
           }
           else
           {
               log_msg ("ERROR: Failed to retrieve Compellent Mgmt IP details for $deviceIPAddress.");
               return $error_response;
           }
           my @temp;
           my $tempSize;
           my $tempDelimeter;
           if ($deviceType eq $compellentCtldevice)
           {
               foreach my $entry (keys  %{$result})
               {
                   if (index ($entry,$compellentCtlIPOID) == 0 && $isIPv6Address eq "false")
                   {
                       if ($deviceIPfromHostName eq $result->{$entry})
                       {
                           $tempDelimeter = $compellentCtlIPOID . '.';
                           @temp = split $tempDelimeter,$entry;
                           $tempSize = @temp;
                           if ($tempSize > 1)
                           {
                               $compellentCtlIndex = $temp[1];
                               last;
                           }
                       }
                   }
                   else
                   {
                       if (index ($result->{$entry}, ':') > 0)
                       {   #changing the Compellent  controller IPv6 Address into full octect form to get the correct comparision result.
                           my $tempValue = new Net::IP ($result->{$entry});
                           $tempValue = $tempValue->ip();
                           if ($deviceIPfromHostName eq $tempValue)
                           {
                               $tempDelimeter = $compellentCtlIPIPv6OID . '.';
                               @temp = split $tempDelimeter,$entry;
                               $tempSize = @temp;
                               if ($tempSize > 1)
                               {
                                   $compellentCtlIndex = $temp[1];
                                   last;
                               } 
                           }
                       }                       
                   }
               }
               my $tempkey = $compellentSvcTagOID . "." . $compellentCtlIndex;
               $serviceTag = $result->{$tempkey};
           }
           if ($deviceType ne "" && $serviceTag ne "" && $compellentMgmtIp ne "" && $compellentCtlIndex ne "")
           {               
               log_msg ("INFO: Retrieve Compellent details device type: $deviceType, service tag: $serviceTag, Mgmt IP: $compellentMgmtIp and Ctrl Index: $compellentCtlIndex for $deviceIPAddress.");
               return "success";
           }
           else
           {
               log_msg ("ERROR: Failed to retrieve Compellent details device type: $deviceType, service tag: $serviceTag, Mgmt IP: $compellentMgmtIp and Ctrl Index: $compellentCtlIndex for $deviceIPAddress.");
               return $error_response;
           }
        }
    }
    else 
    {
        log_msg("ERROR: Required perl module Net::SNMP not found.");
        print "\nERROR: Required perl module Net::SNMP not found\n";
        return "fail";
    }
}


#-----------------------------------------------------------------
# Function to process and validate command line arguments
#-----------------------------------------------------------------    
sub processArgs{
    checkArgOccurrence();
    GetOptions(
        'H|hostname=s'       => \$opt{hostname},
        'F|filewithiplist=s' => \$opt{filewithiplist},
        'S|subnet=s'         => \$opt{subnetmask},
        'P|protocol=s'       => \$opt{protocol},
        'h|help'             => \$opt{help},
        'c|configfile=s'     => \$opt{configfile},
        't|template=s'       => \$opt{servicetemplate},
        'f|force'            => \$opt{force},
        'd|detailedservice'  => \$opt{detailedservice},
    ) or do {
        print"ERROR: Invalid command line arguments\n";
        print $HELP;
        exit FAILURE;
    };
    
    # If user requested help
    if ($opt{'help'}) {
            print $HELP;
            exit SUCCESS;
    }

    if (defined $opt{hostname} ) {
        @IpList = $opt{hostname};
    }elsif( defined $opt{subnetmask} ){
        my $ip = new Net::IP ($opt{subnetmask}) ||  log_msg("ERROR: Invalid subnet mask provided. Exiting discovery. ")  &&  print("Invalid subnet mask provided. Exiting discovery. \n")  && exit FAILURE;
        do {
            push(@IpList,$ip->ip());    
        } while (++$ip);
    }elsif( defined $opt{filewithiplist} )  {
        if (! -e $opt{filewithiplist}) {
            log_msg( "ERROR: IP list file $opt{filewithiplist} does not exist. Exiting discovery.");
            print "IP list file $opt{filewithiplist} does not exist. Exiting discovery.\n";
            exit FAILURE;
        }
        @IpList = `cat $opt{filewithiplist}`;
    }else{
        log_msg("ERROR: Invalid arguments. Mandatory arguments -H|--host or -S|--subnetmask or -F|--filewithiplist not provided. Exiting discovery.");
        print "Invalid arguments. Mandatory arguments -H|--host or -S|--subnetmask or -F|--filewithiplist not provided. Exiting discovery.\n";
        print $HELP;
        exit FAILURE;        
    }

    if(( $opt{protocol} != SNMP )  && ($opt{protocol} != WSMAN ) && defined $opt{protocol} )
    {
        log_msg( "ERROR: Invalid protocol specified. Exiting discovery");
        print "Invalid protocol specified. Exiting discovery\n";
        print $HELP;
        exit FAILURE;
    } 
    
    if( $opt{protocol} == WSMAN)
    {
        $communicationProtocol = "wsman";
    }
	else
	{
	    $communicationProtocol = "snmp";
	}

    if (defined $opt{configfile} )
    {
        $dellCommConfigFile = $opt{configfile}
    }
    
    if (defined $opt{servicetemplate} )
    {
        $dellServiceConfigFile = $opt{servicetemplate}
    }
    
    if (!-e $dellCommConfigFile) {
         print "Configuration file $dellCommConfigFile does not exist. Exiting discovery.\n";
         log_msg( "ERROR: Configuration file $dellCommConfigFile does not exist. Exiting discovery.");
        exit $FAILURE;
    } 
    
    if (!-e $dellServiceConfigFile) {
            print "Template file $dellServiceConfigFile does not exist. Exiting discovery.\n";
            log_msg( "ERROR: Template file $dellServiceConfigFile does not exist. Exiting discovery.");
            exit $FAILURE;
        }    
    if (!-e $dellResourceFile) {
            print "Resource file $resourceFile does not exist. Exiting discovery.\n";
            log_msg( "ERROR: Resource file $resourceFile does not exist. Exiting discovery.");
            exit $FAILURE;
      }
    

    ## Read communication configurations based on specified protocol
    #if($communicationProtocol eq "wsman" )
    {
        %wsmanParams = readCommunicationParams($dellCommConfigFile, %wsmanParams);
        $wsmanUser = readConfigFile($dellResourceFile, $wsmanParams{'wsman.username'});
        $wsmanPasswd  = readConfigFile($dellResourceFile, $wsmanParams{'wsman.password'});
        if($wsmanParams{'wsman.port'} < 1 )
        {
            log_msg("ERROR: Wsman port $wsmanParams{'wsman.port'} is not supported.Invalid configuration in the file $dellCommConfigFile. Exiting discovery.");
            print("Invalid configuration. Exiting discovery.\n");
            exit $FAILURE;
        }
    
        if($wsmanParams{'wsman.retries'} < 1 )
        {
            log_msg("WARNING: Wsman retries $wsmanParams{'wsman.retries'} is not supported.Invalid configuration in the file $dellCommConfigFile. Exiting discovery.");
            print("Invalid configuration. Exiting discovery.\n");
            exit $FAILURE;
        }

        if( $wsmanParams{'wsman.timeout'} < 1 )
        {
            log_msg("ERROR: Wsman timeout $wsmanParams{'wsman.timeout'} not supported.Invalid configuration in the file $dellCommConfigFile. Exiting discovery.");
            print("Invalid configuration. Exiting discovery.\n");
            exit $FAILURE;
        }

        if( $wsmanPasswd eq "" )
        {
            log_msg("ERROR: Wsman password is null/empty. Exiting discovery.");
            print("Wsman password is null/empty. Exiting discovery.\n");
            exit $FAILURE;
        }
        if( $wsmanUser eq "" )
        {
            log_msg("ERROR: Wsman user name is null/empty. Exiting discovery.");
            print("Wsman user name is null/empty. Exiting discovery.\n");
            exit $FAILURE;
        }
        $noOfChild = getProcessCount();
        log_msg("INFO: No of process: $noOfChild result of getProcessCount");

    } 
    #elsif($communicationProtocol eq "snmp")
    {
        %snmpParams = readCommunicationParams($dellCommConfigFile, %snmpParams);
            $snmpCommunity = readConfigFile($dellResourceFile, $snmpParams{'snmp.community'});
        if (($snmpParams{'snmp.version'} != 1 ) && ( $snmpParams{'snmp.version'}!=  2 ))
        {
              log_msg("ERROR: Snmp version $snmpParams{'snmp.version'} not supported. Exiting discovery.");
            print("Snmp version $snmpParams{'snmp.version'} not supported. Exiting discovery.\n");
            exit $FAILURE;
        }
               
        if($snmpParams{'snmp.port'} < 1 )
        {
            log_msg("ERROR: Snmp port $snmpParams{'snmp.port'} is not supported. Exiting discovery.");
            print("Snmp port $snmpParams{'snmp.port'} is not supported. Exiting discovery.\n");
            exit $FAILURE;
        }

        if($snmpParams{'snmp.retries'}  < 1){
               log_msg("ERROR: Snmp retries $snmpParams{'snmp.retries'} not supported. Exiting discovery.");
            print("Snmp retries $snmpParams{'snmp.retries'} not supported. Exiting discovery.\n");
            exit $FAILURE;
        }

        if( $snmpParams{'snmp.timeout'} < 1 )
        {
            log_msg("ERROR: Snmp timeout $snmpParams{'snmp.timeout'} not supported. Exiting discovery.");
            print("Snmp timeout $snmpParams{'snmp.timeout'} not supported. Exiting discovery.\n");
            exit $FAILURE;
        }
        
        if( $snmpCommunity eq "" )
            {
                    log_msg("ERROR: Snmp community  string is null/empty. Exiting discovery.");
                    print("Snmp community  string is null/empty. Exiting discovery.\n");
                    exit $FAILURE;
        }
    }
    
    if($opt{force})
    {
        $fileWriteEnable = "y";
    }

    if($opt{detailedservice})
    {
        $serviceOption = "all";
    }
}

sub getProcessCount
{
    #read dell_pluginconfig.cfg file
    my $process_count = 0;
    $process_count = readConfigFile ("$dell_pluginconfigFile", "process.count" );
    log_msg("INFO: configured value for process.count = $process_count");
    if ($process_count =~ /^\d+?$/)
    {
        if ($process_count <= 0)
        {
            $process_count = $default_no_process;
            log_msg("INFO: configured value for process.count is invalid numeric value, set to default $process_count");
        }
    }
    else
    {
        log_msg("INFO: configured value for process.count is invalid value, set to default $process_count");
        $process_count = $default_no_process;
    }
    return $process_count;
}

sub checkModule
{
	if ( !(eval { require Net::SNMP; 1}) )
	{
	    if( $communicationProtocol eq "snmp" )
		{
	        print "\nERROR: Required perl module Net::SNMP not found. iDRAC and storage devices will not be discovered.\n";
			log_msg("ERROR: Required perl module Net::SNMP not found. iDRAC and storage devices will not be discovered.");
		}
		else
		{
			print "\nERROR: Required perl module Net::SNMP not found. Storage devices will not be discovered.\n";
			log_msg("ERROR: Required perl module Net::SNMP not found. Storage devices will not be discovered.");
		}
	}

	if ( !(eval { require openwsman; 1}) ) 
	{
	    if( $communicationProtocol eq "wsman" )
		{
	        print "\nERROR: Required perl module openwsman not found. iDRAC and Chassis devices will not be discovered.\n";
			log_msg("ERROR: Required perl module openwsman not found. iDRAC and Chassis devices will not be discovered.");
		}
		else
		{
			print "\nERROR: Required perl module openwsman not found. Chassis devices will not be discovered.\n";
			log_msg("ERROR: Required perl module openwsman not found. Chassis devices will not be discovered.");
		}
	}
}


#-----------------------------------------------------------------
# Simple log-writing method
#-----------------------------------------------------------------
sub log_msg
{
    my $message = shift;
    my $tm = localtime(time);
    #time in following format : 2013-01-16 18:57:37:
    my $current_time = sprintf '%d-%02d-%02d %02d:%02d:%02d ', $tm->year + 1900, $tm->mon+1, $tm->mday, $tm->hour , $tm->min , $tm->sec;
    my $myProtocol = uc($communicationProtocol);    
    eval
    {
        $message = $current_time . LOGMODULE." $$: " .$message . "\n";
        if ($opt_log)
        {
            open(FILE,">>$opt_logfile") or print "Could not open data file ($opt_logfile) for writing: $!";
            print FILE "$message" or warn "Error writing $message to $opt_logfile: $!";
            close FILE or print "Error closing $opt_logfile: $!";
        }
        
    };

    if ($@)
    {
                warn "Error: $@\n";
    }

    return 1;
}



#-----------------------------------------------------------------
# Function to read config file for single attribute
#-----------------------------------------------------------------

sub readConfigFile {
    my ($file, $configParamName) = @_;
    my $readLine;
    my $name; 
    our $value;       
    if  (-e $file)
    {
    open (CONFIG, "<", "$file");
        while (<CONFIG>) {
            $readLine=$_;
            chop ($readLine);          # Remove trailling \n
            $readLine =~ s/^\s*//;     # Remove spaces at the start of the line
            $readLine =~ s/\s*$//;     # Remove spaces at the end of the line
            if ( ($readLine !~ /^#/) && ($readLine ne "") ){    # Ignore lines starting with # and blank lines
                    ($name, $value) = split (/=/, $readLine);          # Split each line into name value pairs
                    $value =~ s/^\s*//;     # Remove spaces at the start of the line
                    $value =~ s/\s*$//;
            $name =~ s/^\s*//;
            $name =~ s/\s*$//;    
            if ( $name eq $configParamName && $value ne "" ){
                return $value;
            }
            }
        }
        close(CONFIG);
    } 
    else 
    {
    log_msg("ERROR: File $file doesn't exist \n");
    }
   return; 
}


#-----------------------------------------------------------------
# Function to read config file for set of attributes
#-----------------------------------------------------------------
sub readCommunicationParams {
    my $file = shift;
    my %myHash = @_;
    my $readLine;
    my $name;
    my $value;
    if  (-e $file)
    {
        open (CONFIG, "<", "$file");
        while (<CONFIG>) {
            $readLine=$_;
            chop ($readLine);          # Remove trailling \n
            $readLine =~ s/^\s*//;     # Remove spaces at the start of the line
            $readLine =~ s/\s*$//;     # Remove spaces at the end of the line
            if ( ($readLine !~ /^#/) && ($readLine ne "") ){    # Ignore lines starting with # and blank lines
                ($name, $value) = split (/=/, $readLine);          # Split each line into name value pairs
                $value =~ s/^\s*//;     # Remove spaces at the start of the line
                $value =~ s/\s*$//;
                $name =~ s/^\s*//;
                $name =~ s/\s*$//;
                $name = lc($name);
                while( my($hashKey, $hashValue ) = each %myHash ){
                    if($hashKey eq $name && $value ne "" ){
                        $myHash{$hashKey}= $value;
                    }
                }
            }
        }
        close(CONFIG);
    }
    else
    {
        log_msg("ERROR: File $file doesn't exist.");
    }
    return %myHash;
}


sub enumerateWsman{
    my ( $myClient, $myOptions, $myUri, $myFilter) = @_;
    my $count = 0;
    my $test_flag = 1;
    my $myResult = undef ; 
    
    # Force basic auth.
    $myClient->transport()->set_auth_method($openwsman::BASIC_AUTH_STR);
    $myClient->transport()->set_timeout($wsmanParams{'wsman.timeout'});
    openwsman::wsman_transport_set_verify_peer($myClient, 0);
    openwsman::wsman_transport_set_verify_host($myClient, 0);
       
    $myOptions->set_flags($openwsman::FLAG_ENUMERATION_OPTIMIZATION);
    $myOptions->set_max_elements($max_elements);
    
    for ($count = 0; (($count < ($wsmanParams{'wsman.retries'} + 1)) and ($test_flag == 1)) ; $count = $count + 1){
        $myResult = $myClient->enumerate($myOptions, $myFilter, $myUri);
        unless($myResult && $myResult->is_fault eq 0) {
            $test_flag = 1; 
            next;
        }
        $test_flag = 0;
    }
    if($test_flag  == 1){
            log_msg("ERROR: Failed to enumerate $myUri. $myResult->fault->reason");
        return ;
    }
        
    my $nodes = undef;
    if(defined $myResult->body() )
    {
        if(defined  $myResult->body()->find(undef, "Items"))
        {
            $nodes = $myResult->body()->find(undef, "Items")->child();
        }
    }        
    # Get items.
    my $items;
    if(defined $nodes)
    {
        for((my $cnt = 0) ; ($cnt<$nodes->size()) ; ($cnt++)) {
            $items->{$nodes->get($cnt)->name()} = $nodes->get($cnt)->text();
        }
    }    
    push @list, $items;

    return @list;
}

#---------------------------------------------------------------------
# Function to read service name and provides the device name
#---------------------------------------------------------------------
sub getdevicetype
{   
   my $linefromfile = shift; 
   my %deviceTypeFromService = (
        'dellemcserverinformation'                         => 'idrac',
        'dellemcserveroverallhealthstatus'                 => 'idrac',
        'dellemcservertraps'                               => 'idrac',
        'dellemcserverphysicaldiskstatus'                  => 'idrac',
        'dellemcserverbatterystatus'                       => 'idrac',
        'dellemcserverfanstatus'                           => 'idrac',
        'dellemcserverintrusionstatus'                     => 'idrac',
        'dellemcservervirtualdiskstatus'                   => 'idrac',
        'dellemcservernetworkdevicestatus'                 => 'idrac',
        'dellemcservercpustatus'                           => 'idrac',
        'dellemcserverpowersupplystatus'                   => 'idrac',
		'dellemcservermemorystatus'                        => 'idrac',
        'dellemcservertemperatureprobestatus'              => 'idrac',
        'dellemcservervoltageprobestatus'                  => 'idrac',
        'dellemcserveramperageprobestatus'                 => 'idrac',
        'dellemcservercontrollerstatus'                    => 'idrac',
        'dellemcserversdcardstatus'                        => 'idrac',
        'dellemcserverfcnicstatus'                         => 'idrac',
		'dellemcserverwarrantyinformation'                 => 'idrac',
        'dellemcchassisinformation'                        => 'chassis',
        'dellemcchassisoverallhealthstatus'                => 'chassis',
        'dellemcchassistraps'                              => 'chassis',
        'dellemcchassispowersupplystatus'                  => 'chassis',
        'dellemcchassisfanstatus'                          => 'chassis',
        'dellemcchassisi/omodulestatus'                    => 'chassis',
        'dellemcchassisslotinformation'                    => 'chassis',
        'dellemcchassiskvmstatus'                          => 'chassis',
		'dellemcchassiswarrantyinformation'                => 'chassis',
        'dellemcchassisenclosurestatus'                    => 'vrtx',
        'dellemcchassiscontrollerstatus'                   => 'vrtx',
        'dellemcchassisphysicaldiskstatus'                 => 'vrtx',
        'dellemcchassisvirtualdiskstatus'                  => 'vrtx',
        'dellemcchassispciedevicesstatus'                  => 'vrtxfx2',
        'dellemcstorageps-seriesmemberinformation'        => 'equallogicmember',
        'dellemcstorageps-seriesmemberoverallhealthstatus'      => 'equallogicmember',
        'dellemcstorageps-seriesmembertraps'              => 'equallogicmember',
        'dellemcstorageps-seriesmemberphysicaldiskstatus' => 'equallogicmember',
		'dellemcstorageps-seriesmemberwarrantyinformation' => 'equallogicmember',
        'dellemcstorageps-seriesgroupinformation'         => 'equallogicgroup',
        'dellemcstorageps-seriesgroupvolumestatus'        => 'equallogicgroup',
        'dellemcstorageps-seriesgroupstoragepoolinformation'   => 'equallogicgroup',
        'dellemcstorageps-seriesgrouptraps'              => 'equallogicgroup',
        'dellemcstoragesc-seriesinformation'              => 'compellentmanagement',
        'dellemcstoragesc-seriesoverallhealthstatus'            => 'compellentmanagement',
        'dellemcstoragesc-seriesmanagementtraps'          => 'compellentmanagement',
        'dellemcstoragesc-seriesphysicaldiskstatus'       => 'compellentmanagement',
        'dellemcstoragesc-seriesvolumestatus'             => 'compellentmanagement',
        'dellemcstoragesc-seriescontrollerinformation'    => 'compellentcontroller',
        'dellemcstoragesc-seriescontrolleroverallhealthstatus'  => 'compellentcontroller',
        'dellemcstoragesc-seriescontrollertraps'          => 'compellentcontroller',
		'dellemcstoragesc-seriescontrollerwarrantyinformation'  => 'compellentcontroller',
        'dellemcstoragemd-seriesinformation'            => 'md',
        'dellemcstoragemd-seriesoverallhealthstatus'          => 'md',
        'dellemcstoragemd-seriestraps'                  => 'md',
		'dellemcstoragemd-serieswarrantyinformation'    => 'md',
    );

    my $device = $deviceTypeFromService{$linefromfile};
    return $device;
}

#---------------------------------------------------------------------
# Function to read service template config file for available services
#---------------------------------------------------------------------
sub readServiceConfigurationNew {
    my $file              = shift;
    my $protocolSelected  = shift;
    my $monitoringType    = shift;
    my %myHash            = @_;
    my %returnHash;
    my $deviceType        = "";
    my $protocol          = "";   
    my $servicename       = "";   
    log_msg("INFO: Protocol Selected: $protocolSelected and Monitoring Type: $monitoringType");
    my $readLine;
    if  (-e $file)
    {
        open (CONFIG, "<", "$file");
        while (<CONFIG>) 
        {
            $readLine=$_;
            chop ($readLine);          # Remove trailling \n
            $readLine =~s/\s//g;
            if ( ($readLine !~ /^#/) && ($readLine ne "") )
            {   # Ignore lines starting with # and blank lines
                $readLine = lc($readLine);
                $deviceType = getdevicetype($readLine);
                #log_msg("INFO:Device Type: $deviceType from getdevicetype");
                if ($monitoringType eq "basic")
                {
                    if ($deviceType eq "idrac" && $protocolSelected eq "snmp")
                    {
                        my $key = $deviceType . "." . $protocolSelected;
                        if (defined ($delldevicebasic{$key}{$readLine}))
                        {
                            #log_msg("INFO: Key : $key and Value: $delldevicebasic{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicebasic{$key}{$readLine};
                            $idracsnmpdefinedservice{$readLine} = $delldevicebasic{$key}{$readLine};
                        }
                    }
                    elsif($deviceType eq "idrac" && $protocolSelected eq "wsman")
                    {
                        my $key = $deviceType . "." . $protocolSelected;
                        if (defined ($delldevicebasic{$key}{$readLine}))
                        {
                            #log_msg("INFO: Key : $key and Value: $delldevicebasic{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicebasic{$key}{$readLine};
                            $idracwsmandefinedservice{$readLine} = $delldevicebasic{$key}{$readLine};
                        }
                    }                
                    elsif($deviceType eq "chassis")
                    {
                        my $key = $deviceType . ".wsman";
                        if (defined ($delldevicebasic{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicebasic{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicebasic{$key}{$readLine};
                            $chassisdefinedservice{$readLine} = $delldevicebasic{$key}{$readLine};
                        }
                    }
                    elsif($deviceType eq "equallogicmember")
                    {
                        my $key = $deviceType . "." . "snmp";
                        if (defined ($delldevicebasic{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicebasic{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicebasic{$key}{$readLine};
                            $eqlmemdefinedservice{$readLine} = $delldevicebasic{$key}{$readLine};
                        }
                    }
                    elsif($deviceType eq "equallogicgroup")
                    {
                        my $key = $deviceType . "." . "snmp";
                        if (defined ($delldevicebasic{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicebasic{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicebasic{$key}{$readLine};
                            $eqlgrpdefinedservice{$readLine} = $delldevicebasic{$key}{$readLine};
                        }
                    }
                    elsif($deviceType eq "compellentmanagement")
                    {
                        my $key = $deviceType . "." . "snmp";
                        if (defined ($delldevicebasic{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicebasic{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicebasic{$key}{$readLine};
                           $compelmgmtdefinedservice{$readLine} = $delldevicebasic{$key}{$readLine};
                        }
                    }
                    elsif($deviceType eq "compellentcontroller")
                    {
                        my $key = $deviceType . "." . "snmp";
                        if (defined ($delldevicebasic{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicebasic{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicebasic{$key}{$readLine};
                            $compelctrldefinedservice{$readLine} = $delldevicebasic{$key}{$readLine};
                        }
                    }
                    elsif($deviceType eq "md")
                    {
                        my $key = $deviceType . "." . "snmp";
                        if (defined ($delldevicebasic{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicebasic{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicebasic{$key}{$readLine};
                            $mddefinedservice{$readLine} = $delldevicebasic{$key}{$readLine};
                        }
                    }
                }
                if ($monitoringType eq "all")
                {
                    if ($deviceType eq "idrac" && $protocolSelected eq "snmp")
                    {
                        my $key = $deviceType . "." . $protocolSelected;
                        if (defined ($delldevicedet{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicedet{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicedet{$key}{$readLine};
                            $idracsnmpdefinedservice{$readLine} = $delldevicedet{$key}{$readLine};
                        }
                    }
                    elsif($deviceType eq "idrac" && $protocolSelected eq "wsman")
                    {
                        my $key = $deviceType . "." . $protocolSelected;
                        if (defined ($delldevicedet{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicedet{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicedet{$key}{$readLine};
                            $idracwsmandefinedservice{$readLine} = $delldevicedet{$key}{$readLine};
                        }
                    }                
                    elsif($deviceType eq "chassis")
                    {
                        my $key = $deviceType . ".wsman";
                        if (defined ($delldevicedet{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicedet{$key}{$readLine}");
                            $chassisdefinedservice{$readLine} = $delldevicedet{$key}{$readLine};                          
                            $vrtxdefinedservice{$readLine} = $delldevicedet{$key}{$readLine};
                            $returnHash{$readLine} = $delldevicedet{$key}{$readLine};
                        }
                    }
                    elsif($deviceType eq "vrtx")
                    {
                        my $key = $deviceType . ".wsman";
                        if (defined ($delldevicedet{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicedet{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicedet{$key}{$readLine};
                            $vrtxdefinedservice{$readLine} = $delldevicedet{$key}{$readLine};
                        }
                    }
                    elsif($deviceType eq "vrtxfx2")
                    {
                        my $key = $deviceType . ".wsman";
                        if (defined ($delldevicedet{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicedet{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicedet{$key}{$readLine};
                            $vrtxfx2definedservice{$readLine} = $delldevicedet{$key}{$readLine};
                        }
                    }                    
                    elsif($deviceType eq "equallogicmember")
                    {
                        my $key = $deviceType . "." . "snmp";
                        if (defined ($delldevicedet{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicedet{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicedet{$key}{$readLine};
                            $eqlmemdefinedservice{$readLine} = $delldevicedet{$key}{$readLine};
                        }
                    }
                    elsif($deviceType eq "equallogicgroup")
                    {
                        my $key = $deviceType . "." . "snmp";
                        if (defined ($delldevicedet{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicedet{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicedet{$key}{$readLine};
                            $eqlgrpdefinedservice{$readLine} = $delldevicedet{$key}{$readLine};
                        }
                    }
                    elsif($deviceType eq "compellentmanagement")
                    {
                        my $key = $deviceType . "." . "snmp";
                        if (defined ($delldevicedet{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicedet{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicedet{$key}{$readLine};
                            $compelmgmtdefinedservice{$readLine} = $delldevicedet{$key}{$readLine};
                        }
                    }
                    elsif($deviceType eq "compellentcontroller")
                    {
                        my $key = $deviceType . "." . "snmp";
                        if (defined ($delldevicedet{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicedet{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicedet{$key}{$readLine};
                            $compelctrldefinedservice{$readLine} = $delldevicedet{$key}{$readLine};
                        }
                    }
                    elsif($deviceType eq "md")
                    {
                        my $key = $deviceType . "." . "snmp";
                        if (defined ($delldevicedet{$key}{$readLine}))
                        {
                            #log_msg("INFO:Key : $key and Value: $delldevicedet{$key}{$readLine}");
                            $returnHash{$readLine} = $delldevicedet{$key}{$readLine};
                            $mddefinedservice{$readLine} = $delldevicedet{$key}{$readLine};
                        }
                    }                
                }
            }
        }
        close(CONFIG);
    }
    else
    {
        print("ERROR: File $file doesn't exist.\n");
		log_msg("ERROR: File $file doesn't exist. ");
    }
    return %returnHash;
}

#-----------------------------------------------------------------
# Validate the argument occurrence
#-----------------------------------------------------------------
sub checkArgOccurrence
{
    
    my $arg_count = $#ARGV + 1;
    my %argHash ;
    my @dup_argList = ();
    my $dup_counter = 0;
    my $option_counter = 0;
    foreach $argnum (0 .. $#ARGV) 
    {
        if ($argHash{$ARGV[$argnum]}++)
        {
            $dup_argList[$dup_counter++] = $ARGV[$argnum];
        }
        if ($ARGV[$argnum] eq '-H' | $ARGV[$argnum] eq '-S' | $ARGV[$argnum] eq '-F')
        {
            $option_counter ++;        
        }
    }
    if ($option_counter > 1)
    {            
        print "Use -H or -S or -F alone, do not use any combination for providing IP address. \n";        
        log_msg("INFO: Use -H or -S or -F alone, do not use any combination for providing IP address. \n");
        exit $FAILURE;
    }
    if ($dup_counter > 0)
    {
        print "Duplicate arguments @dup_argList provided.\n"; 
        log_msg("ERROR: Duplicate arguments @dup_argList provided.\n");
        exit $FAILURE
    }       
}

