#! /usr/bin/perl

##########################################################################
#Title:         Dell Device Plugin Script
#Version:       2.0 
#Creation Date: 20th May 2015
#Description:   This script provides Dell Compellent information, health 
#               and component health. 
#
#Copyright (c) 2015 Dell Inc.
#All Rights Reserved.
##########################################################################

use Getopt::Long qw(:config no_ignore_case);
use Time::localtime;
use File::Spec;

# Global (package) variables used throughout the code
use vars qw($OK $WARNING $CRITICAL $UNKNOWN $HELP 
            $snmp_session $snmp_error $nextline 
            %opt %Nagios_ExitStatus_String_mapping  %snmp_status 
    );

our $plugin_timeout = 15;
our $printmsg = "";
our $final_exit_code = undef;
our $ctl_idx = "NA";
our $isIpv4_ctl = "Y";

#Exit Codes
$OK       = 0;
$WARNING  = 1;
$CRITICAL = 2;
$UNKNOWN  = 3;



# Error Code for Nagios Number to String 
%Nagios_ExitStatus_String_mapping = (
    $OK         => 'OK',
    $WARNING    => 'WARNING',
    $CRITICAL   => 'CRITICAL',
    $UNKNOWN    => 'UNKNOWN',
);

# Error Code for Nagios Number to String 
%Nagios_String_ExitStatus_mapping = (
    'OK' 	   => $OK,
    'WARNING'  => $WARNING,
    'CRITICAL' => $CRITICAL,
    'UNKNOWN'  =>  $UNKNOWN,
);


# SNMP status from dell agents
%snmp_status = (
    1 => $CRITICAL,
    2 => $CRITICAL,
    3 => $OK,
    4 => $WARNING,
    5 => $CRITICAL,
    6 => $CRITICAL,
);

############################################################
# Dell Compellent Managemenet Information
############################################################

#Compellent Managemenet inventory OIDs and corresponding display names
our %compellent_tabular_info_oid = (
		'1.3.6.1.4.1.674.11000.2000.500.1.2.29.1.4' => 'Name',
		'1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.4' => 'Controller Names',
		'1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.5' => 'Controller IPs',
		'1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.10' => 'Controller IPv6',
		'1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.7' => 'Controller Models',
		'1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.8' => 'Controller ServiceTags',
		'1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.12'=> 'Controller Leader',
    );

our %compellent_scalar_info_oid = (
		'1.3.6.1.4.1.674.11000.2000.500.1.2.4' => 'Version',
		'1.3.6.1.4.1.674.11000.2000.500.1.2.8' => 'Compellent URL',
    );
	
#############################################################
#  Dell Compellent Global Health Status
############################################################
our %mngghs_details_oid = (
        '1.3.6.1.4.1.674.11000.2000.500.1.2.6' => 'Overall Storage Center',
    );
	
our %ctlghs_details_oid = (
        '1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.3' => 'Overall Controller',
    );

our %complete_mngghs = (
        'oid'           => \%mngghs_details_oid,
    );
	
our %complete_ctlghs = (
        'oid'           => \%ctlghs_details_oid,
    );
	
	
our %mngghs_mapping = (
		1	=> 'CRITICAL',
		2	=> 'CRITICAL',
		3	=> 'OK',
		4  	=> 'WARNING',
		5	=> 'CRITICAL',
		6   => 'CRITICAL',
	);	

our %ctlghs_mapping = (
		1 => 'OK',
		2 => 'CRITICAL',
		3 => 'WARNING',
	);
	
#############################################################
#  Dell Compellent Management Physical Disk Status
############################################################
our %mngpd_details_oid = (
        '1.3.6.1.4.1.674.11000.2000.500.1.2.14.1.3'  => 'Status',
		'1.3.6.1.4.1.674.11000.2000.500.1.2.14.1.4'  => 'Name',
		'1.3.6.1.4.1.674.11000.2000.500.1.2.14.1.11' => 'DiskEnclosureNumber',
		'1.3.6.1.4.1.674.11000.2000.500.1.2.14.1.9'  => 'TotalSize(GB)',
		'1.3.6.1.4.1.674.11000.2000.500.1.2.14.1.10' => 'BusType',
    );
	

our %bustype_map = (
		1 => 'fibrechannel',
		2 => 'iscsi',
		3 => 'fibrechanneloverethernet',
		4 => 'sas',
		5 => 'unknown',
    ); 

our %mngpd_enums = (
        'BusType'         => \%bustype_map,
    );

our %complete_mngpd = (
        'oid'           => \%mngpd_details_oid,
		'enums'         => \%mngpd_enums,
    );
	


#############################################################
#  Dell Compellent Management Volume Status
############################################################
our %mngvol_details_oid = (
        '1.3.6.1.4.1.674.11000.2000.500.1.2.26.1.3'  => 'Status',
		'1.3.6.1.4.1.674.11000.2000.500.1.2.26.1.4'  => 'VolumeName',
    );


our %complete_mngvol = (
        'oid'           => \%mngvol_details_oid,
		'enums'         => undef,
    );
	
##################################################################
# Func:         get_compellent_info
# Output:       Compellent Basic detail.
# Description:  Main function which is getting detail of Compellent 
#				Basic detail.
##################################################################

sub get_compellent_info {

    snmp_initialize();
	my $finalString  = undef;
    my $primCtlIndex = "1";
	my $secCtlIndex = "2";
	    
    my  $result = $snmp_session->get_entries(-columns => [keys %compellent_tabular_info_oid]);
	
	if (!defined $result ) {
        log_msg("ERROR: $snmp_session->error\n");
    }
	
	my  $scalarresult = $snmp_session->get_entries(-columns => [keys %compellent_scalar_info_oid]);
	
	if (!defined $scalarresult ) {
        log_msg("ERROR: $snmp_session->error\n");
    }

	
    if (!defined $result  and !defined $scalarresult) {
        printf "ERROR: Failed to establish SNMP session.";
        log_msg("ERROR: $snmp_session->error\n");
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
        exit $UNKNOWN;
    } else {
        my $tempoid = undef;
        my $flag = 0;
		my $index;
        log_msg("INFO: Success in getting value from Dell agent.\n");
	
		# Get Leader/Primary Controller index
		foreach my $resultoid ( keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
				
			if (( index(($tempoid), ("1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.12.")) == 0) && ( length($result->{$resultoid}) == 0 ) ){
			
				if (( $result->{$resultoid}) == "1") {
					$primCtlIndex = substr ($tempoid, length("1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.12."), length($tempoid) ) ;
					delete $result->{$resultoid};
				} 
				
				if (($result->{$resultoid}) == "2"){
					$secCtlIndex = substr ($tempoid, length("1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.12."), length($tempoid) ) ;
					delete $result->{$resultoid};
					}
				}
		}

		if($ctl_idx ne "NA") {
				
				foreach my $resultoid (keys %{$result}) {
				$tempoid = $resultoid;
				$tempoid =~ s/^\s+|\s+$//g;
				if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.4.".$ctl_idx) && (length($result->{$resultoid}) != 0 )){
						$finalString =  $finalString . "Controller Name = $result->{$resultoid}$nextline";
						delete $result->{$resultoid};
						$flag = 1;
						last;
					}
				}
					if ($flag != 1) {
						$finalString = $finalString .  "Controller Name = Not Available$nextline";
					   }
					$flag = 0;
					
				foreach my $resultoid (keys %{$result}) {
				$tempoid = $resultoid;
				$tempoid =~ s/^\s+|\s+$//g;
				if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.7.".$ctl_idx) && (length($result->{$resultoid}) != 0 )){
						$finalString =  $finalString . "Model Name = $result->{$resultoid}$nextline";
						delete $result->{$resultoid};
						$flag = 1;
						last;
					}
				}
					if ($flag != 1) {
						$finalString = $finalString .  "Model Name = Not Available$nextline";
					   }
					$flag = 0;
					
				foreach my $resultoid (keys %{$result}) {
				$tempoid = $resultoid;
				$tempoid =~ s/^\s+|\s+$//g;
				if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.8.".$ctl_idx) && (length($result->{$resultoid}) != 0 )){
						$finalString =  $finalString . "Service Tag = $result->{$resultoid}$nextline";
						delete $result->{$resultoid};
						$flag = 1;
						last;
					}
				}
					if ($flag != 1) {
						$finalString = $finalString .  "Service Tag = Not Available$nextline";
					   }
					$flag = 0;
										
				foreach my $resultoid (keys %{$scalarresult}) {
				$tempoid = $resultoid;
				$tempoid =~ s/^\s+|\s+$//g;
				if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.8.0") && (length($scalarresult->{$resultoid}) != 0 )){
						$finalString =  $finalString . "Compellent URL = $scalarresult->{$resultoid}$nextline";
						delete $scalarresult->{$resultoid};
						$flag = 1;
						last;
					}
				}
					if ($flag != 1) {
						$finalString = $finalString .  "Compellent URL = Not Available$nextline";
					   }
					$flag = 0;
				
				if($ctl_idx eq $primCtlIndex){
						$finalString =  $finalString . "Primary Controller = Yes";
					} else {
						$finalString =  $finalString . "Primary Controller = No";
					}
			} else {
				foreach my $resultoid (keys %{$result}) {
				$tempoid = $resultoid;
				$tempoid =~ s/^\s+|\s+$//g;
				if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.29.1.4.1") && (length($result->{$resultoid}) != 0 )){
						$finalString =  $finalString . "Storage Name = $result->{$resultoid}$nextline";
						delete $result->{$resultoid};
						$flag = 1;
						last;
					}
				} if ($flag != 1) {
						$finalString = $finalString .  "Storage Name = Not Available$nextline";
					   }
					$flag = 0;
					
					foreach my $resultoid (keys %{$scalarresult}) {
						$tempoid = $resultoid;
						$tempoid =~ s/^\s+|\s+$//g;
						if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.4.0") && (length($scalarresult->{$resultoid}) != 0 )){
							$finalString =  $finalString . "Firmware Version = $scalarresult->{$resultoid}$nextline";
							delete $scalarresult->{$resultoid};
							$flag = 1;
							last;
						}
					}
					if ($flag != 1) {
						$finalString = $finalString .  "Firmware Version = Not Available$nextline";
					   }
					$flag = 0;
									
					foreach my $resultoid (keys %{$result}) {
						$tempoid = $resultoid;
						$tempoid =~ s/^\s+|\s+$//g;
						if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.4.".$primCtlIndex) && (length($result->{$resultoid}) != 0 )){
							$finalString =  $finalString . "Primary Controller Name = $result->{$resultoid}$nextline";
							delete $result->{$resultoid};
							$flag = 1;
							last;
						}
					}
					if ($flag != 1) {
						$finalString = $finalString .  "Primary Controller Name = Not Available$nextline";
					   }
					$flag = 0;
					
					foreach my $resultoid (keys %{$result}) {
						$tempoid = $resultoid;
						$tempoid =~ s/^\s+|\s+$//g;
						if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.7.".$primCtlIndex) && (length($result->{$resultoid}) != 0 )){
							$finalString =  $finalString . "Primary Controller Model = $result->{$resultoid}$nextline";
							delete $result->{$resultoid};
							$flag = 1;
							last;
						}
					}
					if ($flag != 1) {
						$finalString = $finalString .  "Primary Controller Model = Not Available$nextline";
					   }
					$flag = 0;
					
					
					foreach my $resultoid (keys %{$result}) {
						$tempoid = $resultoid;
						$tempoid =~ s/^\s+|\s+$//g;
						if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.8.".$primCtlIndex) && (length($result->{$resultoid}) != 0 )){
							$finalString =  $finalString . "Primary Controller Service Tag = $result->{$resultoid}$nextline";
							delete $result->{$resultoid};
							$flag = 1;
							last;
						}
					}
					if ($flag != 1) {
						$finalString = $finalString .  "Primary Controller Service Tag = Not Available$nextline";
					   }
					$flag = 0;
					
					foreach my $resultoid (keys %{$result}) {
						$tempoid = $resultoid;
						$tempoid =~ s/^\s+|\s+$//g;
						
						if( $isIpv4_ctl eq "Y" )
						{
							if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.5.".$primCtlIndex) && (length($result->{$resultoid}) != 0 )){
								$finalString =  $finalString . "Primary Controller IP = $result->{$resultoid}$nextline";
								delete $result->{$resultoid};
								$flag = 1;
								last;
							}
						}
						else
						{
							if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.10.".$primCtlIndex) && (length($result->{$resultoid}) != 0 )){
								$finalString =  $finalString . "Primary Controller IP = $result->{$resultoid}$nextline";
								delete $result->{$resultoid};
								$flag = 1;
								last;
							}
						}
					}
					if ($flag != 1) {
						$finalString = $finalString .  "Primary Controller IP = Not Available$nextline";
					   }
					$flag = 0;
					

										

					
					foreach my $resultoid (keys %{$result}) {
						$tempoid = $resultoid;
						$tempoid =~ s/^\s+|\s+$//g;
						if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.4.".$secCtlIndex) && (length($result->{$resultoid}) != 0 )){
							$finalString =  $finalString . "Secondary Controller Name = $result->{$resultoid}$nextline";
							delete $result->{$resultoid};
							$flag = 1;
							last;
						}
					}
					if ($flag != 1) {
						$finalString = $finalString .  "Secondary Controller Name = Not Available$nextline";
					   }
					$flag = 0;
					
					foreach my $resultoid (keys %{$result}) {
						$tempoid = $resultoid;
						$tempoid =~ s/^\s+|\s+$//g;
						if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.7.".$secCtlIndex) && (length($result->{$resultoid}) != 0 )){
							$finalString =  $finalString . "Secondary Controller Model = $result->{$resultoid}$nextline";
							delete $result->{$resultoid};
							$flag = 1;
							last;
						}
					}
					if ($flag != 1) {
						$finalString = $finalString .  "Secondary Controller Model = Not Available$nextline";
					   }
					$flag = 0;
					
					
					foreach my $resultoid (keys %{$result}) {
						$tempoid = $resultoid;
						$tempoid =~ s/^\s+|\s+$//g;
						if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.8.".$secCtlIndex) && (length($result->{$resultoid}) != 0 )){
							$finalString =  $finalString . "Secondary Controller Service Tag = $result->{$resultoid}$nextline";
							delete $result->{$resultoid};
							$flag = 1;
							last;
						}
					}
					if ($flag != 1) {
						$finalString = $finalString .  "Secondary Controller Service Tag = Not Available$nextline";
					   }
					$flag = 0;
					
					
					foreach my $resultoid (keys %{$result}) {
						$tempoid = $resultoid;
						$tempoid =~ s/^\s+|\s+$//g;
						if( $isIpv4_ctl eq "Y" )
						{
							if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.5.".$secCtlIndex) && (length($result->{$resultoid}) != 0 )){
								$finalString =  $finalString . "Secondary Controller IP = $result->{$resultoid}$nextline";
								delete $result->{$resultoid};
								$flag = 1;
								last;
							}
						}
						else
						{
							if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.10.".$secCtlIndex) && (length($result->{$resultoid}) != 0 )){
								$finalString =  $finalString . "Secondary Controller IP = $result->{$resultoid}$nextline";
								delete $result->{$resultoid};
								$flag = 1;
								last;
							}
						}
					}
					if ($flag != 1) {
						$finalString = $finalString .  "Secondary Controller IP = Not Available$nextline";
					   }
					$flag = 0;
					
					foreach my $resultoid (keys %{$scalarresult}) {
						$tempoid = $resultoid;
						$tempoid =~ s/^\s+|\s+$//g;
						if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.8.0") && (length($scalarresult->{$resultoid}) != 0 )){
							$finalString =  $finalString . "Compellent URL = $scalarresult->{$resultoid}";
							delete $scalarresult->{$resultoid};
							$flag = 1;
							last;
						}
					}
					if ($flag != 1) {
						$finalString = $finalString .  "Compellent URL = Not Available";
					   }
					$flag = 0;
		
		}
			
        }

		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
       print "$finalString";
		exit $OK;
    }
	
	

############################################################
# Func:         get_compellent_component_health
# Input:        Component name, Severity name, overall health check flag 
# Output:       No output.
# Description:  Main function which is getting callled by each component
#               and calling other function to display the status 
#               of the component.
############################################################

sub get_compellent_component_health {
	
	my ($component,$component_descriptor, $severity_name,$check_overall_health) = @_;
    my $result = undef;
	my $tmpStatus = undef;
	my $tmpCtlStatus = undef;
	my $tempoid = undef;
	my $oid = $main_oid{$component}->{'oid'};
    $result = $snmp_session->get_entries(-columns => [keys %{$oid}]);
	
	if ((!defined $result)) {
        print "ERROR: SNMP : ", $snmp_session->error;
        log_msg("CRITICAL", $snmp_session->error);
		if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
        exit $UNKNOWN;
    } else {
        log_msg("INFO", "Success in getting value from Dell agent.\n");
    }
	
	if ($component eq 'mngghs'){
	    foreach my $mngghskey ( keys %{$result}) {
		
			$tmpStatus = $mngghs_mapping{$result->{$mngghskey}};
			if ((!defined $tmpStatus)) {
					$tmpStatus = 'UNKNOWN';
				}
			$printmsg = $printmsg . "$mngghs_details_oid{substr($mngghskey, 0, -2)} = $tmpStatus";
			$final_exit_code = $Nagios_String_ExitStatus_mapping{$tmpStatus};
		}
	}
	elsif ($component eq 'ctlghs'){
		foreach my $ctlghskey ( keys %{$result}) {
			$tempoid = $ctlghskey;
			$tempoid =~ s/^\s+|\s+$//g;
			if (($tempoid eq "1.3.6.1.4.1.674.11000.2000.500.1.2.13.1.3.".$ctl_idx) && (length($result->{$ctlghskey}) != 0 ) )
			{
				$tmpCtlStatus = $ctlghs_mapping{$result->{$ctlghskey}};
				if ((!defined $tmpCtlStatus)) {
					$tmpCtlStatus = 'UNKNOWN';
				}
				$printmsg = $printmsg . "$ctlghs_details_oid{substr($ctlghskey, 0, -2)} = $tmpCtlStatus";
				$final_exit_code = $Nagios_String_ExitStatus_mapping{$tmpCtlStatus};
			}
		}
	}
	
	else {
		%output = %{arrange_result($result, $oid) };
		@severity_array = @{severity_arrange($component, $severity_name, \%output)};
		my_printing(\@severity_array,\%output, $component,,$component_descriptor, $severity_name);
		
		
		if ($check_overall_health == 0) 
		{
			if(defined $severity_array[2][0]) 
			{
				$final_exit_code = $CRITICAL;
			} 
			elsif (defined  $severity_array[1][0]) 
			{
				$final_exit_code = $WARNING;
			}
			elsif (defined  $severity_array[0][0]) 
			{
				$final_exit_code = $OK;
			} 
			else 
			{
				#Set exit code UNKNOWN
				$final_exit_code = $UNKNOWN;
			}
		}
	}
	
    if(defined $opt{servicename})
    {
	my $command = $nagioshomedir . "/libexec/eventhandlers/submit_check_result " . $opt{hostname} . q{ } . "\"".$opt{servicename}."\"" . q{ } . $final_exit_code . q{ } . "\"" . $printmsg . "\"";
        system($command);
    }
    else
    {
	print $printmsg;
	if (defined ($snmp_session))
	{ 
	    $snmp_session->close();
	}
	exit $final_exit_code;
    }	
}


########################################
# All Oid in a hash with its references.
########################################
our %main_oid = (
			'ctlghs'           => \%complete_ctlghs,
			'mngghs'           => \%complete_mngghs,
			'mngpd'			   => \%complete_mngpd,
			'mngvol'		   => \%complete_mngvol,
         );

#########################################

# Help text
$HELP = <<'END_HELP';
Usage: dell_check_compellent.pl -H <HOSTNAME> [OPTION]...

OPTIONS:
    -i, --item          Component name.
OPTIONAL:
    -h, --help          Display this help text
    -F, --file          Host configuration file with absolute path 
    -s, --servicename   Service name.
END_HELP

# Options with default values
%opt = (
    'hostname'     => undef,
    'filepath'     => undef,
    'help'         => 0,
    'component'    => undef,
    'opt_log'      => 0,
    'service'      => undef,
	'x'      	   => undef,
    
);

# Get options
GetOptions( 
    'H|hostname=s'      => \$opt{hostname},
    'F|file=s'          => \$opt{filepath},
    'h|help'            => \$opt{help},
    'i|item=s'          => \$opt{component},
    'l|log=i'           => \$opt{opt_log},
    's|servicename=s'   => \$opt{servicename},
	'x|index=s'   		=> \$opt{ctlindex},
) or do { 
    print $HELP; 
    exit $UNKNOWN; 
};


# If user requested help
if ($opt{'help'}) {
    print $HELP;
    exit $OK;
}


# Error if hostname option is not present
if ((!defined $opt{hostname}) and (!defined $opt{component}) )  {
    print $HELP;
    exit $UNKNOWN;
}

# Default line break
$nextline = '<br>';

my $tm = localtime(time);
my $tm_month = sprintf "%02d",$tm->mon + 1;
my $tm_day = sprintf "%02d",$tm->mday;
my $tm_year = $tm->year + 1900;

my ($volume, $directory, $file) = File::Spec->splitpath(__FILE__);

our $opt_logfile = undef;
our $nagioshomedir = undef;
my $config_cfg_path = $directory . "dellconfig.cfg";
if(-e $config_cfg_path) {
    my $log_path = undef;
    my $row = undef;
    if(open(my $fh,"<" , $config_cfg_path)) {
        while ($row  =  <$fh> ){
            chomp $row;
            if(index($row, "NAGIOS_HOME") != -1){
            $row =~ s/\s//g;
            $nagioshomedir = substr($row,12);
            last;
            }
        }
        $log_path = $nagioshomedir . "/var/dell/";
        if(!( -d $log_path )) {
            system ("mkdir -p $log_path");
        }
        $opt_logfile = $log_path . "CompellentServices_" . $tm_year . $tm_month  . $tm_day . ".dbg";
    } 
}
 
#---------------------------------------------------------------------
# Functions
#---------------------------------------------------------------------

##################################################################
# Func: snmp_initialize 
# Input: No input
# outout: No Output
# Description :  This function intializes the snmp session object
#                which will be used for making snmp querries. 
##################################################################
sub snmp_initialize {
    my $temp_community;

    my %param
      = (
     '-hostname'    => $opt{hostname},
     '-version'     => 2,
     '-community'   => 'public',
     '-port'        => 161,
     '-timeout'     => 3,
     '-retries'     => 1,
     '-domain'        => 'UDP/IPv4',
    );

    my $filename = undef;
    my @snmp_params;
    # Parameters to Net::SNMP->session()
	
	if (defined $opt{'ctlindex'}) {
        $ctl_idx = $opt{'ctlindex'};
	}
	
    if (defined $opt{'filepath'}) {
        $filename = $opt{'filepath'};
		
    }elsif(defined $opt{servicename}){
        my $file_check  = $nagioshomedir . "/dell/config/objects/" . $opt{hostname} . ".cfg";
        if( -e $file_check) {
            $filename = $file_check;
        } else {
				if (eval { require  Socket; 1}) { 
						require  Socket;
                    } 
				else{ 
                         log_msg("ERROR: Required perl module Socket not found."); 
                         print "ERROR: Required perl module Socket not found\n"; 
                         exit $UNKNOWN;
                    }
            my $fqdnName = gethostbyaddr(inet_aton("$opt{hostname}"), AF_INET);
            $file_check = $nagioshomedir . "/dell/config/objects/" . $fqdnName . ".cfg";
            if ( -e $file_check) {
                $filename = $file_check;
            }
        }
    }
 
	my $row_counter = 0;
    if (defined $filename){   
        if(open(my $fh, "<", $filename) ) {
            log_msg("INFO ", "Success in opening the file $filename\n");
            while (my $row = <$fh>) {
                chomp $row;
				if(index($row, "action_url") != -1)
				{
                    $row =~ s/\s//g;
                    $row = substr($row,length("action_url"));
                    #$consoleurl = $row; 
					@split_url = split('//',$row);
					if ( index($split_url[1], ":") != -1 )
					{
						$isIpv4_ctl = "N";
					}
					elsif(index($split_url[1], ".") != -1)
					{
						$isIpv4_ctl = "Y";
					}
                    $row_counter = $row_counter + 1 ;
                } 
                elsif (index($row, "_dell_comm_params") != -1)
				{
                    $row =~ s/\s//g;
                    $row = substr($row,17);
                    @snmp_params = split(',',$row);
                    $row_counter = $row_counter + 1 ;
                }
				if( $row_counter == 2 ){
                    last;
                }
            }
	    #Reading controller index incase of trap based health update of Compellent Traps.
	    if(defined $opt{servicename})
	    {
	        while (my $row = <$fh>) {
		    chomp $row;
		    if (index($row, "_INDEX") != -1)
		    {
		        $row =~ s/\s//g;
		        $row = substr($row,6);
		        $ctl_idx = $row;
		        last;
		    }                 
	        }
	    }
			
            if ($snmp_params[0] eq 'SNMP') {
			    $temp_community = $snmp_params[1];
			    $param{'-version'}   = $snmp_params[2];
                $param{'-timeout'}   = $snmp_params[3];
                $param{'-retries'}   = $snmp_params[4];
                $param{'-port'}      = $snmp_params[5];
                $param{'-domain'}    = $snmp_params[6];
			} else {
                print "CRITICAL: Internal Error - Invalid snmp params\n";
                log_msg("CRITICAL", "Internal Error - Invalid snmp params\n");
                exit $UNKNOWN;
            }
			
			if ($param{'-domain'} eq "UDP/IPv6"){
				if (eval { require  Socket6; 1}) { 
						require  Socket6;
                     } 
				else { 
                         log_msg("ERROR: Required perl module Socket6 not found."); 
                         print "ERROR: Required perl module Socket6 not found\n"; 
                         exit $UNKNOWN;
                     }
            }
            else{
				if (eval { require  Socket; 1}) { 
						require  Socket;
                    } 
				else{ 
                         log_msg("ERROR: Required perl module Socket not found."); 
                         print "ERROR: Required perl module Socket not found\n"; 
                         exit $UNKNOWN;
                    }
            }

            my $resource_file = $nagioshomedir . "/dell/resources/dell_resource.cfg";
            my $name;
            my $value;

            if ( -e $resource_file){
                if(open(my $rfh, "<", $resource_file)){
                    while (my $resource_row = <$rfh> ) {
                        chomp $resource_row;
                        $resource_row =~ s/^\s+|\s+$//g;
                        if ( ($resource_row !~ /^#/) && ($resource_row ne "") ){    # Ignore lines starting with # and blank lines
                            ($name, $value) = split (/=/, $resource_row);          # Split each line into name value pairs
                            $value =~ s/^\s+|\s+$//g;     # Remove spaces at the start of the line
                            $name =~ s/^\s+|\s+$//g;
                            
                            if ($name eq $temp_community){
								if ($value ne ""){
									$param{'-community'} = $value;
									last;
								} else {
									print "CRITICAL: Macro $name is not configured in the resource file: $filename\n";
									log_msg("CRITICAL", "Macro $name is not configured in the resource file: $filename\n");
									exit $UNKNOWN;
								}
							}	
                        } 
                    }
			    } else {
					print "CRITICAL: Error in opening resource file: $resource_file\n";
					log_msg("CRITICAL", "Error in opening resource file: $resource_file.\n");
					exit $UNKNOWN;
				}
            } else {
				print "CRITICAL: Missing resource file: $resource_file\n";
				log_msg("CRITICAL", "$resource_file not found.\n");
				exit $UNKNOWN;
			}
			
        } else {
            log_msg("WARNING", "Error in opening the file $filename; Proceeding with default value.\n");
        }
    } else {
        print "CRITICAL: Filepath is invalid : $filename\n";
        log_msg("CRITICAL", "Filepath is invalid : $filename\n");
        exit $UNKNOWN;
    }
     
    my $calculated_timeout = ($param{'-timeout'} * ($param{'-retries'} + 1) + 120);
    $plugin_timeout = $plugin_timeout > $calculated_timeout ? $plugin_timeout: $calculated_timeout ;

    # Parameters for SNMP v2c or v1
    if ($param{'-version'} != 2 and $param{'-version'} != 1) {
        print "SNMP: This Plugin doesn't support SNMP version other than 1 and 2.";
        log_msg ("CRITICAL","SNMP: This Plugin doesn't support SNMP version other than 1 and 2\n");
        exit $UNKNOWN;
    }    

    # Try to initialize the SNMP session
    if (eval {require Net::SNMP; 1}) {
        ($snmp_session, $snmp_error) = Net::SNMP->session( %param );
        if (!defined ($snmp_session)){ 
            print "Error while creating SNMP Session.";
            log_msg("CRITICAL ","Error while creating SNMP Session.");
            exit $UNKNOWN;
        } else {
            log_msg ("INFO","Success in creating the session.\n");
        }
    } else {
        print "ERROR: Package: Required perl module Net::SNMP not found";
        log_msg("CRITICAL","Package: Required perl module Net::SNMP not found");
        exit $UNKNOWN;
    }
    return;
}


##################################################################
# Func: severity_arrange
# Input: severity name string, arranged snmp result hash 
# outout: Return an array of indexes based on severity.
# Description :  This function takes arranged snmp result hash and return
#                a array of indexes based on severity. 
##################################################################
sub severity_arrange {
	my ($component, $severity_name, $oidref) = @_;
    my @finaloutput = ();
    my $all_ok_index = 0;
    my $all_critical_index = 0;
    my $all_warn_index = 0;
	my $all_unknown_index = 0;

      foreach my $refoid (keys %{$oidref}){
            if( $oidref->{$refoid}{$severity_name} == 1) {
                # All Ok status Index[0]
                $oidref->{$refoid}{$severity_name} = 0;
                $finaloutput[0][$all_ok_index] = $refoid;
                $all_ok_index = $all_ok_index + 1;
            } elsif ($oidref->{$refoid}{$severity_name} == 3) {
                # All Wanring Status Index[1] 
                $oidref->{$refoid}{$severity_name} = 1;
                $finaloutput[1][$all_warn_index] = $refoid;
                $all_warn_index = $all_warn_index + 1;
            } elsif ($oidref->{$refoid}{$severity_name} == 2){
                # All CRITICAL Status Index[2]
                $oidref->{$refoid}{$severity_name} = 2;
                $finaloutput[2][$all_critical_index] = $refoid;
                $all_critical_index = $all_critical_index + 1;
            } else {
			    # All UNKNOWN Status Index[3]
                $oidref->{$refoid}{$severity_name} = 3;
                $finaloutput[3][$all_unknown_index] = $refoid;
                $all_unknown_index = $all_unknown_index + 1;
			}
        }    
    
	
    return \@finaloutput;
}

#########################################################################
# Func :         my_printing
# Input:         severity_array, arranged result hash, component name, 
#				 severity name
# Output:        NO output
# Description :  This function prints all the instances of the component 
#                by iterating through the array and hash. 
# 
#########################################################################

sub my_printing {
	my ($sevArray, $output, $component,$component_descriptor,$severity_name) = @_;
    my $severity;
    my $severity_index = 0;
    my $enum_bitmask_found = 0;
    my $enum_or_bitmask = 0;
    my $instance_count = 1;

    for ($severity = 2 ; $severity >= 0; $severity-- ) {
        if (exists $sevArray->[$severity]){
            for ($severity_index = 0 ; exists $sevArray->[$severity][$severity_index]; $severity_index++){
                $printmsg = $printmsg . "#$instance_count ";
                my $print_index_key =  $sevArray->[$severity][$severity_index];
                $printmsg = $printmsg .  "$severity_name = $Nagios_ExitStatus_String_mapping{$output->{$print_index_key}->{$severity_name}}, ";
                $printmsg = $printmsg .  "$component_descriptor = $output->{$print_index_key}->{$component_descriptor}, ";
                delete $output->{$print_index_key}->{$component_descriptor};
                delete $output->{$print_index_key}->{$severity_name};

                foreach my $output_key (sort keys %{$output->{$print_index_key}}){
	                foreach my $enum_name (keys %{$main_oid{$component}->{'enums'}}){
                        if ($output_key eq $enum_name){     
                            $enum_or_bitmask = 1;
                            if (exists $main_oid{$component}->{'enums'}->{$enum_name}->{$output->{$print_index_key}->{$output_key}}){
                                $printmsg = $printmsg . "$output_key = $main_oid{$component}->{'enums'}->{$enum_name}->{$output->{$print_index_key}->{$output_key}}, ";
                            } else {
                                $printmsg = $printmsg . "$output_key = Other($output->{$print_index_key}->{$output_key}), ";
                            }
                            last;
                        }
                    }
                    if ($enum_or_bitmask != 1){
                        $printmsg = $printmsg . "$output_key = $output->{$print_index_key}->{$output_key}, ";
                    }
                    $enum_bitmask_found = 0;
                    $enum_or_bitmask = 0;
                }

                chop ($printmsg);
                chop ($printmsg);
                $printmsg = $printmsg . $nextline;
                $instance_count = $instance_count + 1;
            }
        }
    }
	
	$severity = 3;
        if (exists $sevArray->[$severity]){
            for ($severity_index = 0 ; exists $sevArray->[$severity][$severity_index]; $severity_index++){
                $printmsg = $printmsg . "#$instance_count ";
                my $print_index_key =  $sevArray->[$severity][$severity_index];
                $printmsg = $printmsg .  "$severity_name = $Nagios_ExitStatus_String_mapping{$output->{$print_index_key}->{$severity_name}}, ";
                $printmsg = $printmsg .  "$component_descriptor = $output->{$print_index_key}->{$component_descriptor}, ";
                delete $output->{$print_index_key}->{$component_descriptor};
                delete $output->{$print_index_key}->{$severity_name};

                foreach my $output_key (sort keys %{$output->{$print_index_key}}){
	                foreach my $enum_name (keys %{$main_oid{$component}->{'enums'}}){
                        if ($output_key eq $enum_name){     
                            $enum_or_bitmask = 1;
                            if (exists $main_oid{$component}->{'enums'}->{$enum_name}->{$output->{$print_index_key}->{$output_key}}){
                                $printmsg = $printmsg . "$output_key = $main_oid{$component}->{'enums'}->{$enum_name}->{$output->{$print_index_key}->{$output_key}}, ";
                            } else {
                                $printmsg = $printmsg . "$output_key = Other($output->{$print_index_key}->{$output_key}), ";
                            }
                            last;
                        }
                    }
                    if ($enum_or_bitmask != 1){
                        $printmsg = $printmsg . "$output_key = $output->{$print_index_key}->{$output_key}, ";
                    }
                    $enum_bitmask_found = 0;
                    $enum_or_bitmask = 0;
                }

                chop ($printmsg);
                chop ($printmsg);
                $printmsg = $printmsg . $nextline;
                $instance_count = $instance_count + 1;
            }
      }
		
    $printmsg = substr ($printmsg, 0, -4);
}

##################################################################
# Func: arrange_result
# Input: snmp querry result, all oid hash
# outout: Return a reference of arranged result based on index value.
# Description :  This function takes snmp querry result and all oid 
#                hash reference and return a reference of arranged 
#                hash based on index
##################################################################
sub arrange_result {
    my ($result,$oidref) = @_;
    my %output = ();
    my $tempoid = undef;
    foreach my $refoid (keys %{$oidref}){
        $tempoid = $refoid . '.';
        foreach my $resoid (keys %{$result}){
            if ($resoid =~ /\Q$tempoid\E/) {
                my $key = length($resoid) - length($tempoid);
                my $key1 = substr $resoid,length($tempoid),$key;
                my $value = ($result->{$resoid});
                $value =~ s/^\s+|\s+$//g;
                $output{$key1}{$oidref->{$refoid}} = $value;
            }         
        }
    }
    return \%output;
}


############################################################
# MAIN Function
############################################################

# Initialize SNMP

log_msg("INFO", "Log initializing\n");
snmp_initialize();

# Setting timeout
$SIG{ALRM} = sub {
    print "PLUGIN TIMEOUT: dell_check_compellent.pl timed out after $plugin_timeout seconds$nextline";
	if (defined ($snmp_session))
		{ 
            $snmp_session->close();
        }
    exit $UNKNOWN;
};

alarm $plugin_timeout;

# Check Arguments
if (defined $opt{'component'}){
    if ( (lc$opt{'component'} eq 'mnginfo' ) or (lc$opt{'component'} eq 'ctlinfo' )) {
         get_compellent_info();
    } elsif (lc$opt{'component'} eq 'mngghs' ) {
         get_compellent_component_health('mngghs','NA', 'NA', 0);
    } elsif (lc$opt{'component'} eq 'ctlghs' ) {
         get_compellent_component_health('ctlghs','NA', 'NA', 0);
    } elsif(lc$opt{'component'} eq 'mngpd'){
        get_compellent_component_health('mngpd','Name', 'Status',0);
    } elsif(lc$opt{'component'} eq 'mngvol'){
        get_compellent_component_health('mngvol','VolumeName', 'Status',0);
    }
	
	else {
        print "Invalid component name $opt{'component'}$nextline";
        log_msg ("CRITICAL", "Invalid component name $opt{'component'}\n");
		exit $UNKNOWN;
    }
}

#-----------------------------------------------------------------
# Simple log-writing method
#-----------------------------------------------------------------

sub log_msg
{
    my ($severity,$message) = @_;
    my $tm = localtime(time);
    # time in following format : 2013-01-16 18:57:37 
    my $current_time = sprintf '%d-%02d-%02d %02d:%02d:%02d ', $tm->year + 1900, $tm->mon+1, $tm->mday, $tm->hour , $tm->min , $tm->sec;    
    
    eval
    {
        $message = $current_time . q{ } . $severity . q{ } . q{Dell_} . $opt{'component'} . q{ } . $opt{'hostname'} . q{ } .  $message ;    

        if ($opt{opt_log})
        {
            open(FILE,">>$opt_logfile") ;
            print FILE "$message" or warn "Error writing $message to $opt_logfile: $!";
            close FILE;
        }
    };
    
    return 1;
}
if (defined ($snmp_session))
	{ 
        $snmp_session->close();
    }
exit;
 
