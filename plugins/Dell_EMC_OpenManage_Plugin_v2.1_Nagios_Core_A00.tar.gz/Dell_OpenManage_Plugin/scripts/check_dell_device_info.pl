#!/usr/bin/perl

##########################################################################################
#Title: check_dell_device_info.pl
#Version: 1.0
#Creation Date: 25-Sep-2014
#Description: This is a plug-in that gets the specified device inventory information
#Copyright (c) 2014 Dell Inc.
#All Rights Reserved.
###########################################################################################

use strict;
use Net::SNMP;
use Getopt::Long qw(:config no_ignore_case);
use Time::localtime;
use File::Spec;


my $totalArgs = $#ARGV + 1;
my $snmpCommunity = 'public';
my $snmpPort = 161;
my $snmpVersion = 2;
my $snmpRetries = 1;
my $snmpTimeout = 3;
our $nextlinechar = '<br>';

use vars qw(%opt $snmp_session $snmp_error) ;
use constant DELLCONFIGPATH =>'dellconfig.cfg';
use constant LOGMODULE =>'Dell_Info ';
use constant OK         => 0;
use constant WARNING    => 1;
use constant CRITICAL   => 2;
use constant UNKNOWN    => 3;

my $NAGIOS_HOME = "";
my ($volume, $directory, $file) = File::Spec->splitpath(__FILE__);
my $dellConfigFile = "$directory".DELLCONFIGPATH;
readConfigFile ("$dellConfigFile", "NAGIOS_HOME");
my $DELL_NAGIOS_LOG_DIR = "$NAGIOS_HOME/var/dell";
if(! -d $DELL_NAGIOS_LOG_DIR)
{
    system("mkdir -p $DELL_NAGIOS_LOG_DIR");
}

our $opt_log = 0;
my $tm = localtime(time);
my $tm_month = sprintf "%02d",$tm->mon + 1;
my $tm_day = sprintf "%02d",$tm->mday;
my $tm_year = $tm->year + 1900;

our $opt_logfile = "$DELL_NAGIOS_LOG_DIR/services_" . $tm_year . $tm_month  . $tm_day . ".dbg";

#iDRAC server inventory OIDs and corresponding display names
our %idrac_oid
      = (
        '1.3.6.1.4.1.674.10892.5.1.1.8' =>'Firmware Version',
        '1.3.6.1.4.1.674.10892.5.1.3.1' =>'FQDN Name',
        '1.3.6.1.4.1.674.10892.5.1.3.2' =>'Service Tag',
        '1.3.6.1.4.1.674.10892.5.1.3.6' =>'OS Name',
        '1.3.6.1.4.1.674.10892.5.1.3.14' =>'OS Version',
        '1.3.6.1.4.1.674.10892.5.1.3.12' =>'Model Name',
        '1.3.6.1.4.1.674.10892.5.1.1.2'  =>'Device Type',
        '1.3.6.1.4.1.674.10892.5.1.1.6'  =>'Console URL',
        '1.3.6.1.4.1.674.10892.5.1.2.1' =>'Chassis Tag',
        '1.3.6.1.4.1.674.10892.5.1.3.18' =>'Node ID',
        '1.3.6.1.4.1.674.10892.5.1.1.7' => 'RAC Type',
    );

# Help text
our $HELP = <<'END_HELP';
Usage: perl check_dell_device_info.pl -H <HOSTNAME> [OPTION]...

OPTIONS:
   -i, --item           Plugin timeout in seconds
   -h, --help          Display this help text
   -F, --file          path configuration file for SNMP parameters.
END_HELP


# Get options
GetOptions(
    'H|hostname=s'   => \$opt{hostname},
    'F|file=s'       => \$opt{filepath},
    'h|help'         => \$opt{help},
    'i|item=s'       => \$opt{component},
    'l|log=i'         => \$opt_log,
) or do {
    print $HELP;
    exit UNKNOWN;
};


# If user requested help
if ($opt{'help'}) {
    print $HELP;
    exit OK;
}


# Error if hostname option is not present
if (!defined $opt{hostname}) {
    print $HELP;
    exit UNKNOWN;
}

if (!defined $opt{component}) {
    print $HELP;
    exit UNKNOWN;
}


my %param
      = (
     '-hostname'    => $opt{hostname},
     '-version'     => 2,
     '-community'   => 'public',
     '-port'        => 161,
     '-timeout'     => 3,
     '-retries'     => 1,
     '-domain'        =>    'UDP/IPv4',
    );

#---------------------------------------------------------------------
# Functions
#---------------------------------------------------------------------

#-----------------------------------------------------------------
# Simple log-writing method
#-----------------------------------------------------------------
sub log_msg
{
    my $message = shift;
    my $tm = localtime(time);
    #time in following format : 2013-01-16 18:57:37:
    my $current_time = sprintf '%d-%02d-%02d %02d:%02d:%02d ', $tm->year + 1900, $tm->mon+1, $tm->mday, $tm->hour , $tm->min , $tm->sec;

    eval
    {
        $message = $current_time . LOGMODULE . $message;
        if ($opt_log)
        {
            open(FILE,">>$opt_logfile") ;
            print FILE "$message" or warn "Error writing $message to $opt_logfile: $!";
            close FILE ; 
        }
    };

    if ($@)
    {
                warn "Error: $@\n";
    }

    return 1;
}

#-----------------------------------------------------------------
# Function to read config file
#-----------------------------------------------------------------

sub readConfigFile {
    my ($file, $configParamName) = @_;
    my $readLine;
    my $name;
    my $value;
    if  (-e $file)
    {
        open (CONFIG, "<", "$file");
        while (<CONFIG>) {
                $readLine=$_;
                chop ($readLine);          # Remove trailling \n
                $readLine =~ s/^\s*//;     # Remove spaces at the start of the line
                $readLine =~ s/\s*$//;     # Remove spaces at the end of the line
                if ( ($readLine !~ /^#/) && ($readLine ne "") ){    # Ignore lines starting with # and blank lines
                ($name, $value) = split (/=/, $readLine);          # Split each line into name value pairs
                        if ( $name eq $configParamName && $value ne "" ){
                                $NAGIOS_HOME = $value;
                        }
                }
        }
        close(CONFIG);
    }
    else
    {
        log_msg("ERROR: File $file doesn't exist \n");
    }
   return;
}

##################################################################
# Initialize SNMP
##################################################################
sub initSnmp  {
    my @snmp_params;
    # Parameters to Net::SNMP->session()
    if(defined $opt{'filepath'}){
        my $filename = $opt{'filepath'};
        if(open(my $fh, $filename) ) {
            log_msg("INFO: Success in opening the file $filename\n");
            while (my $row = <$fh>) {
                chomp $row;
                if(index($row, "_dell_comm_params") != -1){
                    $row =~ s/\s//g;
                    $row = substr($row,12);
                    @snmp_params = split(',',$row);
                    last;
                }
            }
            $param{'-community'} = $snmp_params[1];
            $param{'-version'}  = $snmp_params[2];
            $param{'-timeout'}  = $snmp_params[3];
            $param{'-retries'}  = $snmp_params[4];
            $param{'-port'}  = $snmp_params[5];
        $param{'-domain'}  = $snmp_params[6];
    } else {
            log_msg("ERROR: Error in opening the file $filename; Proceeding with default value.\n");
        }
    }
    
    if ($param{'-version'} != 2 and $param{'-version'} != 1) {
        log_msg ("ERROR: This plug-in does not support SNMP version other than 1 or 2\n");
        print "Unsupported snmp version : $param{'-version'}";
        exit UNKNOWN;
    } 
      
    # Try to initialize the SNMP session
    if (eval {require Net::SNMP; 1}) {
    ($snmp_session, $snmp_error) = Net::SNMP->session( %param );
        if (!defined ($snmp_session)){
            printf "ERROR: Failed to establish SNMP session ";
            log_msg("ERROR: Failed to establish SNMP session.\n");
            exit UNKNOWN;
        } else {
            log_msg ("INFO: Success in creating the session\n");
        }
    } else {
        print "Required Perl module Net::SNMP is missing\n";
        log_msg("ERROR: Required perl module Net::SNMP not found\n");
        exit UNKNOWN;
    }
    return;
}


##################################################################
#Function to get iDRAC server information 
##################################################################
sub get_idrac_info {

    initSnmp();
    my $snmpStatus = "true";
    my $finalString  = undef;
    my $outPutLength;
    my $tmpoidresult;
    my $tmpractypeoid = "1.3.6.1.4.1.674.10892.5.1.1.7.0";
    my $racTypeModularFlag = "Not Available";
    my  $result = $snmp_session->get_entries(-columns => [keys %idrac_oid]) or $snmpStatus = "false";
    if($snmpStatus eq "false")
    {
        print "ERROR: Failed to establish SNMP session";
        log_msg("ERROR: Failed to establish SNMP session\n"); 
        exit UNKNOWN;
    }
    if (!defined $result) {
        printf "ERROR: SNMP session error: ";
        log_msg("ERROR: $snmp_session->error\n");
        exit UNKNOWN;
    }else {
        my $tempoid = undef;
        my $flag = 0;
        log_msg("INFO: Success in getting value from Dell agent.\n");
        foreach my $resultoid (keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq $tmpractypeoid ) && (length($result->{$resultoid}) != 0)) {
                my $tmpractype = $result->{$tmpractypeoid};
                if( ($tmpractype == 17 ) || ($tmpractype == 33 )){
                    $racTypeModularFlag = "Modular";
                    log_msg("INFO: Its a Modular server \n");
                
                } 
                elsif ( ($tmpractype == 16 ) || ($tmpractype == 32 )){
                    $racTypeModularFlag = "Monolithic";
                    log_msg("INFO: Its a Monolithic server \n");
                }
            }
        }


        foreach my $resultoid ( keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.3.1.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "Server Host FQDN = $result->{$resultoid}$nextlinechar";
                $flag = 1;
                delete $result->{$resultoid};
                last;
            }
        }
        if ($flag != 1){
            $finalString = $finalString .  "Server Host FQDN = Not Available$nextlinechar"; 
        }
		$flag = 0;

        foreach my $resultoid (keys  %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.3.12.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "Model Name = $result->{$resultoid}$nextlinechar";
                $flag = 1;
                delete $result->{$resultoid};
                last;
            }
        }

        if ($flag != 1){
            $finalString = $finalString .  "Model Name = Not Available$nextlinechar";
           }
		$flag = 0;


        foreach my $resultoid ( keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.1.2.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "Device Type = $result->{$resultoid}$nextlinechar";
                delete $result->{$resultoid};
                $flag = 1;
                last;
            }
        }

        if ($flag != 1){
            $finalString = $finalString .  "Device Type = Not Available$nextlinechar";
           }
		$flag = 0;


        foreach my $resultoid (keys  %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.3.2.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "Service Tag = $result->{$resultoid}$nextlinechar";
                delete $result->{$resultoid};
                $flag = 1;
                last;
            } 
        }

        if ($flag != 1){
            $finalString = $finalString .  "Service Tag = Not Available$nextlinechar";
           }
		$flag = 0;


        foreach my $resultoid ( keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.3.18.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "Node Id = $result->{$resultoid}$nextlinechar";
                delete $result->{$resultoid};
                $flag = 1;
                last;
            } 
        }

        if ($flag != 1){
            $finalString = $finalString .  "Node Id = Not Available$nextlinechar";
           }
		$flag = 0;


        $finalString = $finalString . "Product Type = $racTypeModularFlag$nextlinechar";  

		
		if ($racTypeModularFlag eq "Modular")  
		{
			foreach my $resultoid (keys  %{$result}) {
				$tempoid = $resultoid;
				$tempoid =~ s/^\s+|\s+$//g;
				if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.2.1.0") && 
					(length($result->{$resultoid}) != 0 )) {
					$finalString =  $finalString . "Chassis Tag = $result->{$resultoid}$nextlinechar";
					delete $result->{$resultoid};
					$flag = 1;
					last;
				} 
			}

			if ($flag != 1) {
				$finalString = $finalString .  "Chassis Tag = Not Available$nextlinechar";
			}
			
			$flag = 0;
        }
		
        foreach my $resultoid ( keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.1.8.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "Firmware Version = $result->{$resultoid}$nextlinechar";
                delete $result->{$resultoid};
                $flag = 1;
                last;
            } 
        }


        if ($flag != 1) {
            $finalString = $finalString .  "Firmware Version = Not Available$nextlinechar";
           }
		$flag = 0;



        foreach my $resultoid (keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.3.6.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "OS Name = $result->{$resultoid}$nextlinechar";
                delete $result->{$resultoid};
                $flag = 1;
                last;
            }
        }

        if ($flag != 1) {
            $finalString = $finalString .  "OS Name = Not Available$nextlinechar";
           }
		$flag = 0;



        foreach my $resultoid ( keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.3.14.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "OS Version = $result->{$resultoid}$nextlinechar";
                delete $result->{$resultoid};
                $flag = 1;
                last;
            } 
       }

        if ($flag != 1) {
            $finalString = $finalString .  "OS Version = Not Available$nextlinechar";
           }
		$flag = 0;
        


        foreach my $resultoid ( keys %{$result}) {
            $tempoid = $resultoid;
            $tempoid =~ s/^\s+|\s+$//g;
            if (($tempoid eq "1.3.6.1.4.1.674.10892.5.1.1.6.0") && (length($result->{$resultoid}) != 0 )){
                $finalString =  $finalString . "Console URL = $result->{$resultoid}";
                delete $result->{$resultoid};
                $flag = 1;
                last;
            }
        }

        if ($flag != 1) {
            $finalString = $finalString .  "Console URL = Not Available";
           }
		$flag = 0;

        print "$finalString";
    }
}


if(defined $opt{'component'}){
    log_msg("Started collecting Dell Agent-Free Server inventory information for host: $opt{hostname}\n");    
    if($opt{'component'} eq 'info'){
        get_idrac_info();
        log_msg("Completed Inventory information collection for Agent-Free Server host: $opt{hostname} \n\n");
        exit OK;
       }else {
            log_msg ("DEBUG: Invalid command line arguments\n");
        exit UNKNOWN;
    }
}

exit OK;
