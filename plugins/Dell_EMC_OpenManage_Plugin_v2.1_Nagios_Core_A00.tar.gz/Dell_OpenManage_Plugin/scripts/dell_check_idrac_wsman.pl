#! /usr/bin/perl

##########################################################################
#Title:         Dell Device Plugin Script
#Version:       1.0 
#Creation Date: 10th November 2014
#Description:   This script provides Dell Server health and component 
#               health via Agent-free mode using Wsman protocol. 
#
#Copyright (c) 2014 Dell Inc.
#All Rights Reserved.
##########################################################################


use strict;
use warnings;
use openwsman;
use Socket;
use Getopt::Long qw(:config no_ignore_case);
use Time::localtime;
use File::Spec;
openwsman::set_debug(0);

use vars qw($OK $WARNING $CRITICAL $UNKNOWN $HELP 
            $option $nextline 
            %opt %Nagios_ExitStatus_String_mapping %wsman_status 
    );

our $plugin_timeout = 120;
our $wsman_result;
our $wsman_client;
our $filter;
our %list;
our %temp_list;
our $printmsg = "";
our $final_exit_code = undef;
our $retries = undef;
our $consoleurl = undef;

#Exit Codes
$OK       = 0;
$WARNING  = 1;
$CRITICAL = 2;
$UNKNOWN  = 3;


# Error Code for Nagios from String to number 
our %Nagios_ExitStatus_String_mapping = (
    'OK',			=> 0,
    'WARNING',		=> 1,
    'CRITICAL',		=> 2,
    'UNKNOWN',		=> 3,
);


# Error Code for Nagios Number to String 
%Nagios_ExitStatus_String_mapping = (
    $OK         => 'OK',
    $WARNING    => 'WARNING',
    $CRITICAL   => 'CRITICAL',
    $UNKNOWN    => 'UNKNOWN',
);

# Wsman status from dell agents
%wsman_status = (
	0 => $UNKNOWN,
    1 => $OK,
    2 => $WARNING,
    3 => $CRITICAL,
);


# Max_element for Optmizatio code
our %max_elements_map =(
	lowest_max_element => 10,
	average_max_element => 100,
	maximum_max_element => 300,
);

# OverallHealth status check
our %check_overall_health = (
	yes => 1,
	no  => 0,
);

# Help text
$HELP = <<'END_HELP';
Usage: dell_check_idrac_wsman.pl -H <HOSTNAME> [OPTION]...

OPTIONS:
    -i, --item          Component name.
OPTIONAL:
    -h, --help          Display this help text
    -F, --file          Host configuration file with absolute path 
    -s, --servicename   Service name.
    -m, --macroname     Macro name that needs to read from the configuration file
END_HELP


# Options with default values
%opt = (
    'hostname'     => undef,
    'filepath'     => undef,
    'help'         => 0,
    'component'    => undef,
    'opt_log'      => 0,
    'service'      => undef,
    
);

# Get options
GetOptions( 
    'H|hostname=s'      => \$opt{hostname},
    'F|file=s'          => \$opt{filepath},
    'h|help'            => \$opt{help},
    'i|item=s'          => \$opt{component},
    'l|log=i'           => \$opt{opt_log},
    's|servicename=s'   => \$opt{servicename},
) or do { 
    print $HELP; 
    exit $UNKNOWN; 
};


# If user requested help
if ($opt{'help'}) {
    print $HELP;
    exit $OK;
}


# Error if hostname option is not present
if ((!defined $opt{hostname}) and (!defined $opt{component}) )  {
    print $HELP;
    exit $UNKNOWN;
}

# Default line break
$nextline = '<br>';

my $tm = localtime(time);
my $tm_month = sprintf "%02d",$tm->mon + 1;
my $tm_day = sprintf "%02d",$tm->mday;
my $tm_year = $tm->year + 1900;

my ($volume, $directory, $file) = File::Spec->splitpath(__FILE__);

our $opt_logfile = undef;
our $nagioshomedir = undef;
my $config_cfg_path = $directory . "dellconfig.cfg";
if(-e $config_cfg_path) {
    my $log_path = undef;
    my $row = undef;
    if(open(my $fh,"<" , $config_cfg_path)) {
        while ($row  =  <$fh> ){
            chomp $row;
            if(index($row, "NAGIOS_HOME") != -1){
            $row =~ s/\s//g;
            $nagioshomedir = substr($row,12);
            last;
            }
        }
        $log_path = $nagioshomedir . "/var/dell/";
        if(!( -d $log_path )) {
            system ("mkdir -p $log_path");
        }
        $opt_logfile = $log_path . "AgentfreeServerServices_" . $tm_year . $tm_month  . $tm_day . ".dbg";
    } 
}

our %sensor_state = (
    0   => "Unknown",
    1   => "Other", 
    2   => "Enabled", 
    3   => "Disabled", 
    4   => "Shutting Down", 
    5   => "Not Applicable", 
    6   => "Enabled but Offline", 
    7   => "In Test", 
    8   => "Deferred", 
    9   => "Quiesce", 
    10  => "Starting", 
);

#############################################################
#  Fixed URI for all wsman calls 
############################################################

our $fixed_uri = 'http://schemas.dell.com/wbem/wscim/1/cim-schema/2/';

#############################################################
#  CPU related values 
############################################################

our @cpu_selector_array = ('__cimnamespace','root/dcim');

our %cpu_profile = (
    uri => 'DCIM_CPUView',
    filter_value => "select InstanceID,DeviceDescription,Model,PrimaryStatus,CurrentClockSpeed,NumberOfProcessorCores from DCIM_CPUView", 
    selector => \@cpu_selector_array,
    merge_attribute  => 'InstanceID',
);

our %complete_cpu_profile = (
    profile1 => \%cpu_profile,
);

our %cpu_overall_health_profile = (
    uri => 'DCIM_SystemView',
    selector => \@cpu_selector_array,
    filter_value => "select CPURollupStatus from DCIM_SystemView",
);

our %cpu_profile_key_mapping = (
    'DeviceDescription'      => 'FQDD',
    'PrimaryStatus'          => 'Status', 
    'NumberOfProcessorCores' => 'CoreCount', 
    'CurrentClockSpeed'      => 'CurrentSpeed(GHz)', 
    'Model'                  => 'Name',
    ); 

our %cpu_overallhealth_key_mapping = (
    status => 'CPURollupStatus' ,
);

our %cpu_key_mapping = (
    profile_key => \%cpu_profile_key_mapping,
    overallhealthkey => \%cpu_overallhealth_key_mapping,
);

our %complete_cpu = (
    profile =>  \%complete_cpu_profile,
    overallHealth => \%cpu_overall_health_profile,
    keymapping => \%cpu_key_mapping,
    enums =>    undef,
);

#############################################################
#  FAN related values 
############################################################

our @fan_selector_array = ('__cimnamespace','root/dcim');

our %fan_profile = (
    uri => 'DCIM_NumericSensor',
    filter_value => "select DeviceID,ElementName,PrimaryStatus,EnabledState,CurrentReading from DCIM_NumericSensor where SensorType = 5", 
    selector => \@fan_selector_array,
    merge_attribute => 'DeviceID',
);

our %complete_fan_profile = (
    profile1 => \%fan_profile,
);

our %fan_overall_health_profile = (
    uri => 'DCIM_SystemView',
    selector => \@fan_selector_array,
    filter_value => "select FanRollupStatus from DCIM_SystemView",
);

our %fan_profile_key_mapping = (
    'ElementName'       => 'FQDD', 
    'PrimaryStatus'     => 'Status', 
    'CurrentReading'    => 'Speed(RPM)',
    'EnabledState'      => 'State',
);

our %fan_overallhealth_key_mapping = (
    status => 'FanRollupStatus' ,
);

our %fan_key_mapping = (
    profile_key => \%fan_profile_key_mapping,
	overallhealthkey => \%fan_overallhealth_key_mapping,
);

our %fan_enum = (
     State => \%sensor_state,
);

our %complete_fan = (
    profile =>  \%complete_fan_profile,
	overallHealth => \%fan_overall_health_profile,
    keymapping => \%fan_key_mapping,
    enums =>    \%fan_enum,
);

#############################################################
#  Memory related values 
############################################################

our @mem_selector_array = ('__cimnamespace','root/dcim');

our %mem_profile = (
    uri => 'DCIM_MemoryView',
    filter_value => "select InstanceID,DeviceDescription,PrimaryStatus,Size,CurrentOperatingSpeed,MemoryType,PartNumber from DCIM_MemoryView", 
    selector => \@mem_selector_array,
    merge_attribute => 'InstanceID',
);

our %complete_mem_profile = (
    profile1 => \%mem_profile,
);

our %mem_overall_health_profile = (
    uri => 'DCIM_SystemView',
    selector => \@mem_selector_array,
    filter_value => "select SysMemPrimaryStatus from DCIM_SystemView",
);

our %mem_profile_key_mapping = (
    'DeviceDescription'     => 'FQDD', 
    'MemoryType'            => 'Type' , 
    'PrimaryStatus'         => 'Status' , 
    'Size'                  => 'Size(GB)', 
    'PartNumber'            => 'PartNumber',
    'CurrentOperatingSpeed' => 'Speed(MHz)',
    );

our %mem_overallhealth_key_mapping = (
    status => 'SysMemPrimaryStatus' ,
);

our %mem_key_mapping = (
    profile_key => \%mem_profile_key_mapping,
	overallhealthkey => \%mem_overallhealth_key_mapping,
);

our %mem_Type_Map = (
        1  => 'Other', 
        2  => 'Unknown',
        3  => 'DRAM', 
        4  => 'EDRAM', 
        5  => 'VRAM', 
        6  => 'SRAM', 
        7  => 'RAM', 
        8  => 'ROM', 
        9  => 'FLASH', 
        10 => 'EEPROM', 
        11 => 'FEPROM', 
        12 => 'EPROM', 
        13 => 'CDRAM', 
        14 => '3DRAM', 
        15 => 'SDRAM', 
        16 => 'SGRAM', 
        17 => 'RDRAM', 
        18 => 'DDR', 
        19 => 'DDR2', 
        20 => 'DDR2FBDIMM', 
        24 => 'DDR3', 
        25 => 'FBD2',
        26 => 'DDR4',
    ); 

our %mem_enums = (
        'Type'          => \%mem_Type_Map,
    );

our %complete_mem = (
    profile =>  \%complete_mem_profile,
    keymapping => \%mem_key_mapping,
	overallHealth => \%mem_overall_health_profile,
    enums =>    \%mem_enums,
);

#############################################################
#  GHS related values 
############################################################

our @ghs_selector_array = ('__cimnamespace','root/dcim');

our %ghs_profile1 = (
    uri => 'DCIM_SystemView',
    filter_value => undef,
    selector => \@ghs_selector_array,
    merge_attribute => 'InstanceID',
);

our %complete_ghs_profile = (
    profile1 => \%ghs_profile1,
);

our %ghs_profile_key_mapping = (
    'RollupStatus'         => 'Overall System',
    'BatteryRollupStatus'  => 'Battery',
    'VoltRollupStatus'     => 'Voltage',
    'StorageRollupStatus'  => 'Storage',
    'PSRollupStatus'       => 'Power Supply',
    'FanRollupStatus'      => 'Fan',
    'SysMemPrimaryStatus'  => 'Memory',
    'TempRollupStatus'     => 'Temperature',
	'CPURollupStatus'      => 'Processor',
);

our %ghs_key_mapping = (
    profile_key => \%ghs_profile_key_mapping,
);

our %complete_ghs = (
    profile =>  \%complete_ghs_profile,
    keymapping => \%ghs_key_mapping,
    enums =>    undef,
);

#############################################################
#  Voltage related values 
############################################################


our @voltage_selector_array = ('__cimnamespace','root/dcim');

our %voltage_profile1 = (
    uri => 'DCIM_Sensor',
    filter_value => 'select DeviceID,ElementName,EnabledState,HealthState,CurrentState from DCIM_Sensor where SensorType = 3',
    selector => \@voltage_selector_array,
    merge_attribute => 'DeviceID',
);

our %voltage_profile2 = (
    uri => 'DCIM_NumericSensor',
    filter_value => 'select DeviceID,ElementName,EnabledState,HealthState,CurrentReading from DCIM_NumericSensor where SensorType = 3',
    selector => \@voltage_selector_array,
    merge_attribute => 'DeviceID',
);

our %complete_voltage_profile = (
    profile1 => \%voltage_profile1,
    profile2 => \%voltage_profile2,
);

our %volatge_overall_health_profile = (
    uri => 'DCIM_SystemView',
    selector => \@voltage_selector_array,
    filter_value => "select VoltRollupStatus from DCIM_SystemView",
);

our %voltage_profile_key_mapping = (
    'ElementName'  => 'Location',
    'EnabledState' => 'State',
    'HealthState'  => 'Status',
    'CurrentState' => 'Reading', 
    'CurrentReading' => 'Reading(V)',  
);

our %voltage_overallhealth_key_mapping = (
    status => 'VoltRollupStatus' ,
);


our %voltage_key_mapping = (
    profile_key => \%voltage_profile_key_mapping,
	overallhealthkey => \%voltage_overallhealth_key_mapping,
);

our %vlt_enum = (
    State => \%sensor_state,
);

our %complete_voltage = (
    profile     =>  \%complete_voltage_profile,
	overallHealth => \%volatge_overall_health_profile,
    keymapping  =>  \%voltage_key_mapping,
    enums       =>  \%vlt_enum,
);

#############################################################
#  NIC related values 
############################################################

our @nic_selector_array = ('__cimnamespace','root/dcim');

our %nic_profile1 = (
    uri => 'DCIM_NICView',
    filter_value => 'select InstanceID,DeviceDescription,LinkSpeed,FamilyVersion,ProductName from DCIM_NICView',
    selector => \@nic_selector_array,
    merge_attribute => 'InstanceID',
);

our %nic_profile2 = (
    uri => 'DCIM_NICStatistics',
    filter_value => 'select InstanceID,LinkStatus from DCIM_NICStatistics',
    selector => \@nic_selector_array,
    merge_attribute => 'InstanceID',
);

our %complete_nic_profile = (
    profile1 => \%nic_profile1,
    profile2 => \%nic_profile2,
);

our %nic_profile_key_mapping = (
    'DeviceDescription' => 'FQDD',
    'ProductName'       => 'Name',  
    'LinkStatus'        => 'ConnectionStatus',
    'FamilyVersion'     => 'FirmwareVersion',
    'LinkSpeed'         => 'LinkSpeed',		
);

our %nic_key_mapping = (
    profile_key => \%nic_profile_key_mapping,
);


our %nic_linkspeed = (
	0 	=> 'Unknown',
	1   => '10 Mbps',
	2   => '100 Mbps',
	3   => '1000 Mbps',
	4   => '2.5 Gbps',
	5   => '10 Gbps',
	6   => '20 Gbps',
	7   => '40 Gbps',
	8   => '100 Gbps',
);


our %nic_enum = (
    LinkSpeed => \%nic_linkspeed,
);


our %complete_nic = (
    profile     =>  \%complete_nic_profile,
    keymapping  =>  \%nic_key_mapping,
    enums       =>  \%nic_enum,
);

#############################################################
#  FC (Fiber Channel) NIC related values 
#############################################################
our @fcnic_selector_array = ('__cimnamespace','root/dcim');

our %fcnic_profile1 = (
    uri => 'DCIM_FCView',
    filter_value => 'select InstanceID,DeviceDescription,DeviceName,FamilyVersion,PortSpeed from DCIM_FCView',
    selector => \@fcnic_selector_array,
    merge_attribute => 'InstanceID',
);

our %fcnic_profile2 = (
    uri => 'DCIM_FCStatistics',
    filter_value => 'select InstanceID,PortStatus from DCIM_FCStatistics',
    selector => \@fcnic_selector_array,
    merge_attribute => 'InstanceID',
);

our %complete_fcnic_profile = (
    profile1 => \%fcnic_profile1,
    profile2 => \%fcnic_profile2,
);

our %fcnic_profile_key_mapping = (
    'DeviceDescription' => 'FQDD',
    'DeviceName'        => 'Name', 
    'PortStatus'        => 'ConnectionStatus',
    'FamilyVersion'     => 'FirmwareVersion',
    'PortSpeed'         => 'LinkSpeed',
);

our %fcnic_key_mapping = (
    profile_key => \%fcnic_profile_key_mapping,
);

our %fcnic_portspeed = (
	   0 => 'No Link',
	   1 => '2 Gbps',
	   2 => '4 Gbps',
	   3 => '8 Gbps',
	   4 => '16 Gbps',
	   5 => '32 Gbps',
	   6 => 'Unknown',
);

our %fcnic_enum = (
    LinkSpeed => \%fcnic_portspeed,
);

our %complete_fcnic = (
    profile     =>  \%complete_fcnic_profile,
    keymapping  =>  \%fcnic_key_mapping,
    enums       =>  \%fcnic_enum,
);

#############################################################
#  Disk Controller related values 
############################################################

our @DiskCtl_selector_array = ('__cimnamespace','root/dcim');

our %DiskCtl_profile = (
    uri => 'DCIM_ControllerView',
    filter_value => 'select InstanceID,DeviceDescription,ProductName,PrimaryStatus,ControllerFirmwareVersion,CacheSizeInMB from DCIM_ControllerView where RollupStatus != 0 and PrimaryStatus != 0',
    selector => \@DiskCtl_selector_array,
    merge_attribute => 'InstanceID',
);

our %complete_DiskCtl_profile = (
    profile => \%DiskCtl_profile,
);

our %DiskCtl_profile_key_mapping = (
    'DeviceDescription'         => 'FQDD',
    'ProductName'               => 'Name', 
    'PrimaryStatus'             => 'Status',
    'ControllerFirmwareVersion' => 'FirmwareVersion',
    'CacheSizeInMB'             => 'CacheSize(MB)',
);

our %DiskCtl_key_mapping = (
    profile_key => \%DiskCtl_profile_key_mapping,
	overallhealthkey => undef,
);

our %complete_DiskCtl = (
    profile     =>  \%complete_DiskCtl_profile,
	overallHealth => undef,
    keymapping  =>  \%DiskCtl_key_mapping,
    enums       =>  undef,
);

#############################################################
#  Virtual Disk related values 
############################################################

our @virdisk_selector_array = ('__cimnamespace','root/dcim');

our %virdisk_profile = (
    uri => 'DCIM_VirtualDiskView',
    filter_value => "select * from DCIM_VirtualDiskView where PrimaryStatus != 0 and RollupStatus != 0",
    selector => \@virdisk_selector_array,
    merge_attribute => 'InstanceID',
);

our %complete_virdisk_profile = (
    profile => \%virdisk_profile,
);

our %virdisk_profile_key_mapping = (
    'DeviceDescription'  => 'FQDD',
    'RAIDStatus'         => 'State',
    'SizeInBytes'        => 'Size(GB)',
    'WriteCachePolicy'   => 'WritePolicy',
    'ReadCachePolicy'    => 'ReadPolicy',
    'RAIDTypes'          => 'Layout',
    'StripeSize'         => 'StripeSize',
    'PrimaryStatus'      => 'Status',
    'MediaType'          => 'MediaType',
);

our %writepolicy = (
    0   =>  'Unknown',
    1   =>  'Write Through',
    2   =>  'Write Back',
    4   =>  'Force Write Back',
);

our %stripsize = (
    0   => "Default",
    1   => "512B",
    2   => "1KB",
    4   => "2KB",
    8   => "4KB",
    16  => "8KB",
    32  => "16KB",
    64  => "32KB",
    128 => "64KB",
    256 =>  "128KB",
    512 =>  "256KB",
    1024    =>  "512KB",
    2048    =>  "1MB",
    4096    => "2MB",
    8192    => "4MB",
    16384   => "8MB",
    32768   =>  "16MB",
);

our %mediatype = (
    0   =>  'Unknown',
    1   =>  'HDD',
    2   =>  'SSD',
);

our %readpolicy = (
    0   => 'Unknown',
    16  => 'No Read Ahead',
    32  =>  'Read Ahead',
    64  =>  'Adaptive Read Ahead',
);

our %layout = (
    1       =>  'No RAID',
    2       =>  'RAID-0',
    4   =>  'RAID-1',
    64  =>  'RAID-5',
    128 =>  'RAID-6',
    2048 => 'RAID-10',
    8192    =>  'RAID-50',
    16384   =>  'RAID-60',
);

our %vir_disk_raidstate = (
    0   =>  "Unknown", 
    1   =>  "Ready", 
    2   =>  "Online", 
    3   =>  "Foreign", 
    4   =>  "Offline",
    5   =>  "Blocked", 
    6   =>  "Failed", 
    7   =>  "Degraded", 
);


our %virdisk_enum = (
    StripeSize => \%stripsize,
    State => \%vir_disk_raidstate,
    MediaType => \%mediatype,
    WritePolicy   => \%writepolicy,
    ReadPolicy  => \%readpolicy,
    Layout  => \%layout,
);

our %virdisk_key_mapping = (
    profile_key => \%virdisk_profile_key_mapping,
);

our %complete_virdisk = (
    profile     =>  \%complete_virdisk_profile,
    keymapping  =>  \%virdisk_key_mapping,
    enums       =>  \%virdisk_enum,
);

#############################################################
#  Physical Disk related values 
############################################################

our @phydisk_selector_array = ('__cimnamespace','root/dcim');

our %phydisk_profile = (
    uri => 'DCIM_PhysicalDiskView',
    filter_value => "select * from DCIM_PhysicalDiskView where PrimaryStatus != 0 and RollupStatus != 0",
    selector => \@phydisk_selector_array,
    merge_attribute => 'InstanceID',
);

our %complete_phydisk_profile = (
    profile => \%phydisk_profile,
);

our %phydisk_profile_key_mapping = (
    'DeviceDescription' => 'FQDD',
    'RaidStatus'        => 'State',
    'PrimaryStatus'     => 'Status',
    'Model'             => 'ProductID',
    'SerialNumber'      => 'SerialNo',
    'SizeInBytes'       => 'Size(GB)',
    'MediaType'         => 'MediaType',
    'FreeSizeInBytes'   => 'FreeSpace(GB)',
    'Revision'          => 'FirmwareVersion',
);

our %phydisk_key_mapping = (
    profile_key => \%phydisk_profile_key_mapping,
);

our %phydiskmediatype = (
    0 => 'HDD',
    1   => 'SSD',
);

our %phydiskRaidStatus =(
    0   =>  "Unknown", 
    1   =>  "Ready", 
    2   =>  "Online", 
    3   =>  "Foreign", 
    4   =>  "Offline",
    5   =>  "Blocked", 
    6   =>  "Failed", 
    7   =>  "Degraded", 
    8   =>  "Non-RAID", 
    9   =>  "Removed" 
);


our %phydisk_enum = (
    State => \%phydiskRaidStatus,
    MediaType => \%phydiskmediatype,
);

our %complete_phydisk = (
    profile     =>  \%complete_phydisk_profile,
    keymapping  =>  \%phydisk_key_mapping,
    enums       =>  \%phydisk_enum,
);

#############################################################
# Power Supply related values 
############################################################

our @powersupply_selector_array = ('__cimnamespace','root/dcim');

our %powersupply_profile = (
    uri => 'DCIM_PowerSupplyView',
    filter_value => "select DeviceDescription,PrimaryStatus,TotalOutputPower,InputVoltage,Range1MaxInputPower,FirmwareVersion,RedundancyStatus from DCIM_PowerSupplyView where DetailedState != 'Absent' and PrimaryStatus != 0", 
    selector => \@powersupply_selector_array,
    merge_attribute => 'InstanceID',
);



our %complete_powersupply_profile = (
    profile1 => \%powersupply_profile,
);

our %powersupply_overall_health_profile = (
    uri => 'DCIM_SystemView',
    selector => \@powersupply_selector_array,
    filter_value => "select PSRollupStatus from DCIM_SystemView",
);


our %powersupply_profile_key_mapping = (
    'DeviceDescription'     => 'FQDD',
    'PrimaryStatus'         => 'Status',
    'TotalOutputPower'      => 'OutputWattage(W)',
    'InputVoltage'          => 'InputVoltage(V)',
    'Range1MaxInputPower'   => 'InputWattage(W)',
    'FirmwareVersion'       => 'FirmwareVersion',
    'RedundancyStatus'      => 'Redundancy',
);

our %powersupply_overallhealth_key_mapping = (
    status => 'PSRollupStatus' ,
);

our %powersupply_key_mapping = (
    profile_key => \%powersupply_profile_key_mapping,
	overallhealthkey => \%powersupply_overallhealth_key_mapping,
);


our %powersupply_redundancy =(
    0       =>  'Unknown',
    1       =>  'DMTF Reserved',
    2       =>  'Fully Redundant',
    3       =>  'Degraded Redundancy',
    4       =>  'Redundancy Lost',
    5       =>  'Overall Failure',
);

our %powersupply_enum = (
    Redundancy => \%powersupply_redundancy,
);

our %complete_powersupply = (
    profile         => \%complete_powersupply_profile,
	overallHealth   => \%powersupply_overall_health_profile,
    keymapping      => \%powersupply_key_mapping,
    enums           => \%powersupply_enum,
);

#############################################################
# Intrusion related values 
############################################################

our @int_selector_array = ('__cimnamespace','root/dcim');

our %int_profile = (
    uri => 'DCIM_Sensor',
    filter_value => "select DeviceID,ElementName,HealthState,EnabledState,CurrentState from DCIM_Sensor where SensorType = 16", 
    selector => \@int_selector_array,
    merge_attribute => 'DeviceID',
);

our %complete_int_profile = (
    profile1 => \%int_profile,
);

our %int_profile_key_mapping = (
    'ElementName'       => 'Location',
    'EnabledState'      => 'State',
    'HealthState'       => 'Status',
    'CurrentState'      => 'Reading', 
);

our %int_key_mapping = (
    profile_key => \%int_profile_key_mapping,
);

our %int_enum = (
    State => \%sensor_state,
);

our %complete_int = (
    profile =>  \%complete_int_profile,
    keymapping => \%int_key_mapping,
    enums =>    \%int_enum,
);


#############################################################
# Temperature related values 
############################################################

our @temp_selector_array = ('__cimnamespace','root/dcim');

our %temp_profile = (
    uri => 'DCIM_NumericSensor',
    filter_value => "select DeviceID,ElementName,HealthState,EnabledState,CurrentReading from DCIM_NumericSensor where SensorType = 2", 
    selector => \@temp_selector_array,
    merge_attribute => 'DeviceID',
);

our %complete_temp_profile = (
    profile => \%temp_profile,
);

our %temp_overall_health_profile = (
    uri => 'DCIM_SystemView',
    selector => \@temp_selector_array,
    filter_value => "select  TempRollupStatus from DCIM_SystemView",
);

our %temp_profile_key_mapping = (
    'ElementName'       => 'Location',
    'EnabledState'      => 'State',
    'HealthState'       => 'Status',
    'CurrentReading'    => 'Reading(degree Celsius)', 
);

our %temp_overallhealth_key_mapping = (
    status => 'TempRollupStatus' ,
);

our %temp_key_mapping = (
    profile_key => \%temp_profile_key_mapping,
	overallhealthkey => \%temp_overallhealth_key_mapping,
);

our %temp_enum = (
    State => \%sensor_state,
);
our %complete_temp = (
    profile =>  \%complete_temp_profile,
	overallHealth => \%temp_overall_health_profile,
    keymapping => \%temp_key_mapping,
    enums =>   \%temp_enum,
);

#############################################################
# Amperage related values 
############################################################

our @amp_selector_array = ('__cimnamespace','root/dcim');

our %amp_profile = (
    uri => 'DCIM_PSNumericSensor',
    filter_value => "select DeviceID,BaseUnits,ElementName,HealthState,EnabledState,CurrentReading from DCIM_PSNumericSensor where SensorType = 13", 
    selector => \@amp_selector_array,
    merge_attribute => 'DeviceID',
);

our %complete_amp_profile = (
    profile => \%amp_profile,
);

our %amp_profile_key_mapping = (
    'ElementName'      => 'Location',
    'EnabledState'     => 'State',
    'HealthState'      => 'Status',
    'CurrentReading'   => 'Reading', 
    'BaseUnits'        => 'BaseUnits',
);

our %amp_key_mapping = (
    profile_key => \%amp_profile_key_mapping,
);

our %amp_enum = (
    State => \%sensor_state,
);
our %complete_amp = (
    profile =>  \%complete_amp_profile,
    keymapping => \%amp_key_mapping,
    enums =>   \%amp_enum,
);


#############################################################
# Battery related values 
############################################################

our @bat_selector_array = ('__cimnamespace','root/dcim');

our %bat_profile = (
    uri => 'DCIM_Sensor',
    filter_value => "select DeviceID,ElementName,HealthState,EnabledState,CurrentState from DCIM_Sensor where SensorType = 1 and OtherSensorTypeDescription = 'Battery'", 
    selector => \@bat_selector_array,
    merge_attribute => 'DeviceID',
);

our %complete_bat_profile = (
    profile => \%bat_profile,
);

our %bat_overall_health_profile = (
    uri => 'DCIM_SystemView',
    selector => \@bat_selector_array,
    filter_value => "select BatteryRollupStatus from DCIM_SystemView",
);

our %bat_profile_key_mapping = (
    'ElementName'      => 'Location',
    'EnabledState'     => 'State',
    'HealthState'      => 'Status',
    'CurrentState'     => 'Reading', 
);

our %bat_overallhealth_key_mapping = (
    status => 'BatteryRollupStatus' ,
);

our %bat_key_mapping = (
    profile_key => \%bat_profile_key_mapping,
	overallhealthkey => \%bat_overallhealth_key_mapping,
);

our %bat_enum = (
    State => \%sensor_state,
);
our %complete_bat = (
    profile =>  \%complete_bat_profile,
	overallHealth => \%bat_overall_health_profile,
    keymapping => \%bat_key_mapping,
    enums =>   \%bat_enum,
);


#############################################################
# SD card  related values 
############################################################

our @sd_selector_array = ('__cimnamespace','root/dcim');

our %sd_profile1 = (
    uri             => 'DCIM_VFlashView',
    filter_value    => "select DeviceDescription,HealthStatus,VFlashEnabledState,WriteProtected,InitializedState,Capacity,AvailableSize from DCIM_VFlashView", 
    selector        => \@sd_selector_array,
    merge_attribute => 'InstanceID',
);


our %complete_sd_profile = (
    profile1 => \%sd_profile1,
);

our %sd_profile_key_mapping = (
    'DeviceDescription'     => 'FQDD',
    'WriteProtected'        => 'WriteProtected',
    'HealthStatus'          => 'Status',
    'VFlashEnabledState'    => 'State', 
    'InitializedState'      => 'InitializedState',
    'Capacity'              => 'Size(GB)',
    'AvailableSize'         => 'AvailableSpace(GB)',
);

our %sd_key_mapping = (
    profile_key => \%sd_profile_key_mapping,
);

our %sd_state = (
    true => 'Enable',
    false => 'Disable',

);

our %WriteProtected_state = (
    true => 'True',
    false => 'False',
);


our %sd_enum = (
    State => \%sd_state,
	WriteProtected => \%WriteProtected_state, 
);

our %complete_sd = (
    profile =>  \%complete_sd_profile,
    keymapping => \%sd_key_mapping,
    enums =>   \%sd_enum,
);


#############################################################
# All Attribute in a hash with its references.
############################################################
our %main_profile = (
        'cpu'           => \%complete_cpu,
        'memory'        => \%complete_mem,
        'fan'           => \%complete_fan,
        'ghs'           => \%complete_ghs,
        'voltage'       => \%complete_voltage,
        'nic'           => \%complete_nic,
        'ctl'           => \%complete_DiskCtl,
        'virdisk'       => \%complete_virdisk,
        'powersupply'   => \%complete_powersupply,
        'intrusion'     => \%complete_int,
        'phydisk'       => \%complete_phydisk,
        'temperature'   => \%complete_temp,
        'amperage'      => \%complete_amp,
		'battery'       => \%complete_bat,
		'sd'            => \%complete_sd,
        'fcnic'         => \%complete_fcnic,
    );


#############################################################
#  Server Information related values 
############################################################

our @serverinfo_selector_array = ('__cimnamespace','root/dcim');
our %system_view_profile = (
    uri => 'DCIM_SystemView',
    filter_value => " select ServiceTag, Model, NodeId , ChassisServiceTag, SystemGeneration from DCIM_SystemView ",
    selector => \@serverinfo_selector_array,
    key_attribute => undef, 
    merge_attribute => 'InstanceID',
);

our %idrac_card_view_profile = (
    uri => 'DCIM_iDRACCardView',
    filter_value => " select DNSRacName, FirmwareVersion, URLString from DCIM_iDRACCardView ", 
    selector => \@serverinfo_selector_array,
    key_attribute => undef,
    merge_attribute => 'InstanceID',
);

our %system_string_profile = (
    uri => 'DCIM_SystemString',
    filter_value => " select AttributeName, CurrentValue  from DCIM_SystemString where AttributeName= 'OSVersion' or AttributeName='HostName' or AttributeName='OSName' ", 
    selector => \@serverinfo_selector_array,
    key_attribute => "AttributeName",
    merge_attribute => 'InstanceID',
);

our @server_information_profile = (\%system_view_profile, \%system_string_profile, \%idrac_card_view_profile);

#---------------------------------------------------------------------
# Functions
#---------------------------------------------------------------------

##################################################################
# Func: wsman_initialize 
# Input: No input
# outout: No Output
# Description :  This function intializes the wsman session object
#                which will be used for making wsman querries. 
##################################################################
sub wsman_initialize {
    my $flag = 0;
    my $temp_username;
    my $temp_password;
    my %param
      = (
        'hostname'         => $opt{hostname},
        'username'         => undef,
        'password'         => undef,
        'timeout'          => undef,
        'port'             => undef,
        'certificateCheck' => undef,

    );
    
    # Try to initialize the wsman session
    #  Creating option object 
    $option = new openwsman::ClientOptions::()
        or  $flag = 1;
    if ($flag == 1) {
        print "Error while creating Wsman Session: ";
        log_msg("CRITICAL ","Error while creating Wsman clientoption Session.\n");
        exit $UNKNOWN;
    } else {
		log_msg("INFO ","Success while creating Wsman clientoption Session.\n");
	}

    
    my $filename = undef;
    my @wsman_params;

    if (defined $opt{'filepath'}) {
        $filename = $opt{'filepath'};
    }elsif(defined $opt{servicename}){
        my $file_check  = $nagioshomedir . "/dell/config/objects/" . $opt{hostname} . ".cfg";
        if( -e $file_check) {
            $filename = $file_check;
        } else {
            my $fqdnName = gethostbyaddr(inet_aton("$opt{hostname}"), AF_INET);
            $file_check = $nagioshomedir . "/dell/config/objects/" . $fqdnName . ".cfg";
            if ( -e $file_check) {
                $filename = $file_check;
            }
        }
    }

    my $row_counter = 0;

    if (defined $filename){   
        if(open(my $fh, "<", $filename) ) {
            log_msg("INFO ", "Success in opening the wsman file $filename\n");
            while (my $row = <$fh>) {
                chomp $row;
                if(index($row, "action_url") != -1){
                    $row =~ s/\s//g;
                    $row = substr($row,length("action_url"));
                    $consoleurl = $row; 
                    $row_counter = $row_counter + 1 ;
                } elsif(index($row, "_dell_comm_params") != -1){
                    $row =~ s/\s//g;
                    $row = substr($row,17);
                    @wsman_params = split(',',$row);
                }
                
                if( $row_counter == 2 ){
                        last;
                }
            }
            if($wsman_params[0] eq 'WSMAN'){
                $temp_username              = $wsman_params[1];
                $temp_password              = $wsman_params[2];
                $param{'timeout'}           = $wsman_params[3];
                $param{'port'}              = $wsman_params[4];
                $param{'certificateCheck'}  = $wsman_params[5];
                $retries                    = $wsman_params[6];
            }  else {
                print "CRITICAL: Internal Error - Invalid wsman params\n";
                log_msg("CRITICAL", "Internal Error - Invalid wsman params\n");
                exit $UNKNOWN;
            }
            my $resource_file = $nagioshomedir . "/dell/resources/dell_resource.cfg";
            my $name;
            my $value;

            if ( -e $resource_file){
                if(open(my $rfh, "<", $resource_file)){
                    while (my $resource_row = <$rfh> ) {
                        chomp $resource_row;
                        $resource_row =~ s/^\s+|\s+$//g; 
                        if ( ($resource_row !~ /^#/) && ($resource_row ne "") ){    # Ignore lines starting with # and blank lines
                            ($name, $value) = split (/=/, $resource_row);          # Split each line into name value pairs
                            $value =~ s/^\s+|\s+$//g;     # Remove spaces from both end
                            $name =~ s/^\s+|\s+$//g;
                            
                            
                            if ($name eq $temp_username){
								if ( $value ne "") {
									$param{'username'} = $value;
								} else {
									print "CRITICAL: Macro $name is not configured in the resource file: $filename\n";
									log_msg("CRITICAL", "Macro $name is not configured in the resource file: $filename\n");
									exit $UNKNOWN;
								}
                            }elsif ($name eq $temp_password){
								if ($value ne "" ){
									$param{'password'} = $value;
								} else {
									print "CRITICAL: Macro $name is not configured in the resource file: $filename\n";
									log_msg("CRITICAL", "Macro $name is not configured in the resource file: $filename\n");
									exit $UNKNOWN;
								}
							}
                        } 
                    }
                }else {
					print "CRITICAL: Error in opening resource file: $resource_file\n";
					log_msg("CRITICAL", "Error in opening resource file: $resource_file.\n");
					exit $UNKNOWN;
				}
            } else {
				print "CRITICAL: Missing resource file: $resource_file\n";
				log_msg("CRITICAL", "$resource_file not found.\n");
				exit $UNKNOWN;
			}
        } else {
            print "CRITICAL: Error in opening the file $filename\n";
            log_msg("CRITICAL", "Error in opening the file $filename\n");
            exit $UNKNOWN;
        }
    } else {
        print "CRITICAL: Filepath is invalid : $filename\n";
        log_msg("CRITICAL", "Filepath is invalid : $filename\n");
        exit $UNKNOWN;
    }
    
    my $calculated_timeout = ($param{'timeout'} * ($retries + 1) + 120);
    $plugin_timeout = $plugin_timeout > $calculated_timeout ? $plugin_timeout: $calculated_timeout ;

    $wsman_client = new openwsman::Client::($param{'hostname'},
                                               $param{'port'},
                                               '/wsman', 
                                               'https',
                                               $param{'username'},
                                               $param{'password'})

        or $flag = 1;
    if ($flag == 1) {
        print "Error while creating Wsman client Session";
        log_msg("CRITICAL ","Error while creating Wsman client Session.\n");
        exit $UNKNOWN;
    } else {
		log_msg("INFO ","Success while creating Wsman client Session.\n");
	}

    $filter = new openwsman::Filter::()
      or $flag = 1;
    if ($flag == 1) {
        print "Error while creating Wsman Filter Session";
        log_msg("CRITICAL ","Error while creating Wsman Filter Session.\n");
        exit $UNKNOWN;
    } else {
		log_msg("INFO ","Success while creating Wsman Filter Session.\n");
	}

    $wsman_client->transport()->set_auth_method($openwsman::BASIC_AUTH_STR);
    $wsman_client->transport()->set_timeout($param{'timeout'});

    if ($param{'certificateCheck'} == 0) {
        openwsman::wsman_transport_set_verify_peer($wsman_client, 0);
        openwsman::wsman_transport_set_verify_host($wsman_client, 0);
    }

    return;
}

sub get_wsman_result{
    my ($uri,$selector,$merge_attribute) = @_;
    my $final_uri = $fixed_uri . $uri  ;
    my $selector_counter = 0;

    for ($selector_counter = 0 ; $selector_counter <  $#{$selector} + 1   ; $selector_counter = $selector_counter + 2 ){
        $option->add_selector ($selector->[$selector_counter],$selector->[$selector_counter + 1 ] );
    }  
    my $result = $wsman_client->get($option,  $final_uri);
    unless($result && $result->is_fault eq 0) {
        if (( defined $result) and (defined $result->fault)) {
            print "WSMAN Error while retreiving data: ", $result->fault->reason ;
        } else {
            print "WSMAN Error while communicating with host $opt{'hostname'}";
        }
        log_msg("CRITICAL ","WSMAN Error while retreiving data\n");
        exit $UNKNOWN;
    }

    my $info = $result->body()->child();

    my $items;
    for((my $cnt = 0) ; ($cnt<$info->size()) ; ($cnt++)) {
        $items->{$info->get($cnt)->name()} = $info->get($cnt)->text();
    }

    foreach my $items_keys ( keys %{$items}){
        $temp_list{$items->{$merge_attribute}}->{$items_keys} = $items->{$items_keys};
    }

}




sub enumerate_wsman_result{
    my ($uri,$filter_query,$selector,$merge_attribute,$max_elements) = @_;
    my $result = undef;
    my $final_uri = $fixed_uri . $uri  ;
    my $selector_counter = 0;
    for ($selector_counter = 0 ; $selector_counter <  $#{$selector} + 1   ; $selector_counter = $selector_counter + 2 ){
        $option->add_selector ($selector->[$selector_counter],$selector->[$selector_counter + 1 ] );
    } 
    if (defined $max_elements) {
        $option->set_flags($openwsman::FLAG_ENUMERATION_OPTIMIZATION);
        $option->set_max_elements($max_elements);
    }

    my $count = 0;
    my $test_flag = 1;
    for ($count = 0; (($count < ($retries + 1)) and ($test_flag == 1)) ; $count = $count + 1){ 
        if( defined $filter_query){
            $filter->wql($filter_query);
            $result = $wsman_client->enumerate($option, $filter, $final_uri);
        } else {
            $result = $wsman_client->enumerate($option, undef, $final_uri);
        }

        unless($result && $result->is_fault eq 0) {

            $test_flag = 1;
            next;
        }
        $test_flag = 0;
        
    }
    if ($test_flag == 1){
        if (( defined $result) and (defined $result->fault)) {
                print "WSMAN Error while retreiving data: ", $result->fault->reason ;
                log_msg("CRITICAL ",$result->fault->reason);
            } else {
                print "WSMAN Error while communicating with host $opt{'hostname'}";
                log_msg("CRITICAL ","WSMAN Error while communicating with host $opt{'hostname'}");
        }
        exit $UNKNOWN;
    }
    
    my $nodes = $result->body()->find(undef, "Items");
    if (defined $nodes){
        my $node;
        for((my $cnt1 = 0) ; ($cnt1<$nodes->size()) ; ($cnt1++)) {
            my $items;
            $node = $nodes->get($cnt1);
            for((my $cnt2 = 0) ; ($cnt2<$node->size()) ; ($cnt2++)) {
                $items->{$node->get($cnt2)->name()} = $node->get($cnt2)->text();
            }
            foreach my $items_keys ( keys %{$items}){
                $temp_list{$items->{$merge_attribute}}->{$items_keys} = $items->{$items_keys};
            }
        }
    }

    # Get context.
    my $context = $result->context();

    while($context) {
        $result = $wsman_client->pull($option, $filter, $final_uri, $context);
        next unless($result);
        $nodes = $result->body()->find(undef, "Items");
        if (defined $nodes){
            my $node;
            for((my $cnt1 = 0) ; ($cnt1<$nodes->size()) ; ($cnt1++)) {
                my $items;
                $node = $nodes->get($cnt1);
                for((my $cnt2 = 0) ; ($cnt2<$node->size()) ; ($cnt2++)) {
                    $items->{$node->get($cnt2)->name()} = $node->get($cnt2)->text();
                }
                foreach my $items_keys ( keys %{$items}){
                    $temp_list{$items->{$merge_attribute}}->{$items_keys} = $items->{$items_keys};
                }
            }
        }
        $context = $result->context();
    }
    # Release context.
    $wsman_client->release($option, $uri, $context) if($context);

}



##################################################################
# Func: severity_arrange
# Input: severity name string, arranged snmp result hash 
# outout: Return an array of indexes based on severity.
# Description :  This function takes arranged snmp result hash and return
#                a array of indexes based on severity. 
##################################################################
sub severity_arrange {
    my ($severity_name, $component) = @_;
    my @finaloutput = ();
    my $all_unknown_index = 0;
    my $all_ok_index = 0;
    my $all_critical_index = 0;
    my $all_warn_index = 0;

	
    if (($component eq 'voltage') ||
        ($component eq 'intrusion') ||
        ($component eq 'battery') ||
        ($component eq 'amperage') ||
		($component eq 'temperature') ) {
        foreach my $eachInstance (keys %list){
            if ($list{$eachInstance}{$severity_name} == 0){
                # All Unknown instances to index[0]  
                $list{$eachInstance}{$severity_name} = 3;
                $finaloutput[0][$all_unknown_index] = $eachInstance;
                $all_unknown_index = $all_unknown_index + 1;
            }elsif( $list{$eachInstance}{$severity_name} == 5) {
                # All Ok status Index[1]
                $list{$eachInstance}{$severity_name} = 0;
                $finaloutput[1][$all_ok_index] = $eachInstance;
                $all_ok_index = $all_ok_index + 1;
            } elsif (($list{$eachInstance}{$severity_name} == 10)) {
                # All Wanring Status Index[2] 
                $list{$eachInstance}{$severity_name} = 1;
                $finaloutput[2][$all_warn_index] = $eachInstance;
                $all_warn_index = $all_warn_index + 1;
            } else {
                # All CRITICAL Status Index[3]
                $list{$eachInstance}{$severity_name} = 2;
                $finaloutput[3][$all_critical_index] = $eachInstance;
                $all_critical_index = $all_critical_index + 1;
            }
        }    

    } else {
        foreach my $eachInstance (keys %list){
            if (($list{$eachInstance}{$severity_name}) == 0){
                # All Unknown instances to index[0]  
                if ($component eq 'nic'){
                    $list{$eachInstance}{$severity_name} = 'Unknown';
                    $finaloutput[0][$all_unknown_index] = $eachInstance;
                    $all_unknown_index = $all_unknown_index + 1;
                } elsif ($component eq 'fcnic'){
                # FC NIC mapping [0-Down, 1-Up, 2-Unknown] 
                    $list{$eachInstance}{$severity_name} = 'Down';
                    $finaloutput[3][$all_critical_index] = $eachInstance;
                    $all_critical_index = $all_critical_index + 1;
                } else {
                    $list{$eachInstance}{$severity_name} = 3;
                    $finaloutput[0][$all_unknown_index] = $eachInstance;
                    $all_unknown_index = $all_unknown_index + 1;
                }
            }elsif( $list{$eachInstance}{$severity_name} == 1) {
                # All Ok status Index[1]
                # FC NIC mapping [0-Down, 1-Up, 2-Unknown] 
                if ($component eq 'nic' || $component eq 'fcnic'){
                    $list{$eachInstance}{$severity_name} = 'UP';
                } else {
                    $list{$eachInstance}{$severity_name} = 0;
                }
                $finaloutput[1][$all_ok_index] = $eachInstance;
                $all_ok_index = $all_ok_index + 1;
            } elsif (($list{$eachInstance}{$severity_name} == 2)) {
                if ($component eq 'fcnic'){
                # FC NIC mapping [0-Down, 1-Up, 2-Unknown] 
                    $list{$eachInstance}{$severity_name} = 'Unknown';
                    $finaloutput[0][$all_unknown_index] = $eachInstance;
                    $all_unknown_index = $all_unknown_index + 1;
                } else {
                    # All Wanring Status Index[2] 
                    $list{$eachInstance}{$severity_name} = 1;
                    $finaloutput[2][$all_warn_index] = $eachInstance;
                    $all_warn_index = $all_warn_index + 1;
                }
            } else {
                # All CRITICAL Status Index[3]
                if ($component eq 'nic'){
                    $list{$eachInstance}{$severity_name} = 'DOWN';
                } else {
                    $list{$eachInstance}{$severity_name} = 2;
                }
                $finaloutput[3][$all_critical_index] = $eachInstance;
                $all_critical_index = $all_critical_index + 1;
            }
        }    

    }

    return \@finaloutput;

}

##################################################################
# Func: severity_arrange_on_string
# Input: severity name string, arranged snmp result hash 
# outout: Return an array of indexes based on severity.
# Description :  This function takes arranged snmp result hash and return
#                a array of indexes based on severity. 
##################################################################
sub severity_arrange_on_string {
    my ($severity_name, $component) = @_;
    my @finaloutput = ();
    my $all_unknown_index = 0;
    my $all_ok_index = 0;
    my $all_critical_index = 0;
    my $all_warn_index = 0;

    foreach my $eachInstance (keys %list){
        if (exists $list{$eachInstance}{$severity_name}){
            if (lc($list{$eachInstance}{$severity_name}) eq 'unknown'){
                # All Unknown instances to index[0]  
                $list{$eachInstance}{$severity_name} = 3;
                $finaloutput[0][$all_unknown_index] = $eachInstance;
                $all_unknown_index = $all_unknown_index + 1;
            }elsif( lc($list{$eachInstance}{$severity_name}) eq 'ok') {
                # All Ok status Index[1]
                $list{$eachInstance}{$severity_name} = 0;
                $finaloutput[1][$all_ok_index] = $eachInstance;
                $all_ok_index = $all_ok_index + 1;
            } elsif (lc($list{$eachInstance}{$severity_name}) eq 'warning') {
                # All Warning Status Index[2] 
                $list{$eachInstance}{$severity_name} = 1;
                $finaloutput[2][$all_warn_index] = $eachInstance;
                $all_warn_index = $all_warn_index + 1;
            } else   {
                # All CRITICAL Status Index[3]
                $list{$eachInstance}{$severity_name} = 2;
                $finaloutput[3][$all_critical_index] = $eachInstance;
                $all_critical_index = $all_critical_index + 1;
            }
        }
    }    
    return \@finaloutput;
}

##################################################################
# Func :         my_printing
# Input:         severity_array, arranged result hash, component name, severity name, 
# Output:        NO output
# Description :  This function prints all the instances of the component 
#                by iterating through the array and hash. 
# 
##################################################################

sub my_printing { 
    my ($sevArray, $component,$component_descriptor,$severity_name) = @_;
    my $severity;
    my $severity_index = 0;
    my $check_enum_flag = 0;
    my $instance_count = 1;
    for ($severity = 3 ; $severity >= 0; $severity-- ) {
        if (exists $sevArray->[$severity]){
            for ($severity_index = 0 ; exists $sevArray->[$severity][$severity_index]; $severity_index++){ 
                $printmsg = $printmsg . "#$instance_count ";
                my $print_index_key =  $sevArray->[$severity][$severity_index];
                if ($component eq 'nic' || $component eq 'fcnic'){
                    $printmsg = $printmsg .  "$severity_name = $list{$print_index_key}->{$severity_name}, ";
                } else {
                    $printmsg = $printmsg .  "$severity_name = $Nagios_ExitStatus_String_mapping{$list{$print_index_key}->{$severity_name}}, ";
                    
                }
                $printmsg = $printmsg .  "$component_descriptor = $list{$print_index_key}->{$component_descriptor}, ";
                delete $list{$print_index_key}->{$component_descriptor};
                delete $list{$print_index_key}->{$severity_name};

                if ( exists ($list{$print_index_key}->{'State'}) ) {
				    $printmsg = $printmsg . "State = $main_profile{$component}->{'enums'}->{'State'}->{$list{$print_index_key}->{'State'}}, ";
                    delete $list{$print_index_key}->{'State'}; 
                } 
                foreach my $list_key (sort keys %{$list{$print_index_key}}){
                    my $value_len = length($list{$print_index_key}->{$list_key});
                    if ($value_len != 0){
                        foreach my $enum_name (keys %{$main_profile{$component}->{'enums'}}){
                            if ($list_key eq $enum_name){     
                                if (exists $main_profile{$component}->{'enums'}->{$enum_name}->{$list{$print_index_key}->{$list_key}}){
                                    $printmsg = $printmsg . "$list_key = $main_profile{$component}->{'enums'}->{$enum_name}->{$list{$print_index_key}->{$list_key}}, ";
                                } else {
                                    $printmsg = $printmsg . "$list_key = Other($list{$print_index_key}->{$list_key}), "; 
                                }
                                $check_enum_flag = 1;
                                last;
                            }
                        }
                        if ($check_enum_flag != 1){
                            $printmsg = $printmsg . "$list_key = $list{$print_index_key}->{$list_key}, ";
                        }
                        $check_enum_flag = 0;
                    } else {
                        $printmsg = $printmsg . "$list_key = Not Available, ";
                    }
                }
                chop ($printmsg);
                chop ($printmsg);
                $printmsg = $printmsg . $nextline;
                $instance_count = $instance_count + 1;
            }
        }
    }
    $printmsg = substr ($printmsg, 0, -4);
}

sub  overall_health_status{
    my ($component,$max_elements) = @_;
    
    my $temp_profile = $main_profile{$component}->{'overallHealth'};
    my $temp_uri = $fixed_uri . $temp_profile->{'uri'};
    enumerate_wsman_result($temp_profile->{'uri'},
                           $temp_profile->{'filter_value'},  
                           $temp_profile->{'selector'},
                           'InstanceID',
                           $max_elements);
}

##################################################################
# Func:         get_Component_Status
# Input:        Component name, Severity name, overall health check flag 
# Output:       No output.
# Description:  Main function which is getting callled by each component
#               and calling other function to display the status 
#               of the component.
##################################################################
sub get_Component_Status {
	log_msg("INFO ","WSMAN query started for IP $opt{hostname}\n");
    my ($component,$component_descriptor, $severity_name,$operation,$max_elements,$check_overall_health) = @_;
    my %output = ();
    my @severity_array = ();

    my $final_uri = undef;
    my  $profiles  = $main_profile{$component}->{'profile'};
    foreach ( keys %{$profiles}){
	
        my $profile = $_;

        if($operation eq 'get'){
            get_wsman_result($profiles->{$profile}->{'uri'},
                         $profiles->{$profile}->{'selector'}, 
                         $profiles->{$profile}->{'merge_attribute'});

        } elsif ($operation eq 'Enumerate') {
            enumerate_wsman_result($profiles->{$profile}->{'uri'},
                         $profiles->{$profile}->{'filter_value'},
                         $profiles->{$profile}->{'selector'}, 
                         $profiles->{$profile}->{'merge_attribute'},
                         $max_elements);
        }             
    }
    
	log_msg("INFO ","Success in getting all attribute value for component $component\n");
	
    if( !%temp_list){
        print "Component Information = UNKNOWN";
        exit $UNKNOWN;
    }
	
    foreach my $delete_key ( keys %temp_list) {
        if (defined $temp_list{$delete_key}->{'InstanceID'}){
            delete $temp_list{$delete_key}->{'InstanceID'};
        }
    }


   
    my $sd_flag =0;
    foreach my $item_instance ( keys %temp_list){
	
        foreach my $key_instance ( keys %{$temp_list{$item_instance}}){
            if (defined $main_profile{$component}->{'keymapping'}->{'profile_key'}->{$key_instance}){
                my $value = $temp_list{$item_instance}->{$key_instance};
                # Triming white spaces from both side of the value.
                $value =~ s/^\s+|\s+$//g;
                if (length($value) != 0 ){
                    $list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'profile_key'}->{$key_instance}}= $value;
                }
            }
        }
        if (($component eq 'sd') and
            (defined $list{$item_instance}->{'FQDD'}) and 
            (defined $list{$item_instance}->{'Status'} == 0)) {
            $list{$item_instance}->{'Status'} = 'unknown';
        }
    }
 
    if ($component eq 'memory'){
        foreach my $meminstance ( keys %list){
            if ( exists $list{$meminstance}->{'Size(GB)'} ){  
                $list{$meminstance}->{'Size(GB)'} = sprintf '%.2f', $list{$meminstance}->{'Size(GB)'}/1024.00;   
            }
        }
    } elsif ($component eq 'virdisk'){
        foreach my $meminstance ( keys %list){
            if (exists $list{$meminstance}->{'Size(GB)'}) {
                $list{$meminstance}->{'Size(GB)'} = sprintf '%.2f', $list{$meminstance}->{'Size(GB)'}/(1024.00 * 1024 * 1024 );   
            }
        }
    } elsif ($component eq 'phydisk') {
        foreach my $meminstance ( keys %list){
            if (exists  $list{$meminstance}->{'Size(GB)'} ) {
                $list{$meminstance}->{'Size(GB)'} = sprintf '%.2f', $list{$meminstance}->{'Size(GB)'}/(1024.00 * 1024 * 1024 );   
            }
            if (exists $list{$meminstance}->{'FreeSpace(GB)'}) {
                $list{$meminstance}->{'FreeSpace(GB)'} = sprintf '%.2f', $list{$meminstance}->{'FreeSpace(GB)'}/(1024.00 * 1024 * 1024 );   
            }
        }
    }elsif ($component eq 'temperature') {
	    foreach my $instance ( keys %list){
            if (exists $list{$instance}->{'Reading(degree Celsius)'} ) {
				if($list{$instance}->{'Status'} == 0){
					$list{$instance}->{'Reading(degree Celsius)'} = "Not Available";   
				} else {
					$list{$instance}->{'Reading(degree Celsius)'} = sprintf '%.2f', $list{$instance}->{'Reading(degree Celsius)'}/(10.0);   
				}
            }
        }
    }elsif ($component eq 'sd') {
	    foreach my $instance ( keys %list){
            if ( exists $list{$instance}->{'Size(GB)'}){
                $list{$instance}->{'Size(GB)'} = sprintf '%.2f', $list{$instance}->{'Size(GB)'}/(1024.0);   
            }
            if ( exists $list{$instance}->{'AvailableSpace(GB)'}){
                $list{$instance}->{'AvailableSpace(GB)'} = sprintf '%.2f', $list{$instance}->{'AvailableSpace(GB)'}/(1024.0);   
            }
        }
    } elsif ($component eq 'amperage') {
        foreach my $instance ( keys %list){
		
		if (exists $list{$instance}->{'Reading'}){
                if (exists $list{$instance}->{'BaseUnits'}) {
                    if($list{$instance}->{'BaseUnits'} == 6 ){
						if($list{$instance}->{'Status'} == 0){
							$list{$instance}->{'Reading(A)'} = "Not Available";   
						} else {
							$list{$instance}->{'Reading(A)'} = sprintf '%.2f', $list{$instance}->{'Reading'} / 10;
						}
                    } elsif ($list{$instance}->{'BaseUnits'} == 7 ){
						if($list{$instance}->{'Status'} == 0){
							$list{$instance}->{'Reading(W)'} = "Not Available";   
						} else {
							$list{$instance}->{'Reading(W)'} = $list{$instance}->{'Reading'};
						}
                    }
                    delete $list{$instance}->{'Reading'};
                    delete $list{$instance}->{'BaseUnits'};
                }
            }
        }
	}  elsif ($component eq 'cpu') {
        foreach my $instance ( keys %list){
            if (exists $list{$instance}->{'CurrentSpeed(GHz)'}) {
                $list{$instance}->{'CurrentSpeed(GHz)'} = sprintf '%.2f', $list{$instance}->{'CurrentSpeed(GHz)'}/(1000.0);   
            }
        }
    } elsif ($component eq 'voltage') {
        foreach my $instance ( keys %list){
            if (exists $list{$instance}->{'Reading(V)'} && $list{$instance}->{'Status'} == 0 ) {
                $list{$instance}->{'Reading(V)'} = "Not Available";   
            }
        }
    }


    my $ghs_hash;

    if ( $component eq 'ghs' ){
        foreach my $instance ( keys %list){
            $ghs_hash = $list{$instance}; #converting two dimensional hash to one dimension
        }
        $final_exit_code  = $wsman_status{$ghs_hash->{'Overall System'}}; 
        $printmsg = "Overall System = $Nagios_ExitStatus_String_mapping{$wsman_status{$ghs_hash->{'Overall System'}}}$nextline";
        delete $ghs_hash->{'Overall System'};
        for my $ghs_key (sort {$ghs_hash->{$b} cmp $ghs_hash->{$a}} keys %{$ghs_hash}) {
            if (($ghs_hash->{$ghs_key} == 1 ) or ($ghs_hash->{$ghs_key} == 2 ) or ($ghs_hash->{$ghs_key} == 3))  {
                $printmsg = $printmsg . "$ghs_key = $Nagios_ExitStatus_String_mapping{$wsman_status{$ghs_hash->{$ghs_key}}}$nextline";
            }
        }
        $printmsg = substr ($printmsg, 0, -4);

    } else {
		if ($component eq 'sd'){
			@severity_array =  @{severity_arrange_on_string($severity_name,$component)};
		} else {
			
			@severity_array =  @{severity_arrange($severity_name,$component)};
		
		}
		log_msg("INFO ","Success in arranging $component instance on severity basis.\n");
		
		my_printing(\@severity_array,$component,$component_descriptor,$severity_name);

		
        %list = ();
        %temp_list = ();
        
        if($check_overall_health == 1){
            my $status; 
            overall_health_status($component,$max_elements);
            foreach my $item_instance ( keys %temp_list){
                foreach my $key_instance ( keys %{$temp_list{$item_instance}}){
                   $status =  $temp_list{$item_instance}->{$main_profile{$component}->{'keymapping'}->{'overallhealthkey'}->{'status'}};
                    last;
                }
                last;
            }
			
            if($status == 3) {
                $final_exit_code = $CRITICAL;
			} elsif($status == 1){
                $final_exit_code = $OK;
            }elsif($status == 2) {
                $final_exit_code = $WARNING;
            } else {
                $final_exit_code = $UNKNOWN;
            }
			
        } elsif ($check_overall_health == 0) {
            if(defined $severity_array[3][0]){
				$final_exit_code = $CRITICAL;
			} elsif (defined  $severity_array[2][0]) {
				$final_exit_code = $WARNING;
			} elsif (defined  $severity_array[1][0]) {
				$final_exit_code = $OK;
			} else {
				$final_exit_code = $UNKNOWN;
            }
        }

    }
	
    log_msg("INFO ","Overall Status for $component = $Nagios_ExitStatus_String_mapping{$final_exit_code}\n");
    if(defined $opt{servicename}){
        my $command = $nagioshomedir . "/libexec/eventhandlers/submit_check_result " .  $opt{hostname} . q{ } . "\"" .$opt{servicename}."\""  . q{ } . $final_exit_code . q{ } . "\"" . $printmsg . "\"";
        system($command);
    } else {
        print $printmsg;
		log_msg("INFO ","...Service is FINISHED for the IP $opt{'hostname'} and component $opt{'component'}...\n\n");
        exit $final_exit_code;
    }
	

}

sub get_Server_Information{
    foreach my $profile ( @server_information_profile ){
        enumerate_wsman_result($profile->{'uri'},
                               $profile->{'filter_value'},
                               $profile->{'selector'}, 
                               $profile->{'merge_attribute'});
        update_Server_Information($profile->{'key_attribute'});    
    }

    print_server_info();
    exit $OK;
}

sub update_Server_Information{

    my ($key_attribute) = @_;
    foreach my $key ( keys %temp_list){
        my $temp_hash = $temp_list{$key};     
        if( (defined $key_attribute) and  (defined $temp_hash->{$key_attribute})){
            $list{$temp_hash->{$key_attribute}} = $temp_hash->{"CurrentValue"};
        }else {
            foreach my $keys ( keys %$temp_hash){
                if (($temp_hash->{$keys} ne "") && ($keys ne "InstanceID"))    {
                    $list{$keys} = $temp_hash->{$keys};
                }
            }
        }
    }
}


sub print_server_info {
    if ((defined $list{"HostName"}) and ( length($list{"HostName"}) ne 0)) {
        $printmsg = $printmsg . "Server Host FQDN = $list{'HostName'}$nextline" ;
    }else {
        $printmsg = $printmsg . "Server Host FQDN = Not Available$nextline";
    }

    if ((defined $list{"Model"}) and ( length($list{"Model"}) ne 0)) {
        $printmsg = $printmsg . "Model Name = $list{'Model'}$nextline";
    } else {
        $printmsg = $printmsg . "Model Name = Not Available$nextline";
    }

    if (defined $list{"SystemGeneration"} ) {
	    if ($list{"SystemGeneration"} =~ m/14G/i) {
            $printmsg = $printmsg . "Device Type = iDRAC9$nextline";
		}elsif ($list{"SystemGeneration"} =~ m/13G/i) {
            $printmsg = $printmsg . "Device Type = iDRAC8$nextline";
        } elsif ($list{"SystemGeneration"} =~ m/12G/i) {
            $printmsg = $printmsg . "Device Type = iDRAC7$nextline";
        } else {
            if (length($list{"SystemGeneration"}) ne 0) {
                $printmsg = $printmsg . "Device Type = iDRAC ($list{'SystemGeneration'})$nextline";
            }else {
                $printmsg = $printmsg . "Device Type = Not Available$nextline";
            }
        }
    }

    if ((defined $list{"ServiceTag"}) and ( length($list{"ServiceTag"}) ne 0)) {
        $printmsg = $printmsg . "Service Tag = $list{'ServiceTag'}$nextline";
    }else{
        $printmsg = $printmsg . "Service Tag = Not Available$nextline";
    }

    if ((defined $list{"NodeID"}) and (length($list{'NodeID'}) ne 0) and ($list{'NodeID'} ne $list{'ServiceTag'})){
        $printmsg = $printmsg . "Node Id = $list{'NodeID'}$nextline";
    }

    if (defined $list{"SystemGeneration"})  {
        if ( ($list{"SystemGeneration"} =~ m/Monolithic/i) || ($list{"SystemGeneration"} =~ m/DCS/i) ) {
            $printmsg = $printmsg . "Product Type = Monolithic$nextline";
        } elsif ($list{"SystemGeneration"} =~ m/Modular/i) {
            $printmsg = $printmsg . "Product Type = Modular$nextline";
            if ((defined $list{"ChassisServiceTag"}) and ( length($list{"ChassisServiceTag"}) ne 0))  {
                $printmsg = $printmsg . "Chassis Tag = $list{'ChassisServiceTag'}$nextline";
            } else {
                $printmsg = $printmsg . "Chassis Tag = Not Available$nextline";
            }
        } else {
            if (length($list{"SystemGeneration"}) ne 0){
                $printmsg = $printmsg . "Product Type = $list{'SystemGeneration'}$nextline";
            }else {
                $printmsg = $printmsg . "Product Type = Not Available$nextline";
            }
        }
    }

    if ((defined $list{"FirmwareVersion"}) and ( length($list{"FirmwareVersion"}) ne 0)) {
        $printmsg = $printmsg . "iDRAC Firmware Version = $list{'FirmwareVersion'}$nextline";
    } else {
        $printmsg = $printmsg . "iDRAC Firmware Version = Not Available$nextline";
    }

    if ((defined $list{"OSName"}) and ( length($list{"OSName"}) ne 0)) {
        $printmsg = $printmsg . "OS Name = $list{'OSName'}$nextline"
    }else {
        $printmsg = $printmsg . "OS Name = Not Available$nextline";
    }

    if ((defined $list{"OSVersion"}) and ( length($list{"OSVersion"}) ne 0)) {
        $printmsg = $printmsg . "OS Version = $list{'OSVersion'}$nextline";
    } else {
         $printmsg = $printmsg . "OS Version = Not Available$nextline";
    }

    $printmsg = $printmsg ."iDRAC URL = $consoleurl";

    print $printmsg;

}

############################################################
# MAIN Function
############################################################

# Initialize SNMP

log_msg("INFO ","...Service is STARTED for the IP $opt{'hostname'} and component $opt{'component'}...\n");
log_msg("INFO ", "Log initializing\n");
wsman_initialize();

# Setting timeout
$SIG{ALRM} = sub {
    print "PLUGIN TIMEOUT: dell_check_idrac_wsman.pl timed out after $plugin_timeout seconds$nextline";
    exit $UNKNOWN;
};

alarm $plugin_timeout;

# Check Arguments
if (defined $opt{'component'}){
    if(lc$opt{'component'} eq 'cpu'){
        get_Component_Status('cpu','FQDD', 'Status','Enumerate',$max_elements_map{'average_max_element'},$check_overall_health{'yes'});
    } elsif(lc$opt{'component'} eq 'mem'){
        get_Component_Status('memory','FQDD', 'Status','Enumerate',$max_elements_map{'maximum_max_element'},$check_overall_health{'yes'});
    } elsif(lc$opt{'component'} eq 'fan'){
        get_Component_Status('fan','FQDD', 'Status','Enumerate',$max_elements_map{'average_max_element'},$check_overall_health{'yes'});
    } elsif(lc$opt{'component'} eq 'vlt'){
        get_Component_Status('voltage','Location', 'Status','Enumerate',$max_elements_map{'average_max_element'},$check_overall_health{'yes'});
    } elsif(lc$opt{'component'} eq 'ctl'){
        get_Component_Status('ctl','FQDD', 'Status','Enumerate',$max_elements_map{'average_max_element'},$check_overall_health{'no'});
    } elsif(lc$opt{'component'} eq 'vd'){
        get_Component_Status('virdisk','FQDD', 'Status','Enumerate',$max_elements_map{'maximum_max_element'},$check_overall_health{'no'});
    } elsif(lc$opt{'component'} eq 'ps'){
        get_Component_Status('powersupply','FQDD', 'Status','Enumerate',$max_elements_map{'average_max_element'},$check_overall_health{'yes'});
    } elsif(lc$opt{'component'} eq 'nic'){
        get_Component_Status('nic','FQDD', 'ConnectionStatus','Enumerate',$max_elements_map{'average_max_element'},$check_overall_health{'no'});
    } elsif(lc$opt{'component'} eq 'int'){
        get_Component_Status('intrusion','Location', 'Status','Enumerate',$max_elements_map{'lowest_max_element'},$check_overall_health{'no'});
    } elsif(lc$opt{'component'} eq 'pd'){
        get_Component_Status('phydisk','FQDD', 'Status','Enumerate',$max_elements_map{'maximum_max_element'},$check_overall_health{'no'});
    } elsif(lc$opt{'component'} eq 'temp'){
        get_Component_Status('temperature','Location', 'Status','Enumerate',$max_elements_map{'average_max_element'},$check_overall_health{'yes'});
	} elsif(lc$opt{'component'} eq 'amp'){
        get_Component_Status('amperage','Location', 'Status','Enumerate',$max_elements_map{'average_max_element'},$check_overall_health{'no'});
	} elsif(lc$opt{'component'} eq 'bat'){
        get_Component_Status('battery','Location', 'Status','Enumerate',$max_elements_map{'average_max_element'},$check_overall_health{'yes'});
	} elsif(lc$opt{'component'} eq 'sd'){
        get_Component_Status('sd','FQDD', 'Status','Enumerate',$max_elements_map{'average_max_element'},$check_overall_health{'no'});
	} elsif(lc$opt{'component'} eq 'ghs'){
        get_Component_Status('ghs','Status', 'Overall System','Enumerate',$max_elements_map{'lowest_max_element'},$check_overall_health{'no'});
    } elsif(lc$opt{'component'} eq 'info'){    
       get_Server_Information();
    } elsif(lc$opt{'component'} eq 'fcnic'){
        get_Component_Status('fcnic','FQDD', 'ConnectionStatus','Enumerate',$max_elements_map{'average_max_element'},$check_overall_health{'no'});
    } else {
        print "Invalid component name $opt{'component'}$nextline";
        log_msg ("CRITICAL", "Invalid component name $opt{'component'}\n");
    }
}

#-----------------------------------------------------------------
# Simple log-writing method
#-----------------------------------------------------------------

sub log_msg
{
    my ($severity,$message) = @_;

    my $tm = localtime(time);
    # time in following format : 2013-01-16 18:57:37 
    my $current_time = sprintf '%d-%02d-%02d %02d:%02d:%02d ', $tm->year + 1900, $tm->mon+1, $tm->mday, $tm->hour , $tm->min , $tm->sec;    
    
    eval
    {
        $message = $current_time . q{ } . $severity . q{ } . q{Dell_} . $opt{'component'} . q{ } . "_WSMAN " . $opt{'hostname'} . q{ } .  $message ;    

        if ($opt{opt_log})
        {
            open(FILE,">>$opt_logfile") ;
            print FILE "$message" or warn "Error writing $message to $opt_logfile: $!";
            close FILE;
        }
    };
    return 1;
}
