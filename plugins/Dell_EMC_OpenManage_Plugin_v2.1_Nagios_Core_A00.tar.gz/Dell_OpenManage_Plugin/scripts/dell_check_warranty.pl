#! /usr/bin/perl

##########################################################################
#Title:         Dell Device Plugin Script
#Version:       2.0 
#Creation Date: 15th Aug 2015
#Description:   This script provides Dell Device warranty information. 
#
#Copyright (c) 2015 Dell Inc.
#All Rights Reserved.
##########################################################################

use Getopt::Long qw(:config no_ignore_case);
use Time::localtime;
use File::Spec;

# Global (package) variables used throughout the code
use vars qw($OK $WARNING $CRITICAL $UNKNOWN $HELP);

use constant DELLRESOURCEFILE  => 'dell_pluginconfig.cfg';
our $plugin_timeout = 15;
our $printmsg = "";
our $final_exit_code = undef;
our $deviceServiceTag = undef;
our $criticalDays = undef;
our $warningDays = undef;
our $apiURL = undef;
our $criticalDaysDefault = 10;
our $warningDaysDefault = 30;
our $apiURLDefault = "https://api.dell.com/support/assetinfo/v4/getassetwarranty/";
our $printmsg = "";
our $final_exit_code = undef;
our $errorInput = "false";
our $javainstallpath = "java";
our $jarLocation = "";

#Exit Codes
$OK       = 0;
$WARNING  = 1;
$CRITICAL = 2;
$UNKNOWN  = 3;

sub get_warranty_info
{		
	param_initialize();
	my $command = "$javainstallpath -jar $jarLocation '$deviceServiceTag' $apiURL $criticalDays $warningDays";
	my $warrantyAPIOutput = `$command`;

	my @tempOutput = split('~~~',$warrantyAPIOutput);
	
	$printmsg = @tempOutput[1];
	
	if($errorInput ne "true"){
		my $tmpExitCode = @tempOutput[0];
		my @splittmpExitCode = split('=',$tmpExitCode);
		$final_exit_code = @splittmpExitCode[1];
	} else {
		$final_exit_code = $UNKNOWN;
	}
	
	print $printmsg;
	exit $final_exit_code;
}

	
# Help text
$HELP = <<'END_HELP';
Usage: dell_check_warranty.pl -H <HOSTNAME> [OPTION]...

OPTIONS:
    -i, 	--item      Component name.
	-svt, 	--svt       Device Service Tag.
	-F, 	--file      Host configuration file with absolute path 
OPTIONAL:
    -h, 	--help      Display this help text
END_HELP

# Options with default values
%opt = (
    'hostname'     => undef,
    'filepath'     => undef,
    'help'         => 0,
    'component'    => undef,
    'opt_log'      => 0,
    'serviceTag'   => undef,   
);

# Get options
GetOptions( 
    'H|hostname=s'      => \$opt{hostname},
    'F|file=s'          => \$opt{filepath},
    'h|help'            => \$opt{help},
    'i|item=s'          => \$opt{component},
    'l|log=i'           => \$opt{opt_log},
    'svt|serviceTag=s'  => \$opt{serviceTag},
) or do { 
    print $HELP; 
    exit $UNKNOWN; 
};


# If user requested help
if ($opt{'help'}) {
    print $HELP;
    exit $OK;
}

# Error if hostname option is not present
if ((!defined $opt{hostname}) and (!defined $opt{component}) )  {
    print $HELP;
    exit $UNKNOWN;
}

my $tm = localtime(time);
my $tm_month = sprintf "%02d",$tm->mon + 1;
my $tm_day = sprintf "%02d",$tm->mday;
my $tm_year = $tm->year + 1900;

my ($volume, $directory, $file) = File::Spec->splitpath(__FILE__);

our $opt_logfile = undef;
our $nagioshomedir = undef;
$jarLocation = $directory . "dell_OMC_Nagios_Warranty_v_2_0.jar";
my $config_cfg_path = $directory . "dellconfig.cfg";
if(-e $config_cfg_path) {
    my $log_path = undef;
    my $row = undef;
    if(open(my $fh,"<" , $config_cfg_path)) {
        while ($row  =  <$fh> ){
            chomp $row;
            if(index($row, "NAGIOS_HOME") != -1){
            $row =~ s/\s//g;
            $nagioshomedir = substr($row,12);
            }
			if(index($row, "JAVAINSTALLPATH") != -1){
            $row =~ s/\s//g;
            $javainstallpath = substr($row,16);
            }
        }
        $log_path = $nagioshomedir . "/var/dell/";
        if(!( -d $log_path )) {
            system ("mkdir -p $log_path");
        }
        $opt_logfile = $log_path . "WarrantyService_" . $tm_year . $tm_month  . $tm_day . ".dbg";
    } 
}
 
#---------------------------------------------------------------------
# Functions
#---------------------------------------------------------------------

##################################################################
# Func: param_initialize 
# Input: No input
# outout: No Output
# Description :  This function intializes the parameters and read
#				 Config file. 
##################################################################
sub param_initialize {
	
	if (defined $opt{'serviceTag'}) {
        $deviceServiceTag = $opt{'serviceTag'};
	}
	
	my ($volume, $directory, $file) = File::Spec->splitpath(__FILE__);
	my $resourceFile                = DELLRESOURCEFILE;
	my $dellResourceFile            = "$directory../resources/".$resourceFile;

    if (!-e $dellResourceFile) {
            print "Resource file $resourceFile does not exists. Exiting warranty plugin.\n";
            log_msg( "ERROR: Resource file $resourceFile does not exists. Exiting warranty plugin.");
            exit $UNKNOWN;
    } else {
	  
        $criticalDays = readConfigFile($dellResourceFile, 'RemainingDaysCritical');
		$warningDays = readConfigFile($dellResourceFile, 'RemainingDaysWarning');
		$apiURL = readConfigFile($dellResourceFile, 'WarrantyURL');

		if(length($warningDays) == 0) {
			log_msg("INFO: Invalid Configuration of 'RemainingDaysWarning' in Resource file $resourceFile. Setting defauly value $warningDaysDefault");
			$warningDays = $warningDaysDefault;
		}

		if(length($criticalDays) == 0) {
			log_msg("INFO: Invalid Configuration of 'RemainingDaysCritical' in Resource file $resourceFile. Setting defauly value $criticalDaysDefault");
			$criticalDays = $criticalDaysDefault;
		}
		
		if(length($apiURL) == 0) {
			log_msg("INFO: Invalid Configuration of 'WarrantyURL' in Resource file $resourceFile. Setting defauly value $apiURLDefault");
			$apiURL = $apiURLDefault;
		}

		#Validating RemainingDaysCritical negative and non numaric value
		if ($criticalDays =~ /^\d+?$/) {
			if ($criticalDays < 0) {
				log_msg("INFO: Invalid Configuration of 'RemainingDaysCritical' in Resource file $resourceFile. So service status will be UNKNOWN");
				$errorInput = "true";
				$criticalDays = 0;
				$warningDays = 0;
			}
		} else {
				log_msg("INFO: Invalid Configuration of 'RemainingDaysCritical' in Resource file $resourceFile. So service status will be UNKNOWN");
				$errorInput = "true";
				$criticalDays = 0;
				$warningDays = 0;
		}
	
		#Validating RemainingDaysWarning negative and non numaric value
		if ($warningDays =~ /^\d+?$/) {
			if ($warningDays < 0) {
				log_msg("INFO: Invalid Configuration of 'RemainingDaysWarning' in Resource file $resourceFile. So service status will be UNKNOWN");
				$errorInput = "true";
				$criticalDays = 0;
				$warningDays = 0;
			}
			
		} else {
				  log_msg("INFO: Invalid Configuration of 'RemainingDaysWarning' in Resource file $resourceFile. So service status will be UNKNOWN");
				  $errorInput = "true";
				  $criticalDays = 0;
				  $warningDays = 0;
			}
		
		if($criticalDays > '365') {
			log_msg( "INFO: RemainingDaysCritical Configuration more than 365 days in Resource file $resourceFile.So setting it as 365 days");
			$criticalDays = '365';
		}
		
		if($warningDays > '365') {
			log_msg( "INFO: RemainingDaysWarning Configuration more than 365 days in Resource file $resourceFile.So setting it as 365 days");
			$warningDays = '365';
		}
		
		if($criticalDays > $warningDays) {
			log_msg( "INFO: Invalid Configuration in Resource file $resourceFile,Now RemainingDaysWarning value will be treated as RemainingDaysCritical");
			$warningDays = $criticalDays;
		}
	}
}

#-----------------------------------------------------------------
# Function to read config file for single attribute
#-----------------------------------------------------------------

sub readConfigFile {
    my ($file, $configParamName) = @_;
    my $readLine;
    my $name; 
    our $value;       
    if  (-e $file)
    {
    open (CONFIG, "<", "$file");
        while (<CONFIG>) {
            $readLine=$_;
            chop ($readLine);          # Remove trailling \n
            $readLine =~ s/^\s*//;     # Remove spaces at the start of the line
            $readLine =~ s/\s*$//;     # Remove spaces at the end of the line
            if ( ($readLine !~ /^#/) && ($readLine ne "") ){    # Ignore lines starting with # and blank lines
                    ($name, $value) = split (/=/, $readLine);          # Split each line into name value pairs
                    $value =~ s/^\s*//;     # Remove spaces at the start of the line
                    $value =~ s/\s*$//;
            $name =~ s/^\s*//;
            $name =~ s/\s*$//;    
            if ( $name eq $configParamName && $value ne "" ){
                return $value;
            }
            }
        }
        close(CONFIG);
    } 
    else 
    {
    log_msg("ERROR: File $file doesn't exist \n");
    }
   return; 
}

############################################################
# MAIN Function
############################################################

log_msg("INFO", "Log initializing\n");

# Setting timeout
$SIG{ALRM} = sub {
    print "PLUGIN TIMEOUT: dell_check_warranty.pl timed out after $plugin_timeout seconds$nextline";
    exit $UNKNOWN;
};

alarm $plugin_timeout;

# Check Arguments
if (defined $opt{'component'}){
    if (( lc($opt{'component'}) eq 'warranty' )) {
         get_warranty_info();
    } 
	else {
        print "Invalid component name $opt{'component'}$nextline";
        log_msg ("CRITICAL", "Invalid component name $opt{'component'}\n");
		exit $UNKNOWN;
    }
}

#-----------------------------------------------------------------
# Simple log-writing method
#-----------------------------------------------------------------

sub log_msg
{

    my ($severity,$message) = @_;

    my $tm = localtime(time);
    # time in following format : 2013-01-16 18:57:37 
    my $current_time = sprintf '%d-%02d-%02d %02d:%02d:%02d ', $tm->year + 1900, $tm->mon+1, $tm->mday, $tm->hour , $tm->min , $tm->sec;    
    
    eval
    {
        $message = $current_time . q{ } . $severity . q{ } . q{Dell_} . $opt{'component'} . q{ } . $opt{'hostname'} . q{ } .  $message ;    

        if ($opt{opt_log})
        {
            open(FILE,">>$opt_logfile") ;
            print FILE "$message" or warn "Error writing $message to $opt_logfile: $!";
            close FILE;
        }
    };
    
    return 1;
}

exit;
 
