﻿Release Notes

Dell EMC OpenManage Plug-in Version 2.1 for Nagios Core

-------------------------------------------------------------------------------
Dell EMC OpenManage Plug-in version 2.1 for Nagios Core provides capabilities to 
monitor 12th and later generations of Dell EMC PowerEdge servers, Datacenter 
Scalable Solutions (DSS) and Hyper-Converged Infrastructure (HCI) through an 
agent-free method using Integrated Dell Remote Access Controller (iDRAC) with 
Lifecycle Controller, Dell EMC chassis and Dell EMC storage devices in the 
Nagios Core console. This plug-in provides comprehensive hardware-level 
visibility including overall and component-level health monitoring of Dell EMC 
PowerEdge servers, Datacenter Scalable Solutions (DSS) and Hyper-Converged 
Infrastructure (HCI) through SNMP and WS-MAN protocols, Dell EMC chassis through 
WS-MAN protocol and Dell EMC storage through SNMP protocol. This plug-in 
provides basic information about the Dell EMC devices and its components and 
also monitors the events that are generated from the Dell EMC devices. This 
plug-in also supports one-to-one web console launch for iDRAC, Chassis, and 
storage devices to perform further troubleshooting, configuration, and 
management activities.

*******************************************************************************

Version: 2.1 

*******************************************************************************

Release Date: July 2017

*******************************************************************************

Previous Versions: 1.0 and 2.0

*******************************************************************************

Importance
----------
OPTIONAL: Dell EMC recommends the customer to review specifics about the 
software update to determine if it applies to your system. The update contains 
changes that impact certain configurations, or provides new features that 
may/may not apply to your environment. 

*******************************************************************************

Platform(s) Affected 
--------------------

For the list of supported platforms, see the section "Support Matrix" in the 
"Dell EMC OpenManage Plug-in Version 2.1 for Nagios Core User's Guide" at 
dell.com/openmanagemanuals.

*******************************************************************************

What is Supported?
------------------
Dell EMC OpenManage Plug-in Version 2.1 for Nagios Core is supported on Nagios 
Core version 3.5.0 and later.

For the list of supported software, operating systems, and other requirements, 
see the "Dell EMC OpenManage Plug-in Version 2.1 for Nagios Core Installation 
Guide" at dell.com/openmanagemanuals.

*******************************************************************************
What’s New?
-----------

* Support for 14G servers and HCI(Hyper Converged Infrastructure) Platforms.

* Upgrade from previous Dell OpenManage Plug-in Version 1.0 and Dell OpenManage 
  Plug-in Version 2.0 to the current Dell EMC OpenManage Plug-in Version 2.1 for
  Nagios Core.
  
*******************************************************************************

Fixes
-----
* Issue 1(238397): In "Dell EMC Server Voltage Probe Status", service where one
  of the instance's actual status is UNKNOWN, that instance will appear as 
  CRITICAL instead of UNKNOWN while monitoring using SNMP protocol.
  
* Issue 2(240073): In "Dell EMC Server Overall Health Status" Service and "Dell 
  EMC Server Temperature Probe Status" service the Overall health status of 
  temperature is shown incorrectly when CPU temperature is WARNING or CRITICAL, 
  for an iDRAC7 or iDRAC8 device when it is discovered using SNMP protocol.  
  
* Issue 3(251278): When Dell EMC chassis is discovered using IPv6, then the 
  RACADM specific attributes such as Speed(RPM) in "Dell EMC Chassis Fan 
  Status", OutputPower(W), InputVoltage(V), and InputCurrent(A) in "Dell EMC 
  Chassis Power Supply Status" services will be shown as "Not Available".
  
* Issue 4(242341, 238683): In "Dell EMC Server Overall Health Status" service, 
  Power Supply Status is shown as OK instead of UNKNOWN when PowerEdge T130 or 
  PowerEdge C6320 device is discovered using SNMP protocol.

* Issue 5(238444): In "Dell EMC Server Voltage Probe Status" service, some of 
  the Voltage instances will not be seen when the PowerEdge C6320 is discovered 
  using WS-MAN protocol. 

*******************************************************************************

Important Notes 
---------------
To visit Dell TechCenter for accessing whitepapers, blogs, wiki-articles, 
videos, Product communities and forums, see:  
http://en.community.dell.com/techcenter/systems-management/w/wiki/
6277.dell-openmanage-plug-in-for-nagios-core

*******************************************************************************

Known Issues
------------
* Issue 1(178686):
  Description: SNMP traps are not received from the Dell EMC device in the 
  Nagios Core console for Ubuntu setup. 
  
  Version Affected: Dell EMC OpenManage Plug-in Version 2.1 for Nagios Core.  
   
* Issue 2(255091):
  Description: In "Dell EMC Server Overall Health Status" service, Power Supply 
  Status is shown as OK instead of UNKNOWN when DSS 1510 device is discovered 
  using SNMP and WS-MAN protocol.

  Version Affected: Dell EMC OpenManage Plug-in Version 2.1 for Nagios Core.
    
* Issue 3(66797):
  Description: In "Dell EMC Server Information" service , the attribute 
  "Device type" is shown as 'iDRAC' instead of 'iDRAC8' for PowerEdge 
  C6320 discovered using SNMP.
  
  Version Affected: Dell EMC OpenManage Plug-in Version 2.1 for Nagios Core.

* Issue 4(63682):
  Description: For 14G Server that is discovered using SNMP protocol, the
  "Power unit" attribute in the "Dell EMC Server Overall Health Status" service 
  is not shown, when the Redundancy Policy is set to "Non Redundant" in iDRAC 
  console and then the "Server is rebooted"/"iDRAC is reset"/"Firmware update".

  Version Affected: Dell EMC OpenManage Plug-in Version 2.1 for Nagios Core.  

* Issue 5(10443):
  Description: For PowerEdge FM120 / PowerEdge FC430 / PowerEdge FC630 /
  PowerEdge FC830, in "Dell EMC Server Power Supply Status" service, the 
  attributes "InputVoltage(V)" is shown as 0 and "FirmwareVersion" is not shown 
  when discovered using WS-MAN and "InputVoltage(V)" is not shown when 
  discovered using SNMP.

  Version Affected: Dell EMC OpenManage Plug-in Version 2.1 for Nagios Core.

* Issue 6(68504):
  Description: For PowerEdge C6320 server, in "Dell EMC Server Voltage Probe 
  Status" service, the value of the attribute "Reading" for "Input voltage" 
  instance shows "Good" instead of actual value when discovered using WS-MAN.
  
  Version Affected: Dell EMC OpenManage Plug-in Version 2.1 for Nagios Core.
  
*******************************************************************************

Limitations
-----------

* IPv6 traps are not associated with the corresponding Dell EMC device in the 
  Nagios Core console.

*******************************************************************************

Installation Prerequisites
--------------------------
For the installation prerequisites, see the "Dell EMC OpenManage Plug-in Version 
2.1 for Nagios Core Installation Guide" at dell.com/openmanagemanuals 

*******************************************************************************

Installation Procedure
----------------------
For installation or update related information, see the "Dell EMC OpenManage 
Plug-in Version 2.1 for Nagios Core Installation Guide" at 
dell.com/openmanagemanuals 

*******************************************************************************

Installation and Configuration Notes
------------------------------------
For installation and configuration related information, see the "Dell EMC 
OpenManage Plug-in Version 2.1 for Nagios Core Installation Guide" at 
dell.com/openmanagemanuals

*******************************************************************************

Contacting Dell
---------------

Note: If you do not have an active Internet connection, you can find contact 
information on your purchase invoice, packing slip, bill, or Dell product 
catalog.

Dell provides several online and telephone-based support and service options. 
Availability varies by country and product, and some services may not be 
available in your area. To contact Dell for sales, technical support, or 
customer service issues:
1.           Go to Dell.com/support.
2.           Select your support category. 
3.           Verify your country or region in the Choose a Country/Region 
             drop-down list at the bottom of the page.
4.           Select the appropriate service or support link based on your need.              

-------------------------------------------------------------------------------
Information in this document is subject to change without notice.

Copyright © 2015 - 2017 Dell Inc. or its subsidiaries. All rights reserved. 
Dell, EMC, and other trademarks are trademarks of Dell Inc. or its subsidiaries.
Other trademarks may be trademarks of their respective owners
